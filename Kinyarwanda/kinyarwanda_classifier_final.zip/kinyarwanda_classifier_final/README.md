# Kinyarwanda Multidomain Domain Classifier

This package contains the files required to preserve the
Kinyarwanda domain-classification experiment.

## Folder Structure

### model/
- `kinyarwanda_domain_classifier.joblib`
  Trained TF-IDF + Logistic Regression pipeline.

### data/
- `kinyarwanda_multidomain_candidates.csv`
  Multidomain corpus used for model development.
- `Gold_Test_sample.xlsx`
  Manually annotated Gold Test data.

### results/
- `Gold_Test_with_Classifier_Predictions.xlsx`
- `metrics.csv`
- `validation_classification_report.csv`
- `gold_test_classification_report.csv`
- `validation_confusion_matrix.png`
- `gold_test_confusion_matrix.png`
- `gold_test_misclassifications.csv`
- `others_prediction_distribution.csv`
- `classifier_report.md`

### documentation/
- `model_metadata.json`
- `environment_versions.txt`

## Important

The manually annotated Gold Test examples were removed from the
training corpus before model training and internal validation.

The model was trained on five classes:
Health, Finance, Agriculture, Telecoms, and Law.

The human Gold Test additionally contains an `others` label.
Because `others` was not included during training, it is analyzed
separately rather than treated as a sixth model class.