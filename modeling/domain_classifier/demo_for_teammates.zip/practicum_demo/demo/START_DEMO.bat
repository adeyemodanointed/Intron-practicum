@echo off
rem Windows: double-click this file. The first run installs what it needs (internet required); later runs work offline.
cd /d "%~dp0.."
if not exist .venv\Scripts\python.exe (
  echo First run: setting up. This can take several minutes.
  python -m venv .venv || (echo Could not create the environment. Install Python 3.10 or newer from python.org, tick "Add to PATH", and try again. & pause & exit /b 1)
  .venv\Scripts\python -m pip install -r demo\requirements.txt || (echo Install failed. Check your internet connection and try again. & rmdir /s /q .venv & pause & exit /b 1)
)
start "" cmd /c "timeout /t 45 >nul & start http://127.0.0.1:7860"
.venv\Scripts\python -X utf8 demo\app.py
pause
