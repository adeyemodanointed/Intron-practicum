"""Local demo page for the practicum. Every file in tasks/ whose name does not start with "_" becomes one tab.

    python demo/app.py        # then open http://127.0.0.1:7860

Runs on this computer only and needs no internet once the models are on disk. See demo/README.md to add a tab.
"""
import importlib, os, pkgutil, sys, time, traceback

from flask import Flask, jsonify, request, send_from_directory

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.dirname(HERE))   # the classifier's domain_model.py and train_afroxlmr_domain.py

import tasks  # noqa: E402

app = Flask(__name__)
TASKS, BROKEN = {}, {}
for m in sorted(pkgutil.iter_modules(tasks.__path__), key=lambda x: x.name):
    if m.name.startswith("_"):
        continue
    try:
        mod = importlib.import_module(f"tasks.{m.name}")
        TASKS[m.name] = mod
    except Exception:   # one teammate's broken tab must not take the others down
        BROKEN[m.name] = traceback.format_exc(limit=2)
        print(f"tab {m.name} did not load:\n{BROKEN[m.name]}", file=sys.stderr)


@app.get("/")
def page():
    return send_from_directory(HERE, "index.html")


@app.get("/api/tasks")
def list_tasks():
    out = []
    for key, t in sorted(TASKS.items(), key=lambda kv: getattr(kv[1], "ORDER", 50)):
        status = t.status() if hasattr(t, "status") else None
        out.append({"id": key, "name": t.NAME, "description": t.DESCRIPTION, "languages": t.LANGUAGES,
                    "examples": getattr(t, "EXAMPLES", {}), "example_note": getattr(t, "EXAMPLE_NOTE", ""), "status": status})
    return jsonify({"tasks": out, "broken": sorted(BROKEN)})


@app.post("/api/predict/<task>")
def predict(task):
    t = TASKS.get(task)
    if not t:
        return jsonify({"error": f"no tab called {task}"}), 404
    body = request.get_json(force=True)
    text, lang = str(body.get("text", "")).strip(), body.get("language")
    if not text:
        return jsonify({"error": "Enter some text first."}), 400
    if lang not in t.LANGUAGES:
        return jsonify({"error": "This tab does not support that language."}), 400
    t0 = time.time()
    try:
        result = t.predict(text, lang)
    except Exception as e:
        traceback.print_exc()
        return jsonify({"error": str(e)}), 500
    result["seconds"] = round(time.time() - t0, 2)
    return jsonify(result)


if __name__ == "__main__":
    for t in TASKS.values():
        if hasattr(t, "warm_up"):
            t.warm_up()   # load models now, so the first click during the talk is not the slow one
    print("Demo ready: http://127.0.0.1:7860", flush=True)
    app.run(host="127.0.0.1", port=7860, debug=False)
