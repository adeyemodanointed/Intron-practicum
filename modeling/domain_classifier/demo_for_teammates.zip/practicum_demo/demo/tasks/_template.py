"""Copy this file to tasks/your_tab.py (a name that does not start with "_") and restart demo/app.py: a new tab appears.
You only edit this one file. The page, the language menu and the example buttons are built from what you set here."""

ORDER = 10                    # tabs are sorted by this; the domain classifier is 20, so 10 puts yours before it
NAME = "Punctuation & capitalisation"
DESCRIPTION = "One sentence the audience can read: what this model does."
LANGUAGES = {"ibo": "Igbo", "kin": "Kinyarwanda", "pcm": "Nigerian Pidgin", "swa": "Swahili", "yor": "Yoruba"}
EXAMPLES = {"pcm": ["na di farmer wey plant plantain rice and beans"]}   # buttons per language; optional
EXAMPLE_NOTE = ""             # optional line shown under the buttons


def warm_up():
    """Optional: load your model here so the first click during the talk is not slow."""


def predict(text, language):
    """Return a dict with any of these keys; the page shows whichever are present:

    output_text   text to show as the result (for example the punctuated sentence)
    labels        list of chosen labels, shown as large chips
    scores        list of {"label": str, "score": 0-1, "threshold": 0-1 or None}, shown as bars
    note          one line of small print
    """
    raise NotImplementedError("Load your model and return, for example, {\"output_text\": punctuated}")
