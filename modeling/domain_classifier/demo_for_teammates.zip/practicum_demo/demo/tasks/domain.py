"""Domain classifier tab: AfroXLMR-base v8, with the labelling rule and per-language thresholds used for the delivered model."""
import json, os

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))
BUNDLED = os.path.join(os.path.dirname(HERE), "model_domain")   # the full package puts the model here
PACKAGE = os.environ.get("DOMAIN_MODEL_PACKAGE") or (BUNDLED if os.path.exists(BUNDLED) else
                                                     os.path.join(ROOT, "results", "kaggle_v3", "domain-v8-base", "final_package"))

ORDER = 20
NAME = "Domain classifier"
DESCRIPTION = "Sorts a text into agriculture, finance, health, law or telecoms (one or two of them), or \"other\". AfroXLMR-base v8."
LANGUAGES = {"swa": "Swahili", "kin": "Kinyarwanda", "pcm": "Nigerian Pidgin", "yor": "Yoruba"}
EXAMPLE_NOTE = "Draft examples, written for this demo and not in the training data. Have a native speaker check them before the talk."
with open(os.path.join(HERE, "domain_examples.json"), encoding="utf-8") as f:
    EXAMPLES = json.load(f)

_model = None


def status():
    if os.path.exists(os.path.join(PACKAGE, "predictor.json")):
        return None
    return "The domain model is not on this computer, so this tab cannot run. The other tabs still work. See demo/README.md."


def warm_up():
    if status() is None:
        _load()


def _load():
    global _model
    if _model is None:
        import torch
        from transformers import AutoModelForSequenceClassification, AutoTokenizer
        cfg = json.load(open(os.path.join(PACKAGE, "predictor.json"), encoding="utf-8"))
        d = os.path.join(PACKAGE, cfg["models"][0])
        tok = AutoTokenizer.from_pretrained(d)
        try:
            net = AutoModelForSequenceClassification.from_pretrained(d, dtype=torch.float32)
        except TypeError:   # older transformers
            net = AutoModelForSequenceClassification.from_pretrained(d, torch_dtype=torch.float32)
        net.eval()
        _model = (tok, net, cfg["thresholds"], cfg.get("max_labels", 2))
    return _model


def predict(text, language):
    if status():
        raise RuntimeError(status())
    import torch
    from domain_model import DOMAINS, LABELS, OTHER, decide_labels, th_for
    tok, net, thresholds, max_labels = _load()
    enc = tok([text], truncation=True, max_length=256, return_tensors="pt")
    with torch.no_grad():
        p = torch.sigmoid(net(**enc).logits).numpy()
    chosen = decide_labels(p, [language], thresholds, max_labels)[0]
    th = th_for(thresholds, language)
    scores = [{"label": lab, "score": round(float(x), 3), "threshold": th.get(lab) if lab != OTHER else None}
              for lab, x in zip(LABELS, p[0])]
    scores.sort(key=lambda s: -s["score"])
    return {"labels": chosen, "scores": scores,
            "note": "A domain is given when its bar passes the marker for this language, at most two per text."}
