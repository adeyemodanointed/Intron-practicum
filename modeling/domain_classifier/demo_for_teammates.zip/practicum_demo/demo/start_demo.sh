#!/bin/sh
# Mac or Linux: run "sh demo/start_demo.sh". The first run installs what it needs (internet required); later runs work offline.
cd "$(dirname "$0")/.." || exit 1
if [ ! -x .venv/bin/python ]; then
  echo "First run: setting up. This can take several minutes."
  python3 -m venv .venv || { echo "Could not create the environment. Install Python 3.10 or newer and try again."; exit 1; }
  .venv/bin/python -m pip install -r demo/requirements.txt || { echo "Install failed. Check your internet connection and try again."; rm -rf .venv; exit 1; }
fi
echo "When it says Demo ready, open http://127.0.0.1:7860"
.venv/bin/python -X utf8 demo/app.py
