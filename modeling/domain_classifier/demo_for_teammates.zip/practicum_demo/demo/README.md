# Practicum demo page

One local web page with one tab per model. It runs on your own laptop, with no internet needed once it is installed.

The AfroXLMR domain model is private project work trained on some research-only data. Please do not post or reshare it. It comes inside the full package, or is shared separately.

## Run it

You need Python 3.10 or newer, about 4 GB of free disk space and about 3 GB of free memory. Unzip the package first, then:

- **Windows:** double-click `demo\START_DEMO.bat`.
- **Mac or Linux:** from inside the `practicum_demo` folder, run `sh demo/start_demo.sh`.

The first run needs internet and takes several minutes to install. Later runs work offline.

Wait until the window says `Demo ready`, about a minute, then open http://127.0.0.1:7860. Try the Domain classifier tab first. To stop it, press Ctrl+C in that window.

A GPU is not needed. If `pip install` is slow, torch is the large download, about 200 MB for the CPU build and more for others.

## Add punctuation and capitalisation (you only touch one file)

1. Copy `demo/tasks/_template.py` to `demo/tasks/punctuation.py`.
2. Fill in `NAME`, `DESCRIPTION`, `LANGUAGES` and, if you like, `EXAMPLES`.
3. Write `predict(text, language)`: load your model once and return what the page should show:
   - `output_text`: the punctuated sentence
   - `labels`: labels to show as large chips (not needed for punctuation)
   - `scores`: bars, as a list of `{"label": ..., "score": 0-1, "threshold": 0-1 or None}` (not needed for punctuation)
   - `note`: one line of small print
4. Add any extra packages your model needs, and restart `demo/app.py`. Your tab appears before the domain classifier. If your file has an error, the page names it and the other tabs keep working.

Your models can sit anywhere on your laptop. If you put this folder in Git, keep data, model weights and API keys out of it.

## Recording the demo video

- Check the example sentences with a native speaker first (`demo/tasks/domain_examples.json`). They are drafts, and you can edit them freely.
- Use new texts. The final domain model trained on most of our test texts, so those would look better than it really is.
- Run through it once before recording, so the models are already loaded and nothing is slow on camera.
- Zoom the browser to about 125% so the text is readable in the video.

Suggested flow: lower-case text with no punctuation goes into your tab, then paste the punctuated result into the Domain classifier tab. That shows the pipeline from the deck: PnC, then the domain classifier.

Known behaviour in the domain tab: the Kinyarwanda bank example comes out as law, and the Yoruba telecoms example also gets "finance" at a low score, because the Yoruba finance threshold is very low. These are real model mistakes, not bugs in the page.

## Sharing without the model

To work on your tab only, the small package without the model is enough: the domain tab then says the model is missing and the other tabs still work. To use a model stored elsewhere, set `DOMAIN_MODEL_PACKAGE` to the folder holding its `predictor.json`.
