"""
STEP 6 - Draw the manual-validation sample (primary reviewer + independent second check).

    python step6_review_sample.py                       # 100 records, 30 double-checked
    python step6_review_sample.py --n 60 --second 20 --seed 7

Outputs (reviews/):
    <lang>_review_primary.xlsx   (and .csv)  for the language owner
    <lang>_review_second.xlsx    (and .csv)  a subset for the second team member, answers blank

The sample is stratified by dataset x domain (every group gets at least 2 records, the
rest proportional to size), so small domains such as health are not missed.

How to review (write this in each cell; the .xlsx has drop-downs):
    is_<language>    Y/N  text is in the target language (not English, not another language)
    domain_correct   Y/N  the 'domain' label fits the text
    punctuation_ok   Y/N  punctuation is present and mostly correct
    text_quality_ok  Y/N  no boilerplate, broken sentences, encoding damage, personal data
    decision         accept/reject   accept only if all four are Y (or you judge it usable)
    comment          free text
The second reviewer must NOT look at the primary reviewer's answers.
"""
import argparse
import csv
import random
import sys
from collections import defaultdict

import config as C
from common import parse_notes, read_jsonl

REVIEW_COLS = [C.REVIEW_LANG_COL, "domain_correct", "punctuation_ok", "text_quality_ok", "decision", "comment"]


def stratified_sample(records, n, seed, min_per_group=2):
    groups = defaultdict(list)
    for r in records:
        groups[(r["source_dataset"], r["domain"])].append(r)
    rng = random.Random(seed)
    for g in groups.values():
        rng.shuffle(g)
    alloc = {k: min(min_per_group, len(v)) for k, v in groups.items()}
    remaining = max(0, n - sum(alloc.values()))
    total = sum(len(v) - alloc[k] for k, v in groups.items()) or 1
    shares = {k: remaining * (len(v) - alloc[k]) / total for k, v in groups.items()}
    for k in groups:
        alloc[k] += int(shares[k])
    leftover = n - sum(alloc.values())
    for k in sorted(groups, key=lambda k: shares[k] - int(shares[k]), reverse=True):
        if leftover <= 0:
            break
        if alloc[k] < len(groups[k]):
            alloc[k] += 1
            leftover -= 1
    sample = [r for k, g in sorted(groups.items()) for r in g[:min(alloc[k], len(g))]]
    rng.shuffle(sample)
    return sample


def write_sheet(path_base, rows, title):
    cols = ["id", "source_dataset", "domain", "langcheck", "raw_text"] + REVIEW_COLS
    with open(path_base.with_suffix(".csv"), "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        w.writerows(rows)
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Alignment, Font, PatternFill
        from openpyxl.worksheet.datavalidation import DataValidation
    except ImportError:
        print("    (openpyxl not installed: wrote CSV only)")
        return
    wb = Workbook()
    ws = wb.active
    ws.title = title
    ws.append(cols)
    for r in rows:
        ws.append([r.get(c, "") for c in cols])
    for cell in ws[1]:
        cell.font = Font(bold=True)
        cell.fill = PatternFill("solid", fgColor="D9E2F3")
    widths = {"id": 24, "source_dataset": 18, "domain": 18, "langcheck": 11, "raw_text": 90,
              "comment": 40}
    for i, c in enumerate(cols, 1):
        ws.column_dimensions[ws.cell(1, i).column_letter].width = widths.get(c, 15)
    for row in ws.iter_rows(min_row=2):
        row[4].alignment = Alignment(wrap_text=True, vertical="top")
    yn = DataValidation(type="list", formula1='"Y,N"', allow_blank=True)
    dec = DataValidation(type="list", formula1='"accept,reject"', allow_blank=True)
    ws.add_data_validation(yn)
    ws.add_data_validation(dec)
    last = len(rows) + 1
    for c in (C.REVIEW_LANG_COL, "domain_correct", "punctuation_ok", "text_quality_ok"):
        col = ws.cell(1, cols.index(c) + 1).column_letter
        yn.add(f"{col}2:{col}{last}")
    col = ws.cell(1, cols.index("decision") + 1).column_letter
    dec.add(f"{col}2:{col}{last}")
    ws.freeze_panes = "B2"
    wb.save(path_base.with_suffix(".xlsx"))


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--n", type=int, default=100, help="records for the primary reviewer (50-100)")
    ap.add_argument("--second", type=int, default=30, help="records double-checked by a second reviewer")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--force", action="store_true",
                    help="overwrite existing review sheets (answers already typed in are LOST)")
    args = ap.parse_args()

    existing = [p for p in (C.REVIEWS / f"{C.LANG}_review_primary.xlsx",
                            C.REVIEWS / f"{C.LANG}_review_primary.csv") if p.exists()]
    if existing and not args.force:
        print(f"Review sheets already exist ({existing[0].name}); not overwriting them, so any "
              f"answers you typed are safe. Use --force to draw a new sample.")
        return 0

    src = C.CLEAN_DIR / f"{C.LANG}_clean.jsonl"
    if not src.exists():
        sys.exit("Run step3_clean.py first.")
    records = list(read_jsonl(src))
    sample = stratified_sample(records, args.n, args.seed)
    rows = [{"id": r["id"], "source_dataset": r["source_dataset"], "domain": r["domain"],
             "langcheck": parse_notes(r["notes"]).get("langcheck", ""), "raw_text": r["raw_text"],
             **{c: "" for c in REVIEW_COLS}} for r in sample]
    second = random.Random(args.seed + 1).sample(rows, min(args.second, len(rows)))

    C.REVIEWS.mkdir(parents=True, exist_ok=True)
    write_sheet(C.REVIEWS / f"{C.LANG}_review_primary", rows, "primary")
    write_sheet(C.REVIEWS / f"{C.LANG}_review_second", [dict(r) for r in second], "second")
    groups = defaultdict(int)
    for r in rows:
        groups[(r["source_dataset"], r["domain"])] += 1
    print(f"Primary sample: {len(rows)} records; second-reviewer subset: {len(second)}")
    for (s, d), c in sorted(groups.items()):
        print(f"    {s:18s} {d:22s} {c}")
    print(f"-> reviews/{C.LANG}_review_primary.xlsx and reviews/{C.LANG}_review_second.xlsx (+ .csv)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
