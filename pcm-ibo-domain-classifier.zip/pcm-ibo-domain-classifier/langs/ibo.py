"""Igbo (ibo) settings. Shared settings are in config.py.

Scope: ONLY five domains - education, health, telecommunications, finance, law.
Text that cannot be placed in one of them is dropped (STRICT_DOMAINS = True).

The Igbo keyword lists below were drafted for this project and MUST be checked and
extended by a native speaker. Matching ignores diacritics (ị/i, ọ/o, ụ/u, ṅ/n and tone
marks), so write each word once, in standard orthography.
"""
GH = "https://raw.githubusercontent.com"

LANG = "ibo"
LANG_NAME = "Igbo"
GLOTLID_LABEL = "ibo_Latn"
REVIEW_LANG_COL = "is_igbo"

TARGET_DOMAINS = ["education", "health", "telecommunications", "finance", "law"]
OTHER_DOMAINS = []
STRICT_DOMAINS = True

# Letters to track in the statistics ("diacritics preserved" selection criterion).
SPECIAL_CHARS = "ịọụṅỊỌỤṄ"
# Letters that are strong evidence for Igbo in the language check (ọ is shared with Yoruba).
LANG_EVIDENCE_CHARS = "ịụṅỊỤṄ"

IGBONLP_ZIP = f"{GH}/IgnatiusEzeani/IGBONLP/master/ig_monoling/text.zip"
IGBONLP_LICENSE = "No licence stated (BBC Igbo / Igbo Radio content, collected by Ezeani et al. 2020)"

SOURCES = {
    "masakhanews_ibo": {
        "title": "MasakhaNEWS (ibo)",
        "reader": "masakhanews",
        "hosting": "github",
        "files": {
            "train.tsv": f"{GH}/masakhane-io/masakhane-news/main/data/ibo/train.tsv",
            "dev.tsv": f"{GH}/masakhane-io/masakhane-news/main/data/ibo/dev.tsv",
            "test.tsv": f"{GH}/masakhane-io/masakhane-news/main/data/ibo/test.tsv",
            "labels.txt": f"{GH}/masakhane-io/masakhane-news/main/data/ibo/labels.txt",
        },
        "license": "AFL-3.0 (HF metadata) / CC BY-NC 4.0 (card text): conflicting, confirm",
        "research_ok": True, "commercial_ok": False,
        "domain_method": "source_label",
        "text_type": "BBC Igbo news articles with topic labels",
        "priority": 1,
    },
    "mafand_en_ibo": {
        "title": "MAFAND-MT (en-ibo, Igbo side)",
        "reader": "mafand", "side": "ibo",
        "hosting": "github",
        "files": {
            "train.json": f"{GH}/masakhane-io/lafand-mt/main/data/json_files/en-ibo/train.json",
            "dev.json": f"{GH}/masakhane-io/lafand-mt/main/data/json_files/en-ibo/dev.json",
            "test.json": f"{GH}/masakhane-io/lafand-mt/main/data/json_files/en-ibo/test.json",
        },
        "license": "CC BY-NC 4.0 (data, per HF card); repository code GPL-3.0",
        "research_ok": True, "commercial_ok": False,
        "domain_method": "keyword",
        "text_type": "News sentences professionally translated into Igbo",
        "priority": 2,
    },
    "igbonlp_bbc": {
        "title": "IgboNLP monolingual: BBC Igbo (Ezeani et al. 2020)",
        "reader": "lines", "zip_member": "bbc-igbo.txt",
        "tokenized": True, "drop_unterminated": True,
        "hosting": "github",
        "files": {"text.zip": IGBONLP_ZIP},
        "license": IGBONLP_LICENSE,
        "research_ok": True, "commercial_ok": False,
        "domain_method": "keyword",
        "text_type": "BBC Igbo news 2018-2020, one sentence per line, tokenised (re-joined here)",
        "priority": 3,
    },
    "igbonlp_radio": {
        "title": "IgboNLP monolingual: Igbo Radio (Ezeani et al. 2020)",
        "reader": "lines", "zip_member": "igbo-radio.txt",
        "tokenized": True, "drop_unterminated": True,
        "hosting": "github",
        "files": {"text.zip": IGBONLP_ZIP},
        "license": IGBONLP_LICENSE,
        "research_ok": True, "commercial_ok": False,
        "domain_method": "keyword",
        "text_type": "igboradio.com news stories, one sentence per line, tokenised",
        "priority": 4,
    },
    "common_voice_ig": {
        "title": "Common Voice Igbo sentences (read-speech prompts)",
        "reader": "lines", "merge_lines": False,
        "in_final_dataset": False,     # poorly punctuated prompts: used for training, not delivered
        "hosting": "github",
        "files": {"sentences.txt": f"{GH}/common-voice/common-voice/main/server/data/ig/sentence-collector.txt"},
        "license": "CC0 1.0 (public domain)",
        "research_ok": True, "commercial_ok": True,
        "domain_method": "keyword",
        "text_type": "Short sentences recorded by Common Voice volunteers (human transcript of speech)",
        "priority": 9,
    },
    "xlsum_igbo": {
        "title": "XL-Sum (igbo)",
        "reader": "xlsum",
        "hosting": "hf", "hf_repo": "csebuetnlp/xlsum",
        "hf_files": ["data/igbo_XLSum_v2.0.tar.bz2"],
        "license": "CC BY-NC-SA 4.0",
        "research_ok": True, "commercial_ok": False,
        "domain_method": "keyword",
        "text_type": "BBC Igbo news articles (overlaps MasakhaNEWS/IgboNLP; de-duplicated)",
        "priority": 5,
    },
    "wura_ibo": {
        "title": "WURA (ibo, document level)",
        "reader": "wura",
        "hosting": "hf", "hf_repo": "castorini/wura",
        "hf_files": ["documents-v1.0/train/ibo.jsonl", "documents-v1.0/eval/ibo.jsonl"],
        "license": "Apache-2.0 (dataset); audited mC4 + verified news sites",
        "research_ok": True, "commercial_ok": True,
        "domain_method": "keyword",
        "text_type": "Audited web and news documents (about 197 MB)",
        "priority": 6,
    },
    "wikipedia_ig": {
        "title": "Wikipedia (ig, 2023-11-01 dump)",
        "reader": "wikipedia",
        "hosting": "hf", "hf_repo": "wikimedia/wikipedia",
        "hf_files": ["20231101.ig/train-00000-of-00001.parquet"],
        "license": "CC BY-SA 4.0 (and GFDL)",
        "research_ok": True, "commercial_ok": True,
        "domain_method": "keyword",
        "text_type": "Encyclopedia articles (many short or bot-generated stubs)",
        "priority": 7,
    },
    "fineweb2_ibo": {
        "title": "FineWeb-2 (ibo_Latn)",
        "reader": "fineweb",
        "hosting": "hf", "hf_repo": "HuggingFaceFW/fineweb-2",
        "hf_patterns": ["data/ibo_Latn/*"],
        "license": "ODC-By 1.0 (plus Common Crawl terms of use)",
        "research_ok": True, "commercial_ok": True,
        "domain_method": "keyword",
        "text_type": "Filtered web text (about 152 MB; includes religious and other off-scope text)",
        "priority": 8,
    },
}
for _s in SOURCES.values():
    _s.setdefault("fallback_domain", "out_of_scope")

CONSIDERED_NOT_USED = [
    ("IgboNLP JW texts (Bible, Watchtower, JW books)", "Copyrighted (Watch Tower); religious, outside the five domains"),
    ("IgboNLP novels (Eze Goes to School, Mmadu ka a na aria)", "Literature, outside the five domains"),
    ("AfriSenti / NaijaSenti (ibo tweets)", "Tweets: informal punctuation, no domain labels"),
    ("MasakhaNER (ibo)", "Tokenised NER sentences from the same news already covered"),
    ("FLORES-200 (ibo_Latn)", "Evaluation benchmark: keep for testing only, never train on it"),
]

# MasakhaNEWS / WURA category -> domain. Labels not listed here (politics, sports,
# entertainment, religion, ...) go through the keyword classifier, so e.g. a politics
# story about a court case can still become "law"; otherwise it is dropped.
LABEL_MAP = {"health": "health", "business": "finance", "education": "education"}
UNMAPPED_LABEL_POLICY = "keyword"

# --------------------------------------------------------------------------------------
# Keyword lists (Igbo + English loanwords/acronyms used in Igbo news). CHECK WITH A NATIVE
# SPEAKER. Non-target lists exist only to compete: a politics story should not be pushed
# into "law" because it mentions one court.
# --------------------------------------------------------------------------------------
DOMAIN_KEYWORDS = {
    "health": [
        "ahụike", "ahụ ike", "ọrịa", "ndị ọrịa", "onye ọrịa", "dọkịta", "ndị dọkịta", "ụlọ ọgwụ",
        "ụlọọgwụ", "ọgwụ", "ọgwụgwọ", "ọgwụ mgbochi", "mgbochi ọrịa", "nọọsụ", "ndị nọọsụ", "nje",
        "ịba", "ahụ ọkụ", "ọrịa kansa", "ọrịa shuga", "ọrịa obi", "ọbara", "afọ ime", "nwanyị dị ime",
        "ọrịa na-efe efe", "covid", "covid-19", "coronavirus", "kọrọna", "hiv", "aids", "lassa",
        "kọlera", "cholera", "polio", "ncdc", "world health organization", "hospital", "doctor",
        "doctors", "vaccine", "malaria", "ahụike uche",
    ],
    "education": [
        "agụmakwụkwọ", "agụmagụ", "ụlọ akwụkwọ", "ụlọakwụkwọ", "ụmụ akwụkwọ", "ụmụakwụkwọ",
        "nwa akwụkwọ", "onye nkuzi", "ndị nkuzi", "nkuzi", "mahadum", "ule", "waec", "neco", "jamb",
        "asuu", "ubec", "praịmarị", "sekọndrị", "klas", "klaasị", "gụọ akwụkwọ", "agụ akwụkwọ",
        "school", "schools", "university", "students", "teachers", "education", "polytechnic",
        "kọleji", "sikọlashịp",
    ],
    "sports": [
        "egwuregwu", "bọọlụ", "bọl", "bọọlụ ụkwụ", "agba bọọlụ", "na-agba bọọlụ", "goolu", "asọmpi",
        "super eagles", "super falcons", "flying eagles", "golden eaglets", "fifa", "caf", "afcon",
        "world cup", "iko mbaụwa", "premier league", "champions league", "nff", "npfl",
        "klọb", "klọọbụ", "chelsea", "arsenal", "manchester", "liverpool", "barcelona",
        "real madrid", "olimpik", "olympics", "mgba", "boxing", "kọchị", "coach", "football",
        "match", "stadium", "ama egwuregwu",
    ],
    "law": [
        "ụlọikpe", "ụlọ ikpe", "ọkaikpe", "ndị ọkaikpe", "ọka iwu", "onye ọka iwu", "ndị ọka iwu",
        "iwu", "ikpe", "ikpe ọmụma", "mkpọrọ", "ụlọ mkpọrọ", "ụlọmkpọrọ", "ebubo", "boro ebubo",
        "ndị uwe ojii", "uwe ojii", "uweojii", "njide", "jidere", "nwụchiri", "mpụ", "omempụ",
        "ndị omekome", "efcc", "icpc", "supreme court", "high court", "court", "judge", "lawyer",
        "bail", "beelụ", "iwu obodo", "akwụkwọ iwu", "ikike mmadụ", "human rights",
    ],
    "telecommunications": [
        "mtn", "glo", "globacom", "airtel", "9mobile", "etisalat", "ncc", "ekwentị", "ekwe ntị",
        "ekwentị mkpanaaka", "sim", "kaadị sim", "sim card", "data", "ịntanetị", "intanet",
        "internet", "netwọk", "network", "airtime", "kredit", "rechaj", "sms", "ussd", "5g", "4g",
        "broadband", "nin", "telekọm", "telecom", "telecoms", "ozi ekwentị", "smartphone",
    ],
    # --- competing non-target domains (never kept for Igbo; "sports" above competes too) ---
    "politics_government": [
        "ntuli aka", "ntuliaka", "inec", "apc", "pdp", "apga", "gọvanọ", "onyeisiala", "onye isi ala",
        "sineto", "ndị omeiwu", "gọọmentị", "ọchịchị", "ndọrọ ndọrọ ọchịchị", "minista", "ipob",
        "president", "governor", "election",
    ],
    "religion": [
        "chọọchị", "ụka", "fada", "chineke", "chukwu", "jizọs", "kraịst", "ekpere", "baịbụl",
        "alakụba", "ụlọ alakụba", "pastọ", "bishọp", "church", "mosque",
    ],
    "entertainment": [
        "egwu", "abụ", "onye na-agụ egwu", "nollywood", "fim", "ihe nkiri", "bbnaija", "big brother",
        "davido", "wizkid", "burna boy", "music", "album", "movie",
    ],
    "finance": [
        "ego", "naịra", "naira", "ụlọ akụ", "ụlọakụ", "akụnụba", "azụmahịa", "ahịa", "ụtụ isi",
        "dọla", "cbn", "ọnụahịa", "mmanụ ụgbọala", "bank", "economy",
    ],
}

# Language check: frequent Igbo function words (written WITHOUT dots: tokens are compared
# after removing diacritics) plus strong markers for neighbouring languages.
LANG_MARKERS = {
    "nke", "ndi", "bu", "maka", "nwere", "kwuru", "anyi", "umu", "onye", "ihe", "di", "nakwa",
    "mana", "ha", "ya", "gi", "ebe", "mgbe", "site", "otu", "ruo", "ga", "ahu", "niile", "nile",
    "ozo", "kama", "maobu", "mere", "emere", "nyere", "obodo", "oge", "ugbu", "ka", "na",
    "ihi", "kwa", "dika", "nwoke", "nwanyi", "ala", "ime", "ozi", "o",
}
OTHER_LANG_MARKERS = {
    "yor": {"words": {"ni", "ti", "ati", "won", "si", "fun", "pe", "naa", "yii", "je", "se",
                      "lati", "awon", "ninu", "sugbon", "nigba", "gege", "lo"},
            "chars": "ẹṣẸṢ"},
    "hau": {"words": {"shi", "cikin", "wannan", "kuma", "domin", "amma", "yana", "suka", "sun",
                      "zai", "wanda", "daga", "mai", "ake", "ta"},
            "chars": "ɓɗƙƁƊƘ"},
}
