"""Nigerian Pidgin (pcm) settings. Shared settings are in config.py."""
GH = "https://raw.githubusercontent.com"

LANG = "pcm"
LANG_NAME = "Nigerian Pidgin"
GLOTLID_LABEL = "pcm_Latn"
REVIEW_LANG_COL = "is_pidgin"
STRICT_DOMAINS = False          # keep non-target domains (reported separately)
SPECIAL_CHARS = ""              # no language-specific letters to track

TARGET_DOMAINS = ["education", "health", "telecommunications", "finance", "law"]
OTHER_DOMAINS = [
    "politics_government", "sports", "entertainment", "religion", "technology",
    "agriculture", "general_news", "conversation", "general",
]

SOURCES = {
    "masakhanews_pcm": {
        "reader": "masakhanews", "fallback_domain": "general_news",
        "title": "MasakhaNEWS (pcm)",
        "hosting": "github",
        "files": {
            "train.tsv": f"{GH}/masakhane-io/masakhane-news/main/data/pcm/train.tsv",
            "dev.tsv": f"{GH}/masakhane-io/masakhane-news/main/data/pcm/dev.tsv",
            "test.tsv": f"{GH}/masakhane-io/masakhane-news/main/data/pcm/test.tsv",
            "labels.txt": f"{GH}/masakhane-io/masakhane-news/main/data/pcm/labels.txt",
        },
        "hf_mirror": "masakhane/masakhanews (config pcm)",
        "license": "AFL-3.0 (HF metadata) / CC BY-NC 4.0 (card text): conflicting, confirm",
        "research_ok": True,
        "commercial_ok": False,
        "domain_method": "source_label",
        "text_type": "BBC Pidgin news articles, human-written",
        "priority": 1,
    },
    "mafand_en_pcm": {
        "reader": "mafand", "side": "pcm", "fallback_domain": "general_news",
        "title": "MAFAND-MT (en-pcm, Pidgin side)",
        "hosting": "github",
        "files": {
            "train.json": f"{GH}/masakhane-io/lafand-mt/main/data/json_files/en-pcm/train.json",
            "dev.json": f"{GH}/masakhane-io/lafand-mt/main/data/json_files/en-pcm/dev.json",
            "test.json": f"{GH}/masakhane-io/lafand-mt/main/data/json_files/en-pcm/test.json",
        },
        "hf_mirror": "masakhane/mafand (config en-pcm)",
        "license": "CC BY-NC 4.0 (data, per HF card); repository code GPL-3.0",
        "research_ok": True,
        "commercial_ok": False,
        "domain_method": "keyword",
        "text_type": "News sentences translated into Pidgin by professional translators",
        "priority": 2,
    },
    "ud_naija_nsc": {
        "reader": "ud_naija", "fallback_domain": "conversation",
        "title": "UD Naija-NSC treebank (orthographic transcripts of speech)",
        "hosting": "github",
        "files": {
            "train.conllu": f"{GH}/UniversalDependencies/UD_Naija-NSC/master/pcm_nsc-ud-train.conllu",
            "dev.conllu": f"{GH}/UniversalDependencies/UD_Naija-NSC/master/pcm_nsc-ud-dev.conllu",
            "test.conllu": f"{GH}/UniversalDependencies/UD_Naija-NSC/master/pcm_nsc-ud-test.conllu",
        },
        "hf_mirror": None,
        "license": "CC BY-SA 4.0",
        "research_ok": True,
        "commercial_ok": True,  # share-alike obligations apply
        "domain_method": "keyword",
        "text_type": "Human transcripts of recorded speech (NaijaSynCor); punctuated orthographic layer",
        "priority": 3,
    },
    "xlsum_pidgin": {
        "reader": "xlsum", "fallback_domain": "general_news",
        "title": "XL-Sum (pidgin)",
        "hosting": "hf",
        "hf_repo": "csebuetnlp/xlsum",
        "hf_files": ["data/pidgin_XLSum_v2.0.tar.bz2"],
        "license": "CC BY-NC-SA 4.0",
        "research_ok": True,
        "commercial_ok": False,
        "domain_method": "keyword",
        "text_type": "BBC Pidgin news articles (overlaps MasakhaNEWS; de-duplicated)",
        "priority": 4,
    },
    "wikipedia_pcm": {
        "reader": "wikipedia", "fallback_domain": "general",
        "title": "Wikipedia (pcm, 2023-11-01 dump)",
        "hosting": "hf",
        "hf_repo": "wikimedia/wikipedia",
        "hf_files": ["20231101.pcm/train-00000-of-00001.parquet"],
        "license": "CC BY-SA 4.0 (and GFDL)",
        "research_ok": True,
        "commercial_ok": True,  # share-alike obligations apply
        "domain_method": "keyword",
        "text_type": "Encyclopedia articles written in Pidgin",
        "priority": 5,
    },
    "fineweb2_pcm": {
        "reader": "fineweb", "fallback_domain": "general",
        "title": "FineWeb-2 (pcm_Latn)",
        "hosting": "hf",
        "hf_repo": "HuggingFaceFW/fineweb-2",
        "hf_patterns": ["data/pcm_Latn/*"],
        "license": "ODC-By 1.0 (plus Common Crawl terms of use)",
        "research_ok": True,
        "commercial_ok": True,
        "domain_method": "keyword",
        "text_type": "Filtered web text; language ID is automatic, so check carefully",
        "priority": 6,
    },
}

# Speech transcripts: NOT part of the text corpus. They are used only to measure the
# gap between clean punctuated text and ASR-style transcripts (PnC findings task).
AUX_SOURCES = {
    "asr_pcm_transcripts": {
        "reader": "asr_parquet",
        "title": "Nigerian Pidgin ASR 1.0 (human transcripts)",
        "hosting": "hf",
        "hf_repo": "asr-nigerian-pidgin/nigerian-pidgin-1.0",
        "hf_patterns": ["data/*"],
        "license": "CC BY 4.0",
        "note": "About 956 MB because the parquet files contain audio; download with --with-asr.",
    },
}

# Candidates considered but not downloaded (they appear in the Monday table with a reason).
CONSIDERED_NOT_USED = [
    ("AfriSenti / NaijaSenti (pcm tweets)", "Tweets: informal punctuation, no domain labels"),
    ("JW300 (pcm)", "Withdrawn over copyright; religious domain only"),
    ("PidginUNMT BBC scrape", "No clear licence; same BBC text is covered by XL-Sum/MasakhaNEWS"),
    ("AfriSpeech-200", "Nigerian-accented English, not Pidgin"),
]

# --------------------------------------------------------------------------------------
# Keyword lists for the domain classifier (Pidgin + English spellings, lower case).
# Multi-word entries are matched as phrases. Extend these after manual review.
# --------------------------------------------------------------------------------------
DOMAIN_KEYWORDS = {
    "health": [
        "hospital", "hospitals", "doctor", "doctors", "nurse", "nurses", "clinic", "patient",
        "patients", "disease", "diseases", "sickness", "sick", "malaria", "vaccine", "vaccines",
        "vaccination", "covid", "coronavirus", "cholera", "lassa", "polio", "hiv", "aids",
        "cancer", "diabetes", "pregnant", "pregnancy", "belle", "medicine", "medical",
        "treatment", "infection", "virus", "fever", "ncdc", "health", "mental health",
        "blood", "surgery", "drugs", "tuberculosis", "hepatitis", "maternal", "pikin health",
        "immunisation", "immunization", "outbreak", "symptoms", "wellbeing",
    ],
    "finance": [
        "naira", "bank", "banks", "banking", "money", "loan", "loans", "cbn", "central bank",
        "inflation", "economy", "economic", "tax", "taxes", "budget", "dollar", "dollars",
        "investment", "investors", "stock", "stocks", "exchange rate", "salary", "salaries",
        "debt", "fintech", "pos", "account", "accounts", "business", "businesses", "price",
        "prices", "market", "fuel price", "subsidy", "revenue", "profit", "interest rate",
        "insurance", "savings", "cash", "crypto", "cryptocurrency", "bitcoin", "wages",
    ],
    "agriculture": [
        "farm", "farms", "farmer", "farmers", "farming", "agric", "agriculture", "agricultural",
        "crop", "crops", "harvest", "rice", "cassava", "maize", "corn", "yam", "cocoa",
        "fertiliser", "fertilizer", "livestock", "cattle", "cow", "cows", "poultry", "goat",
        "herders", "herdsmen", "seed", "seeds", "irrigation", "planting", "plant", "food security",
        "food production", "fish farming", "tomato", "tomatoes", "pesticide", "soil", "grains",
    ],
    "telecommunications": [
        "mtn", "glo", "globacom", "airtel", "9mobile", "etisalat", "ncc", "telecom", "telecoms",
        "telecommunication", "telecommunications", "sim", "sim card", "sim cards", "nin",
        "airtime", "recharge", "data plan", "data bundle", "network", "networks", "broadband",
        "internet", "5g", "4g", "ussd", "sms", "phone call", "subscribers", "mobile phone",
        "smartphone", "handset", "call", "calls", "fibre", "fiber", "spectrum",
    ],
    "law": [
        "court", "courts", "judge", "judges", "justice", "lawyer", "lawyers", "law", "laws",
        "legal", "suit", "lawsuit", "trial", "tribunal", "verdict", "judgment", "judgement",
        "constitution", "constitutional", "bail", "prosecution", "prosecutor", "arraign",
        "arraigned", "jail", "prison", "sentence", "sentenced", "convicted", "efcc", "icpc",
        "supreme court", "high court", "appeal", "rights", "human rights", "attorney",
        "legislation", "bill", "act", "police", "arrest", "arrested", "charges", "charged",
    ],
    # Non-target domains help keep news about elections or football out of the five above.
    "politics_government": [
        "election", "elections", "president", "governor", "senate", "senator", "apc", "pdp",
        "inec", "vote", "votes", "campaign", "minister", "government", "politics", "political",
        "party", "tinubu", "buhari", "atiku", "assembly", "lawmakers",
    ],
    "sports": [
        "football", "match", "goal", "goals", "super eagles", "falcons", "league", "club",
        "coach", "striker", "fifa", "caf", "afcon", "world cup", "premier league", "player",
        "players", "tournament", "olympics", "athlete", "boxing",
    ],
    "entertainment": [
        "music", "musician", "song", "album", "nollywood", "film", "movie", "actor", "actress",
        "bbnaija", "big brother", "celebrity", "concert", "artist", "afrobeats", "grammy",
        "comedian", "fashion",
    ],
    "religion": [
        "church", "pastor", "mosque", "imam", "god", "allah", "christian", "christians",
        "muslim", "muslims", "prayer", "bible", "quran", "ramadan", "easter", "christmas",
        "catholic", "bishop",
    ],
    "education": [
        "school", "schools", "student", "students", "teacher", "teachers", "university",
        "universities", "asuu", "waec", "jamb", "exam", "exams", "education", "lecturer",
        "lecturers", "pupils", "classroom",
    ],
}

# Words that mark Pidgin vs English for the heuristic language check.
# Chosen because they are frequent in BBC-style Pidgin and rare in standard English
# (or the reverse). Calibrated in step 3 on MAFAND, which has aligned English sentences.

LANG_MARKERS = {
    "dey", "wey", "na", "don", "dem", "di", "dis", "dat", "dia", "una", "pikin", "pikin dem",
    "sabi", "wetin", "abi", "sef", "wan", "pipo", "sey", "bin", "im", "ontop", "oda", "becos",
    "afta", "wahala", "comot", "gree", "tori", "naim", "anoda", "wen", "neva", "odas", "tins",
    "fit", "tok", "enta", "ova", "tink", "wit", "sotey", "sotay", "chop", "belle", "kontri",
}

# MasakhaNEWS topic labels -> domains. Unmapped labels fall back to the source's
# fallback_domain ("keep" policy); the Igbo settings use the keyword classifier instead.
LABEL_MAP = {
    "business": "finance",          # business/economy news -> finance domain (review!)
    "health": "health",
    "politics": "politics_government",
    "sports": "sports",
    "entertainment": "entertainment",
    "technology": "technology",
    "religion": "religion",
}
UNMAPPED_LABEL_POLICY = "keep"

# UD Naija recordings have human-given titles. Where a title clearly names a domain we use
# it (domain_method=recording_title); other recordings are classified chunk by chunk.
NSC_TITLE_DOMAINS = {
    "Cost-Of-Living-In-Abuja": "finance", "Insurance": "finance", "Money-Wahala": "finance",
    "Ponzi-Scheme": "finance", "Fuel-Price-Increase": "finance",
    "Food-And-Health": "health", "Tailoring-Immunization": "health",
    "Sport-Commentary": "sports", "Triplea-Sports": "sports", "Why-Men-Watch-Football": "sports",
    "Lens-Sermon": "religion", "Christ-Passion-Prologue": "religion",
    "Christ-Passion-Finale": "religion", "A-Man-Named-Jesus": "religion",
    "School-Life": "education", "Entering-University": "education", "Education": "education",
}
