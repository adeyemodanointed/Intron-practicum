"""
CLASSIFIER STEP 2 - Train and evaluate the domain classifier.

    python clf2_train.py --lang pcm
    python clf2_train.py --lang pcm --gold reviews/pcm_clf_check.xlsx    # add your quick yes/no checks to the test set
    python clf2_train.py --lang pcm --embed intfloat/multilingual-e5-base # sentence-embedding model (needs sentence-transformers)

Input : data/classifier/<lang>_{train,dev,test}.jsonl   (from clf1_build_dataset.py)
Output: models/<lang>_domain_clf.joblib
        reports/<lang>_clf_report.md and .csv

Model (default): TF-IDF features (words 1-2 grams + character 3-5 grams, on lower-cased text
with diacritics removed) -> logistic regression with balanced class weights. Fast on a
laptop CPU, strong for topic classification, and robust to spelling variation.

How it avoids just copying the keyword rules:
  * texts whose label came from keywords are shown with ~50% of the keywords masked, so
    the model must use the other words around them;
  * keyword-labelled texts get a lower sample weight than human (gold) labels;
  * a "masked silver" check holds out 20% of keyword-labelled texts and tests them with
    ALL keywords hidden: if recall is still good, the model learned real context.

The probability threshold for "other" is tuned on the dev set (best macro-F1): a text is
assigned a target domain only if the model is at least that confident.
Every result is compared with the keyword rules alone (the baseline).
"""
import argparse
import csv
import random
import sys
from collections import Counter

import numpy as np

import config as C
from clf_models import OTHER, EmbedModel, TfidfModel, decide
from common import fold, keyword_confident, keyword_scores, mask_keywords, md_table, read_jsonl

WEIGHTS = {"gold": 1.0, "teacher": 0.8, "weak": 0.5}


def kind(ex):
    return (ex.get("label_source") or "gold").split(":")[0]


def keyword_baseline(text: str) -> str:
    best, s1, s2, d = keyword_scores(text)
    return best if (keyword_confident(best, s1, s2, d) and best in C.TARGET_DOMAINS) else OTHER


def load_gold_sheet(path):
    """Rows from clf3's check sheet: correct=Y -> predicted label is gold; N + true_domain -> that."""
    rows = []
    if str(path).endswith(".xlsx"):
        from openpyxl import load_workbook
        ws = load_workbook(path, read_only=True).active
        it = ws.iter_rows(values_only=True)
        head = [str(h) for h in next(it)]
        recs = [dict(zip(head, r)) for r in it]
    else:
        with open(path, encoding="utf-8-sig") as f:
            recs = list(csv.DictReader(f))
    for r in recs:
        ok = str(r.get("correct") or "").strip().upper()[:1]
        true = str(r.get("true_domain") or "").strip()
        label = r.get("predicted") if ok == "Y" else (true if true else None)
        if label and r.get("text"):
            rows.append({"text": r["text"], "label": label if label in C.TARGET_DOMAINS else OTHER,
                         "label_source": "gold:check_sheet", "source": r.get("source", "check_sheet")})
    return rows


def scores(y_true, y_pred, labels):
    from sklearn.metrics import precision_recall_fscore_support
    present = [l for l in labels if l in set(y_true)]
    p, r, f, s = precision_recall_fscore_support(y_true, y_pred, labels=present, zero_division=0)
    rows = [{"class": l, "precision": round(pi, 3), "recall": round(ri, 3), "f1": round(fi, 3),
             "support": int(si)} for l, pi, ri, fi, si in zip(present, p, r, f, s)]
    macro = round(float(np.mean(f)), 3) if len(f) else 0.0
    acc = round(float(np.mean([a == b for a, b in zip(y_true, y_pred)])), 3) if y_true else 0.0
    return rows, macro, acc


def confusion(y_true, y_pred, labels):
    present = [l for l in labels if l in set(y_true) | set(y_pred)]
    rows = []
    for t in present:
        c = Counter(p for tt, p in zip(y_true, y_pred) if tt == t)
        rows.append({"true \\ predicted": t, **{p: c.get(p, 0) for p in present}})
    return rows


def train_texts(rows, rng, mask_p):
    return [mask_keywords(r["text"], mask_p, rng) if kind(r) == "weak" else fold(r["text"]) for r in rows]


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--gold", nargs="*", default=[], help="filled annotation sheets from clf3 (xlsx/csv)")
    ap.add_argument("--train-on-gold", action="store_true",
                    help="use half of the annotated texts for training (the other half stays in the test set)")
    ap.add_argument("--embed", default="", help="sentence-transformers model name (optional)")
    ap.add_argument("--mask", type=float, default=0.5, help="keyword masking probability for weak labels")
    ap.add_argument("--seed", type=int, default=13)
    ap.add_argument("--unmeasured-threshold", type=float, default=0.6,
                    help="confidence needed for domains with no human dev labels (stricter = more precise)")
    args = ap.parse_args()

    d = C.DATA / "classifier"
    try:
        train = list(read_jsonl(d / f"{C.LANG}_train.jsonl"))
        dev = list(read_jsonl(d / f"{C.LANG}_dev.jsonl"))
        test = list(read_jsonl(d / f"{C.LANG}_test.jsonl"))
    except FileNotFoundError:
        sys.exit("Run clf1_build_dataset.py first.")
    for g in args.gold:
        extra = load_gold_sheet(g)
        if args.train_on_gold:
            rng0 = random.Random(args.seed)
            rng0.shuffle(extra)
            half = len(extra) // 2
            train += extra[:half]
            extra = extra[half:]
            print(f"Added {half} annotated texts from {g} to TRAINING")
        test += extra
        print(f"Added {len(extra)} checked examples from {g} to the test set")

    labels = C.TARGET_DOMAINS + [OTHER]
    present_train = sorted({r["label"] for r in train})
    missing_train = [l for l in C.TARGET_DOMAINS if l not in present_train]
    if missing_train:
        print(f"WARNING: no training examples for {missing_train}; the model cannot predict them.")
    rng = random.Random(args.seed)
    make = (lambda: EmbedModel(args.embed)) if args.embed else (lambda: TfidfModel())

    # ---- 1) masked-silver check: hold out 20% of keyword-labelled docs, test with ALL keywords hidden
    import hashlib
    bucket = lambda r: int(hashlib.md5(str(r.get("doc", r["text"][:50])).encode()).hexdigest()[:4], 16) / 0xFFFF
    weak = [r for r in train if kind(r) == "weak" and r["label"] != OTHER]
    silver_test = [r for r in weak if bucket(r) < 0.2]
    silver_rows = []
    if silver_test:
        sub_train = [r for r in train if not (kind(r) == "weak" and r["label"] != OTHER and bucket(r) < 0.2)]
        m = make().fit(train_texts(sub_train, rng, args.mask), [r["label"] for r in sub_train],
                       [WEIGHTS[kind(r)] for r in sub_train])
        masked = [mask_keywords(r["text"], 1.0, rng) for r in silver_test]
        pred = decide(m.proba(masked), m.classes_, 0.0)
        for lab in sorted({r["label"] for r in silver_test}):
            idx = [i for i, r in enumerate(silver_test) if r["label"] == lab]
            silver_rows.append({"class": lab, "held_out": len(idx),
                                "recall_with_keywords_hidden": round(sum(pred[i] == lab for i in idx) / len(idx), 3)})

    # ---- 2) choose regularisation + threshold on dev, then train the final model on train
    w = [WEIGHTS[kind(r)] for r in train]
    best = None
    dev_true = [r["label"] for r in dev]
    for c_reg in ([4.0] if args.embed else [1.0, 4.0, 16.0]):
        m = (EmbedModel(args.embed, c_reg) if args.embed else TfidfModel(c_reg))
        m.fit(train_texts(train, random.Random(args.seed), args.mask), [r["label"] for r in train], w)
        pdev = m.proba([fold(r["text"]) for r in dev]) if dev else None
        measured = {r["label"] for r in dev} - {OTHER}
        for th in ([0.3, 0.4, 0.5, 0.6, 0.7] if dev else [0.5]):
            ths = {c: (th if c in measured else args.unmeasured_threshold) for c in m.classes_}
            f = scores(dev_true, decide(pdev, m.classes_, ths), labels)[1] if dev else 0.0
            if best is None or f > best[0]:
                best = (f, c_reg, ths, m)
    dev_f1, c_reg, threshold, model = best
    print(f"Chosen: C={c_reg}, thresholds={threshold} (dev macro-F1 {dev_f1})")

    # ---- 3) test on gold labels; compare with keyword rules
    y_true = [r["label"] for r in test]
    y_model = decide(model.proba([fold(r["text"]) for r in test]), model.classes_, threshold)
    y_kw = [keyword_baseline(r["text"]) for r in test]
    rows_m, f1_m, acc_m = scores(y_true, y_model, labels)
    rows_k, f1_k, acc_k = scores(y_true, y_kw, labels)
    by_src = []
    for src in sorted({r.get("source", "") for r in test}):
        idx = [i for i, r in enumerate(test) if r.get("source", "") == src]
        yt = [y_true[i] for i in idx]
        by_src.append({"test set": src, "n": len(idx),
                       "classifier macro-F1": scores(yt, [y_model[i] for i in idx], labels)[1],
                       "keyword-rules macro-F1": scores(yt, [y_kw[i] for i in idx], labels)[1]})
    no_gold = [l for l in C.TARGET_DOMAINS if l not in set(y_true)]

    # ---- save
    import joblib
    C.ROOT.joinpath("models").mkdir(exist_ok=True)
    out = C.ROOT / "models" / f"{C.LANG}_domain_clf.joblib"
    joblib.dump({"model": model, "classes": model.classes_, "threshold": threshold, "lang": C.LANG,
                 "domains": C.TARGET_DOMAINS, "embed": args.embed}, out)

    cmp_rows = []
    for rm in rows_m:
        rk = next((r for r in rows_k if r["class"] == rm["class"]), {})
        cmp_rows.append({"class": rm["class"], "support": rm["support"],
                         "classifier P": rm["precision"], "classifier R": rm["recall"], "classifier F1": rm["f1"],
                         "keywords P": rk.get("precision"), "keywords R": rk.get("recall"), "keywords F1": rk.get("f1")})
    train_counts = Counter((r["label"], kind(r)) for r in train)
    tc = [{"class": l, **{k: train_counts.get((l, k), 0) for k in ("gold", "teacher", "weak")}} for l in labels]
    md = [f"# Domain classifier - {C.LANG_NAME} ({C.LANG})\n",
          f"Model: {'embeddings ' + args.embed if args.embed else 'TF-IDF (word + character n-grams)'} + "
          f"logistic regression; C={c_reg}\n",
          "Confidence needed per domain (below it the text goes to 'other'): "
          + ", ".join(f"{k} {v}" for k, v in threshold.items() if k != OTHER) + "\n",
          f"Classes: {', '.join(labels)}\n",
          "## Training examples by label source\n", md_table(tc),
          f"\n## Test on human (gold) labels: {len(test):,} texts\n",
          f"**Classifier macro-F1 {f1_m} (accuracy {acc_m}) vs keyword rules macro-F1 {f1_k} (accuracy {acc_k})**\n",
          md_table(cmp_rows), "\n### By test set\n", md_table(by_src),
          "\n### Confusion matrix (classifier)\n", md_table(confusion(y_true, y_model, labels))]
    if silver_rows:
        md += ["\n## Masked-silver check (keyword-labelled classes, keywords hidden)\n",
               "Recall on held-out keyword-labelled texts after removing every keyword. Well above "
               "chance means the model uses context; near 0 means it only learned the keywords.\n",
               md_table(silver_rows)]
    if no_gold:
        md += [f"\n**Not measured on gold labels: {', '.join(no_gold)}.** Run "
               f"`python clf3_predict.py --lang {C.LANG} --check-sheet`, mark the predictions Y/N, then "
               f"`python clf2_train.py --lang {C.LANG} --gold reviews/{C.LANG}_clf_check.xlsx`."]
    (C.REPORTS / f"{C.LANG}_clf_report.md").write_text("\n".join(md), encoding="utf-8")
    with open(C.REPORTS / f"{C.LANG}_clf_report.csv", "w", newline="", encoding="utf-8") as f:
        wr = csv.DictWriter(f, fieldnames=list(cmp_rows[0]) if cmp_rows else ["class"])
        wr.writeheader()
        wr.writerows(cmp_rows)
    print("\n".join(md))
    print(f"\n-> {out.relative_to(C.ROOT)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
