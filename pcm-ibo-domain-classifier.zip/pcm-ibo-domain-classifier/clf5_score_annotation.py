"""
CLASSIFIER STEP 5 - Score the filled annotation sheet.

    python clf5_score_annotation.py --lang pcm
    python clf5_score_annotation.py --lang pcm --sheet my_filled_sheet.xlsx

Input : reviews/<lang>_annotation.xlsx (or --sheet), filled in:
          correct      Y if the predicted domain is right, N if not
          true_domain  the right domain when correct = N ("other" = none of the five)
Output: reports/<lang>_annotation_score.md / .csv

Reports, per predicted domain: precision (share of items marked correct), and an estimate of
how many of the selected tokens are really in that domain (selected tokens x precision).
With 10 items per domain each precision has a wide margin of error (roughly +/-25 points),
so read it as a sanity check, not a final score. The same sheet can be fed back into
training:  python clf2_train.py --lang pcm --gold reviews/pcm_annotation.xlsx --train-on-gold
"""
import argparse
import csv
import math
import sys
from collections import Counter

import config as C
from common import md_table

OTHER = "other"


def wilson(k, n, z=1.96):
    """95% confidence interval for a proportion (works for small n)."""
    if n == 0:
        return (0.0, 0.0)
    p = k / n
    den = 1 + z * z / n
    mid = (p + z * z / (2 * n)) / den
    half = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / den
    return (max(0.0, mid - half), min(1.0, mid + half))


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--sheet", default=str(C.REVIEWS / f"{C.LANG}_annotation.xlsx"))
    args = ap.parse_args()

    from openpyxl import load_workbook
    try:
        ws = load_workbook(args.sheet, read_only=True).active
    except FileNotFoundError:
        sys.exit(f"{args.sheet} not found.")
    it = ws.iter_rows(values_only=True)
    head = [str(h) for h in next(it)]
    rows = [dict(zip(head, r)) for r in it if r and r[0]]
    done = [r for r in rows if str(r.get("correct") or "").strip().upper()[:1] in ("Y", "N")]
    if not done:
        sys.exit("No rows marked yet: fill the 'correct' column (Y/N).")

    classes = C.TARGET_DOMAINS + [OTHER]
    selected = {}
    fin = C.REPORTS / f"{C.LANG}_final_dataset.csv"
    if fin.exists():
        with open(fin, encoding="utf-8") as f:
            selected = {r["domain"]: int(r["tokens_selected"]) for r in csv.DictReader(f)}

    table, conf = [], Counter()
    for c in classes:
        sub = [r for r in done if r.get("predicted") == c]
        k = sum(str(r["correct"]).strip().upper().startswith("Y") for r in sub)
        lo, hi = wilson(k, len(sub))
        row = {"predicted": c, "annotated": len(sub), "correct": k,
               "precision": round(k / len(sub), 2) if sub else "",
               "95% interval": f"{lo:.2f}-{hi:.2f}" if sub else ""}
        if c in selected and sub:
            row["selected_tokens"] = selected[c]
            row["est. tokens truly in domain"] = int(selected[c] * k / len(sub))
        table.append(row)
        for r in sub:
            truth = c if str(r["correct"]).strip().upper().startswith("Y") else (str(r.get("true_domain") or "?").strip() or "?")
            conf[(c, truth)] += 1
    acc = sum(r["correct"] for r in table) / max(1, sum(r["annotated"] for r in table))
    cm = [{"predicted \\ true": p, **{t: conf.get((p, t), 0) for t in classes + ["?"]}} for p in classes]
    md = [f"# Annotation score - {C.LANG_NAME}\n",
          f"{len(done)} of {len(rows)} items annotated. **Overall accuracy: {acc:.2f}**\n",
          md_table(table),
          "\n`?` = marked N without choosing the true domain.\n",
          "## Predicted vs true domain\n", md_table(cm),
          "\nWith about 10 items per domain each precision has a wide margin (see the 95% interval)."]
    (C.REPORTS / f"{C.LANG}_annotation_score.md").write_text("\n".join(md), encoding="utf-8")
    with open(C.REPORTS / f"{C.LANG}_annotation_score.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["predicted", "annotated", "correct", "precision", "95% interval",
                                          "selected_tokens", "est. tokens truly in domain"])
        w.writeheader()
        w.writerows(table)
    print("\n".join(md))
    return 0


if __name__ == "__main__":
    sys.exit(main())
