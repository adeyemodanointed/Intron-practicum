"""
STEP 3 - Clean, filter, language-check and de-duplicate; assign final IDs.

    python step3_clean.py --lang ibo
    python step3_clean.py --lang ibo --glotlid   # use the GlotLID language-ID model (needs fasttext)

Input : data/formatted/<lang>_*.jsonl
Output: data/clean/<lang>_clean.jsonl       one merged file for the language, shared schema
        data/pnc/<lang>_pnc_labels.jsonl    token-level punctuation + case labels per record
        reports/<lang>_cleaning_log.csv     what was removed, per source and reason
        reports/<lang>_langcheck_calibration.csv  how well the language check separates
                                              the language from English (MAFAND pairs)

Cleaning process (documented for the "Proposed cleaning process" task):
  1. Unicode NFC normalisation (diacritics and language-specific letters preserved)
  2. Remove zero-width/control characters, HTML tags/entities, URLs, e-mails, @mentions
  3. Normalise curly quotes -> " and ', long dashes -> -, ellipsis -> ...
  4. Collapse repeated punctuation (!!! -> !), fix spaces around punctuation, whitespace
  5. Strict-domain languages (Igbo): drop records outside the target domains
  6. Drop malformed records: empty, mojibake/encoding damage, mostly non-letters,
     fewer than MIN_TOKENS_PER_RECORD tokens, run-ons over 3 x MAX_TOKENS_PER_RECORD
  7. Language check: drop records judged English or another language (e.g. Yoruba);
     keep "uncertain" but mark them
  8. De-duplicate at SENTENCE level: a record is dropped when >= 80% of its tokens are in
     sentences already kept (case/punctuation/spacing ignored). This catches the same
     BBC article split differently by different datasets. Sources are processed in
     priority order, so the domain-labelled copy is the one kept
  9. Assign IDs  <lang>_<domain>_<0001>  in a deterministic order
  10. Extract punctuation labels (O, COMMA, PERIOD, QUESTION, EXCLAMATION) + case labels
"""
import argparse
import csv
import sys
from collections import Counter, defaultdict

import config as C
from common import (alpha_ratio, clean_text, dedup_key, format_notes, has_mojibake, lang_check,
                    n_tokens, parse_notes, pnc_labels, read_jsonl, sentence_key, split_sentences,
                    write_jsonl)

MIN_SENT_TOKENS_FOR_DEDUP = 4   # very short sentences ("Ọ kwuru.") are too common to count


def load_glotlid():
    try:
        import fasttext
        from huggingface_hub import hf_hub_download
    except ImportError:
        sys.exit("GlotLID needs:  pip install fasttext-wheel huggingface_hub")
    path = hf_hub_download(repo_id="cis-lmu/glotlid", filename="model.bin")
    model = fasttext.load_model(path)

    def predict(text: str) -> tuple[str, float]:
        labels, probs = model.predict(text.replace("\n", " "), k=1)
        lab = labels[0].replace("__label__", "")
        return lab, float(probs[0])
    return predict


def calibrate_langcheck() -> None:
    path = C.DATA / "calibration" / f"{C.LANG}_pairs.jsonl"
    if not path.exists():
        return
    counts = {f"{C.LANG}_side": Counter(), "en_side": Counter()}
    for pair in read_jsonl(path):
        counts[f"{C.LANG}_side"][lang_check(pair["lang"])[0]] += 1
        counts["en_side"][lang_check(pair["en"])[0]] += 1
    rows = []
    for side, c in counts.items():
        tot = sum(c.values()) or 1
        other = sum(v for k, v in c.items() if k.startswith("other:"))
        rows.append({"text_side": side, "n": tot,
                     f"judged_{C.LANG}_pct": round(100 * c[C.LANG] / tot, 1),
                     "judged_eng_pct": round(100 * c["eng"] / tot, 1),
                     "judged_other_lang_pct": round(100 * other / tot, 1),
                     "uncertain_pct": round(100 * c["uncertain"] / tot, 1)})
    out = C.REPORTS / f"{C.LANG}_langcheck_calibration.csv"
    with open(out, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)
    print(f"[calibration] language check on MAFAND aligned pairs -> {out.relative_to(C.ROOT)}")
    for r in rows:
        print(f"    {r['text_side']:9s} n={r['n']:,}  {C.LANG} {r[f'judged_{C.LANG}_pct']}%  "
              f"eng {r['judged_eng_pct']}%  other {r['judged_other_lang_pct']}%  uncertain {r['uncertain_pct']}%")


def near_duplicate(text: str, seen: dict, source_id: int):
    """Return (is_dup, duplicated_source_id, sentence_keys_with_lengths)."""
    sents = [(sentence_key(s), n_tokens(s)) for s in split_sentences(text)]
    long_ = [(k, n) for k, n in sents if n >= MIN_SENT_TOKENS_FOR_DEDUP]
    if not long_:
        long_ = [(sentence_key(text), n_tokens(text))]
    total = sum(n for _, n in long_) or 1
    hit_tokens, hit_src = 0, Counter()
    for k, n in long_:
        if k in seen:
            hit_tokens += n
            hit_src[seen[k]] += n
    if hit_tokens / total >= C.NEAR_DUP_OVERLAP:
        return True, hit_src.most_common(1)[0][0], long_
    return False, None, long_


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--glotlid", action="store_true", help="use GlotLID instead of the marker-word heuristic")
    ap.add_argument("--use-classifier", action="store_true",
                    help="take domains from the trained classifier (run clf1-clf3 first); human dataset "
                         "labels are kept")
    args = ap.parse_args()
    C.REPORTS.mkdir(parents=True, exist_ok=True)

    glot = load_glotlid() if args.glotlid else None
    files = sorted(C.FORMATTED_DIR.glob(f"{C.LANG}_*.jsonl"),
                   key=lambda p: C.SOURCES.get(p.stem[len(C.LANG) + 1:], {}).get("priority", 99))
    if not files:
        sys.exit("No formatted files found. Run step2_format.py first.")

    seen: dict[bytes, int] = {}        # sentence hash -> index of the source that kept it
    src_names: list[str] = []
    log = defaultdict(Counter)
    dup_with = defaultdict(Counter)    # source -> Counter(source it duplicated)
    kept = []

    for f in files:
        source = f.stem[len(C.LANG) + 1:]
        src_names.append(source)
        sid = len(src_names) - 1
        print(f"[{source}] cleaning {f.name}")
        preds = None
        if args.use_classifier:
            pf = C.DATA / "classified" / f"{C.LANG}_{source}.preds.jsonl"
            if not pf.exists():
                sys.exit(f"{pf.name} not found - run clf3_predict.py --lang {C.LANG} first.")
            preds = list(read_jsonl(pf))
        for line_no, r in enumerate(read_jsonl(f)):
            if preds is not None:
                p = preds[line_no] if line_no < len(preds) else {}
                method = parse_notes(r["notes"]).get("domain_method", "")
                if method not in ("source_label", "recording_title") and p.get("pred"):
                    if p["pred"] in C.TARGET_DOMAINS:
                        r["domain"] = p["pred"]
                    else:
                        r["domain"] = C.OUT_OF_SCOPE if C.STRICT_DOMAINS else \
                            C.SOURCES.get(source, {}).get("fallback_domain", "general")
                    n = parse_notes(r["notes"])
                    n.update(domain_method="classifier", clf_prob=p.get("prob"))
                    n.pop("kw", None)
                    r["notes"] = format_notes(n)
            L = log[source]
            L["formatted"] += 1
            L["tokens_before"] += n_tokens(r["raw_text"])
            if C.STRICT_DOMAINS and r["domain"] not in C.TARGET_DOMAINS:
                L["drop_out_of_domain"] += 1
                continue
            text = clean_text(r["raw_text"])
            ntok = n_tokens(text)
            if not text:
                L["drop_empty"] += 1
                continue
            if has_mojibake(text):
                L["drop_encoding"] += 1
                continue
            if alpha_ratio(text) < C.MIN_ALPHA_RATIO:
                L["drop_non_alpha"] += 1
                continue
            if ntok < C.MIN_TOKENS_PER_RECORD:
                L["drop_too_short"] += 1
                continue
            if ntok > 3 * C.MAX_TOKENS_PER_RECORD:
                L["drop_run_on"] += 1
                continue
            label, _, _ = lang_check(text)
            notes = parse_notes(r["notes"])
            if glot:
                g_lab, g_p = glot(text)
                notes["glotlid"] = f"{g_lab}:{g_p:.2f}"
                if g_lab == C.GLOTLID_LABEL:
                    label = C.LANG
                elif g_lab == "eng_Latn":
                    label = "eng"
                elif g_p >= 0.7:
                    label = f"other:{g_lab}"
                else:
                    label = "uncertain"
            if label == "eng":
                L["drop_english"] += 1
                continue
            if label.startswith("other:"):
                L["drop_other_language"] += 1
                continue
            if label == "uncertain":
                L["kept_lang_uncertain"] += 1
            notes["langcheck"] = label
            is_dup, dup_sid, keys = near_duplicate(text, seen, sid)
            if is_dup:
                if dup_sid == sid:
                    L["drop_dup_within_source"] += 1
                else:
                    L["drop_dup_other_source"] += 1
                    dup_with[source][src_names[dup_sid]] += 1
                continue
            for k, _ in keys:
                seen.setdefault(k, sid)
            r["raw_text"] = text
            r["notes"] = format_notes(notes)
            kept.append(r)
            L["kept"] += 1
            L["tokens_after"] += ntok
        print(f"    kept {log[source]['kept']:,} of {log[source]['formatted']:,} records")

    # ---- final IDs: deterministic (source priority, then input order), per domain counter
    counters = Counter()
    for r in kept:
        counters[r["domain"]] += 1
        r["id"] = f"{C.LANG}_{r['domain']}_{counters[r['domain']]:04d}"

    out = C.CLEAN_DIR / f"{C.LANG}_clean.jsonl"
    write_jsonl(out, kept)
    print(f"\n-> {out.relative_to(C.ROOT)}  ({len(kept):,} records)")

    def pnc_rows():
        for r in kept:
            words, punct, case = pnc_labels(r["raw_text"])
            yield {"id": r["id"], "words": words, "punct": punct, "case": case}
    pnc_out = C.PNC_DIR / f"{C.LANG}_pnc_labels.jsonl"
    write_jsonl(pnc_out, pnc_rows())
    print(f"-> {pnc_out.relative_to(C.ROOT)}  (PnC labels)")

    # ---- cleaning log
    cols = ["source", "formatted", "drop_out_of_domain", "drop_empty", "drop_encoding", "drop_non_alpha", "drop_too_short",
            "drop_run_on", "drop_english", "drop_other_language", "drop_dup_within_source", "drop_dup_other_source",
            "kept_lang_uncertain", "kept", "tokens_before", "tokens_after", "duplicates_of"]
    log_out = C.REPORTS / f"{C.LANG}_cleaning_log.csv"
    with open(log_out, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=cols)
        w.writeheader()
        for source, L in log.items():
            row = {c: L.get(c, 0) for c in cols}
            row["source"] = source
            row["duplicates_of"] = "; ".join(f"{k}:{v}" for k, v in dup_with[source].items())
            w.writerow(row)
    print(f"-> {log_out.relative_to(C.ROOT)}")

    calibrate_langcheck()
    return 0


if __name__ == "__main__":
    sys.exit(main())
