"""
CLASSIFIER STEP 4 - Build the final dataset (up to 50,000 tokens per domain) and the
60-item annotation sheet.

    python clf4_select.py --lang pcm
    python clf4_select.py --lang ibo --tokens 50000 --per-domain 10

Input : data/clean/<lang>_clean.jsonl        (from step3_clean.py --use-classifier)
        data/formatted/<lang>_*.jsonl + data/classified/<lang>_*.preds.jsonl  (for "other" items)
Output: data/final/<lang>_domain_dataset.jsonl   shared JSONL schema, target domains only
        reports/<lang>_final_dataset.md / .csv     tokens per domain vs target, label sources
        reviews/<lang>_annotation.xlsx             10 texts per domain + 10 "other" = 60 items

Selection, per domain, until the token target is reached:
  1. texts whose domain comes from a human label (MasakhaNEWS topic, UD Naija recording title);
  2. then classifier-labelled texts, most confident first.
Records rejected in a manual review (review_status = rejected) and sources marked
in_final_dataset = False in langs/<lang>.py (e.g. Common Voice prompts) are never selected. If a domain
has fewer tokens than the target, everything available is kept and the shortfall is reported.

The annotation sheet checks the classifier's work: the 10 texts per domain are drawn from the
classifier-labelled part of the final dataset (human-labelled ones are already trusted), and
the 10 "other" texts from those the classifier rejected. Short texts (one or two sentences)
are preferred so each item is quick to judge. Score it afterwards with clf5_score_annotation.py.
"""
import argparse
import csv
import random
import sys
from collections import Counter, defaultdict

import config as C
from common import (clean_text, md_table, n_tokens, parse_notes, read_jsonl, split_sentences,
                    write_jsonl)

OTHER = "other"
HUMAN = ("source_label", "recording_title")


def short_first(items, rng, max_tokens=40):
    """Prefer texts of at most two sentences and `max_tokens` words; random within each group."""
    rng.shuffle(items)
    return sorted(items, key=lambda r: (0 if (len(split_sentences(r["text"])) <= 2
                                             and n_tokens(r["text"]) <= max_tokens) else 1,
                                        n_tokens(r["text"]) if n_tokens(r["text"]) > max_tokens else 0))


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--tokens", type=int, default=C.TARGET_TOKENS_PER_DOMAIN, help="token target per domain")
    ap.add_argument("--per-domain", type=int, default=10, help="annotation items per domain (and for 'other')")
    ap.add_argument("--seed", type=int, default=21)
    ap.add_argument("--new-sheet", action="store_true",
                    help="overwrite an annotation sheet that already has answers in it")
    args = ap.parse_args()
    rng = random.Random(args.seed)

    clean = C.CLEAN_DIR / f"{C.LANG}_clean.jsonl"
    if not clean.exists():
        sys.exit("Run step3_clean.py --use-classifier first.")
    excluded = {k for k, s in C.SOURCES.items() if s.get("in_final_dataset", True) is False}
    recs = [r for r in read_jsonl(clean)
            if r.get("review_status") != "rejected" and r["source_dataset"] not in excluded]
    if excluded:
        print(f"Not used in the final dataset (see in_final_dataset in langs/{C.LANG}.py): {sorted(excluded)}")

    # ---- 1) select up to the token target per domain
    pools = defaultdict(list)
    for r in recs:
        if r["domain"] not in C.TARGET_DOMAINS:
            continue
        n = parse_notes(r["notes"])
        method = n.get("domain_method", "")
        human = method in HUMAN
        prob = 1.0 if human else float(n.get("clf_prob") or 0.0)
        pools[r["domain"]].append((0 if human else 1, -prob, rng.random(), r, method))
    final, rows = [], []
    for d in C.TARGET_DOMAINS:
        got, by_src, by_method = 0, Counter(), Counter()
        for _, _, _, r, method in sorted(pools.get(d, []), key=lambda t: t[:3]):
            if got >= args.tokens:
                break
            nt = n_tokens(r["raw_text"])
            final.append(r)
            got += nt
            by_src[r["source_dataset"]] += nt
            by_method["human label" if method in HUMAN else
                      ("classifier" if method == "classifier" else "keywords")] += nt
        rows.append({"domain": d, "tokens_selected": got, "target": args.tokens,
                     "target_met": "yes" if got >= args.tokens else f"no (short by {args.tokens - got:,})",
                     "records": sum(1 for r in final if r["domain"] == d),
                     "from_human_labels": by_method["human label"],
                     "from_classifier": by_method["classifier"],
                     "from_keywords": by_method["keywords"],
                     "sources": "; ".join(f"{k}:{v:,}" for k, v in by_src.most_common())})
    out = C.DATA / "final" / f"{C.LANG}_domain_dataset.jsonl"
    write_jsonl(out, final)

    with open(C.REPORTS / f"{C.LANG}_final_dataset.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)
    total = sum(r["tokens_selected"] for r in rows)
    md = [f"# Final {C.LANG_NAME} dataset: up to {args.tokens:,} tokens per domain\n",
          f"Total: **{total:,} tokens**, {len(final):,} records -> `data/final/{C.LANG}_domain_dataset.jsonl`\n",
          md_table(rows)]
    short = [r["domain"] for r in rows if r["tokens_selected"] < args.tokens]
    if short:
        md.append(f"\n**Below target: {', '.join(short)}.** Add raw text for these domains (more sources, "
                  f"or extend the keyword lists / run the teacher on more texts), then rerun from clf1.")
    (C.REPORTS / f"{C.LANG}_final_dataset.md").write_text("\n".join(md), encoding="utf-8")
    print("\n".join(md))

    # ---- 2) annotation sheet: 10 per domain (classifier-labelled first) + 10 "other"
    sheet = C.REVIEWS / f"{C.LANG}_annotation.xlsx"
    if sheet.exists() and not args.new_sheet:
        from openpyxl import load_workbook
        ws0 = load_workbook(sheet, read_only=True).active
        rows0 = list(ws0.iter_rows(values_only=True))
        col = list(rows0[0]).index("correct") if rows0 and "correct" in rows0[0] else None
        if col is not None and any(r[col] for r in rows0[1:]):
            print(f"\n{sheet.name} already has answers - not overwritten (use --new-sheet to replace it).")
            return 0
    items = []
    for d in C.TARGET_DOMAINS:
        cand = [{"id": r["id"], "source": r["source_dataset"], "text": r["raw_text"], "predicted": d,
                 "label_source": parse_notes(r["notes"]).get("domain_method", "")}
                for r in final if r["domain"] == d]
        clf_only = [c for c in cand if c["label_source"] == "classifier"]
        pick = short_first(clf_only, rng)[:args.per_domain]
        if len(pick) < args.per_domain:          # not enough classifier-labelled texts: top up
            rest = [c for c in cand if c["label_source"] != "classifier"]
            pick += short_first(rest, rng)[:args.per_domain - len(pick)]
        items += pick
    others = []
    for f in sorted(C.FORMATTED_DIR.glob(f"{C.LANG}_*.jsonl")):
        source = f.stem[len(C.LANG) + 1:]
        pf = C.DATA / "classified" / f"{C.LANG}_{source}.preds.jsonl"
        if not pf.exists():
            continue
        for i, (r, p) in enumerate(zip(read_jsonl(f), read_jsonl(pf))):
            method = parse_notes(r["notes"]).get("domain_method", "")
            if p.get("pred") == OTHER and method not in HUMAN:
                t = clean_text(r["raw_text"])
                if n_tokens(t) >= C.MIN_TOKENS_PER_RECORD:
                    others.append({"id": f"{source}:{i + 1}", "source": source, "text": t,
                                   "predicted": OTHER, "label_source": "classifier"})
    items += short_first(others, rng)[:args.per_domain]
    rng.shuffle(items)

    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.worksheet.datavalidation import DataValidation
    cols = ["id", "source", "label_source", "text", "predicted", "correct", "true_domain", "comment"]
    wb = Workbook()
    ws = wb.active
    ws.title = "annotation"
    ws.append(cols)
    for it in items:
        ws.append([it.get(c, "") for c in cols])
    for cell in ws[1]:
        cell.font = Font(bold=True)
        cell.fill = PatternFill("solid", fgColor="D9E2F3")
    for col, wdt in zip("ABCDEFGH", (26, 18, 14, 90, 18, 10, 20, 30)):
        ws.column_dimensions[col].width = wdt
    for row in ws.iter_rows(min_row=2):
        row[3].alignment = Alignment(wrap_text=True, vertical="top")
    classes = C.TARGET_DOMAINS + [OTHER]
    yn = DataValidation(type="list", formula1='"Y,N"', allow_blank=True)
    dom = DataValidation(type="list", formula1='"' + ",".join(classes) + '"', allow_blank=True)
    ws.add_data_validation(yn)
    ws.add_data_validation(dom)
    yn.add(f"F2:F{len(items) + 1}")
    dom.add(f"G2:G{len(items) + 1}")
    ws.freeze_panes = "D2"
    wb.save(sheet)
    cnt = Counter(it["predicted"] for it in items)
    print(f"\nAnnotation sheet: {len(items)} items ({', '.join(f'{k} {v}' for k, v in cnt.items())}) "
          f"-> {sheet.relative_to(C.ROOT)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
