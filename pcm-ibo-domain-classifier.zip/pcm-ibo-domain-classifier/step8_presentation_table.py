"""
STEP 8 - Build the consolidated Monday presentation table for one language.

    python step8_presentation_table.py

One row per dataset: language, domain(s), licence, token target / actual count,
punctuation quality, language check, validation result and a use/reject decision
with the reason. Rows are added for speech-transcript sets (gap analysis only) and
for candidates that were considered but not downloaded.

Outputs: reports/<lang>_dataset_table.csv / .md / .xlsx  (the .xlsx also has a
"Domain coverage" sheet with tokens per domain against the 200k target).

The decision column is a RECOMMENDATION from fixed rules (config.py); the team makes
the final call in the meeting.
"""
import csv
import sys
from collections import Counter, defaultdict

import config as C
from common import md_table, n_tokens, read_jsonl


def read_csv(path):
    if not path.exists():
        return []
    with open(path, encoding="utf-8") as f:
        text = f.read().split("\n\n")[0]      # validation csv has a second table after a blank line
    return list(csv.DictReader(text.splitlines()))


def fnum(x, default=None):
    try:
        return float(x)
    except (TypeError, ValueError):
        return default


def main() -> int:
    stats = {r["dataset"]: r for r in read_csv(C.REPORTS / f"{C.LANG}_punctuation_stats.csv")}
    if not stats:
        sys.exit("Run step5_stats.py first.")
    val = {r["group"].split("=", 1)[1]: r for r in read_csv(C.REPORTS / f"{C.LANG}_validation_summary.csv")
           if r.get("group", "").startswith("source_dataset=")}
    cov = read_csv(C.REPORTS / f"{C.LANG}_domain_coverage.csv")

    dom_tokens = defaultdict(Counter)
    clean = C.CLEAN_DIR / f"{C.LANG}_clean.jsonl"
    for r in read_jsonl(clean):
        dom_tokens[r["source_dataset"]][r["domain"]] += n_tokens(r["raw_text"])

    rows = []
    for key, src in sorted(C.SOURCES.items(), key=lambda kv: kv[1]["priority"]):
        st = stats.get(key)
        base = {"language": f"{C.LANG_NAME} ({C.LANG})", "dataset": src["title"], "key": key,
                "hosting": src["hosting"], "licence": src["license"],
                "research_use": "yes" if src["research_ok"] else "no",
                "commercial_use": "yes" if src["commercial_ok"] else "no (NC)",
                "token_target": f"{C.TARGET_TOKENS_TOTAL:,} per language; {C.TARGET_TOKENS_PER_DOMAIN:,} per domain"}
        if not st:
            rows.append({**base, "domains (tokens)": "", "actual_tokens": "", "pct_of_language_target": "",
                         "punct_quality": "", "punct_per_100_tokens": "", "terminal_end_pct": "",
                         "langcheck_lang_pct": "", "validation_acceptance_pct": "",
                         "decision": "pending", "reason": "not downloaded/processed yet - run steps 1-5"})
            continue
        doms = dom_tokens.get(key, Counter())
        dom_str = ", ".join(f"{d}{'*' if d in C.TARGET_DOMAINS else ''} ({v:,})" for d, v in doms.most_common())
        tokens = int(fnum(st["tokens"], 0))
        pq, lang_pct = st["punct_quality"], fnum(st.get("langcheck_lang_pct"))
        acc = fnum(val.get(key, {}).get("acceptance_pct"))
        reasons = []
        if pq == "poor":
            decision = "reject"
            reasons.append("punctuation too sparse for PnC")
        elif acc is not None and acc < C.DECISION_MIN_ACCEPTANCE_PCT:
            decision = "reject"
            reasons.append(f"manual acceptance {acc}% < {C.DECISION_MIN_ACCEPTANCE_PCT}%")
            checks = {c: fnum(val[key].get(f"{c}_yes_pct")) for c in
                      (C.REVIEW_LANG_COL, "domain_correct", "punctuation_ok", "text_quality_ok")}
            checks = {c: v for c, v in checks.items() if v is not None}
            if checks:
                worst = min(checks, key=checks.get)
                reasons.append(f"weakest check: {worst} ({checks[worst]}% yes)"
                               + (" - fix domain labels rather than drop the data" if worst == "domain_correct" else ""))
        elif lang_pct is not None and lang_pct < C.DECISION_MIN_LANG_PCT:
            decision = "review"
            reasons.append(f"only {lang_pct}% clearly {C.LANG_NAME} by heuristic - check with GlotLID/manual review")
        elif acc is None:
            decision = "use (pending validation)"
        else:
            decision = "use"
        if src["domain_method"] == "keyword":
            reasons.append("domains (partly) from keyword classifier - confirm in manual review")
        if src["license"].lower().startswith("no licence"):
            reasons.append("no licence stated: confirm research use with the dataset authors/Intron")
        elif not src["commercial_ok"]:
            reasons.append("non-commercial licence: research use only, confirm with Intron")
        rows.append({**base, "domains (tokens)": dom_str, "actual_tokens": f"{tokens:,}",
                     "pct_of_language_target": f"{100 * tokens / C.TARGET_TOKENS_TOTAL:.1f}%",
                     "punct_quality": pq, "punct_per_100_tokens": st["punct_per_100_tokens"],
                     "terminal_end_pct": st["terminal_end_pct"],
                     "langcheck_lang_pct": st.get("langcheck_lang_pct", ""),
                     "validation_acceptance_pct": "" if acc is None else acc,
                     "decision": decision, "reason": "; ".join(reasons)})

    for name, st in stats.items():
        if st.get("role", "").startswith("speech"):
            rows.append({"language": f"{C.LANG_NAME} ({C.LANG})", "dataset": name, "key": name,
                         "hosting": "", "licence": "", "research_use": "yes", "commercial_use": "",
                         "token_target": "n/a", "domains (tokens)": "speech transcripts",
                         "actual_tokens": f"{int(fnum(st['tokens'], 0)):,}", "pct_of_language_target": "n/a",
                         "punct_quality": st["punct_quality"], "punct_per_100_tokens": st["punct_per_100_tokens"],
                         "terminal_end_pct": st["terminal_end_pct"], "langcheck_lang_pct": "",
                         "validation_acceptance_pct": "",
                         "decision": "reject for text corpus",
                         "reason": "no/limited punctuation; use to measure the clean-text vs ASR-transcript gap"})
    for name, why in C.CONSIDERED_NOT_USED:
        rows.append({"language": f"{C.LANG_NAME} ({C.LANG})", "dataset": name, "key": "", "hosting": "",
                     "licence": "", "research_use": "", "commercial_use": "", "token_target": "",
                     "domains (tokens)": "", "actual_tokens": "", "pct_of_language_target": "",
                     "punct_quality": "", "punct_per_100_tokens": "", "terminal_end_pct": "",
                     "langcheck_lang_pct": "", "validation_acceptance_pct": "", "decision": "reject",
                     "reason": why})

    cols = ["language", "dataset", "domains (tokens)", "licence", "commercial_use", "token_target",
            "actual_tokens", "pct_of_language_target", "punct_quality", "punct_per_100_tokens",
            "terminal_end_pct", "langcheck_lang_pct", "validation_acceptance_pct", "decision", "reason"]
    with open(C.REPORTS / f"{C.LANG}_dataset_table.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=cols, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)
    md = [f"# Consolidated dataset table - {C.LANG_NAME}\n",
          "`*` = one of the five project domains.\n", md_table(rows, cols),
          "\n## Domain coverage\n", md_table(cov)]
    (C.REPORTS / f"{C.LANG}_dataset_table.md").write_text("\n".join(md), encoding="utf-8")

    try:
        from openpyxl import Workbook
        from openpyxl.styles import Alignment, Font, PatternFill
        wb = Workbook()
        for title, data, c in (("Datasets", rows, cols), ("Domain coverage", cov, list(cov[0]) if cov else [])):
            ws = wb.active if title == "Datasets" else wb.create_sheet(title)
            ws.title = title
            ws.append(c)
            for r in data:
                ws.append([r.get(k, "") for k in c])
            for cell in ws[1]:
                cell.font = Font(bold=True)
                cell.fill = PatternFill("solid", fgColor="D9E2F3")
                cell.alignment = Alignment(wrap_text=True, vertical="top")
            for i, k in enumerate(c, 1):
                width = 45 if k in ("reason", "licence", "domains (tokens)", "sources") else 16
                ws.column_dimensions[ws.cell(1, i).column_letter].width = width
            for row in ws.iter_rows(min_row=2):
                for cell in row:
                    cell.alignment = Alignment(wrap_text=True, vertical="top")
            ws.freeze_panes = "C2"
        wb.save(C.REPORTS / f"{C.LANG}_dataset_table.xlsx")
    except ImportError:
        pass
    print("\n".join(md))
    print(f"-> reports/{C.LANG}_dataset_table.csv / .md / .xlsx")
    return 0


if __name__ == "__main__":
    sys.exit(main())
