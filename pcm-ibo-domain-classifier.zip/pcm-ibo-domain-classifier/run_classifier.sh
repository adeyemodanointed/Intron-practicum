#!/usr/bin/env bash
# Train the domain classifier for ONE language and build its final dataset + annotation sheet.
#   bash run_classifier.sh pcm            # Nigerian Pidgin
#   bash run_classifier.sh ibo            # Igbo
#   bash run_classifier.sh pcm --teacher  # also use the zero-shot teacher (GPU recommended)
set -e
cd "$(dirname "$0")"
L="${1:-pcm}"
TEACH=""
if [ "$2" == "--teacher" ]; then TEACH="--teacher nli --teacher-max 5000"; fi
python step1_download.py --lang "$L"
python step2_format.py --lang "$L"
PYTHONUNBUFFERED=1 python clf1_build_dataset.py --lang "$L" $TEACH
python clf2_train.py --lang "$L"
python clf3_predict.py --lang "$L"
python step3_clean.py --lang "$L" --use-classifier
python step4_validate_schema.py --lang "$L"
python clf4_select.py --lang "$L"
echo
echo "Done. Final dataset: data/final/${L}_domain_dataset.jsonl"
echo "Annotate reviews/${L}_annotation.xlsx, then: python clf5_score_annotation.py --lang $L"
