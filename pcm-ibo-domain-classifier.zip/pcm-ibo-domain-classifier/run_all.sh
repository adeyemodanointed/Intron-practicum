#!/usr/bin/env bash
# Runs the whole pipeline for one language.   Usage:  bash run_all.sh ibo   (or pcm)
# Add --with-asr to step 1 below if you also want the Pidgin ASR transcripts (~956 MB).
set -e
cd "$(dirname "$0")"
L="${1:-pcm}"
python step1_download.py --lang "$L"
python step2_format.py --lang "$L"
python step3_clean.py --lang "$L"
python step4_validate_schema.py --lang "$L"
python step5_stats.py --lang "$L"
python step6_review_sample.py --lang "$L"
python step8_presentation_table.py --lang "$L"
echo
echo "Done. Open reports/${L}_dataset_table.xlsx and reviews/${L}_review_primary.xlsx"
echo "After the manual review:  python step7_score_reviews.py --lang $L && python step8_presentation_table.py --lang $L"
