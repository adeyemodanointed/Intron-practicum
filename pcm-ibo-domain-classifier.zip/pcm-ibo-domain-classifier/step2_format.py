"""
STEP 2 - Read each downloaded source and write it in the SHARED JSONL schema.

    python step2_format.py --lang ibo
    python step2_format.py --lang pcm --sources masakhanews_pcm ud_naija_nsc

Output: data/formatted/<lang>_<source>.jsonl  (not cleaned yet; IDs are assigned in step 3)

What happens per source:
  * documents are read from the raw files;
  * each document gets a domain: the dataset's own label when it maps to a domain
    (MasakhaNEWS / WURA categories, see LABEL_MAP in langs/<lang>.py), otherwise the
    keyword classifier in common.classify_domain. For languages with STRICT_DOMAINS
    (Igbo), text outside the target domains is labelled out_of_scope and dropped in step 3;
  * documents are split into records of whole sentences (<= MAX_TOKENS_PER_RECORD);
  * provenance goes into `notes` as "key=value; key=value".

Speech transcripts (UD Naija spoken layer, ASR set) go to data/aux/ for the PnC gap
analysis only. They are not mixed into the text corpus.
"""
import argparse
import json
import re
import sys
from collections import Counter
from pathlib import Path

import config as C
from common import (TERMINAL_RE, chunk_document, classify_domain, detokenize, format_notes,
                    make_record, n_tokens, write_jsonl)

NSC_TITLE_RE = re.compile(r"_\d+_(.+)_[A-Z]{2}$")


def split_from_name(name: str) -> str:
    n = name.lower()
    for key, split in (("train", "train"), ("dev", "dev"), ("valid", "dev"), ("val", "dev"),
                       ("test", "test")):
        if key in n:
            return split
    return "train"

# ------------------------------------------------------------------ readers
# Each reader yields dicts: {doc_id, text, split, label, meta}


def read_masakhanews(raw: Path):
    import pandas as pd
    for f in sorted(raw.glob("*.tsv")):
        df = pd.read_csv(f, sep="\t", dtype=str, keep_default_na=False)
        df.columns = [c.strip().lower() for c in df.columns]
        label_col = "category" if "category" in df.columns else "label"
        for i, row in df.iterrows():
            # headline is skipped on purpose: headlines rarely end in punctuation and
            # would distort the punctuation statistics.
            yield {"doc_id": f"{f.stem}_{i}", "text": row.get("text", ""),
                   "split": split_from_name(f.stem), "label": row.get(label_col, "").strip().lower(),
                   "meta": {"url": row.get("url", "")}}


def read_mafand(raw: Path, src: dict, calib_out: list):
    side = src.get("side", C.LANG)
    for f in sorted(raw.glob("*.json")):
        with open(f, encoding="utf-8") as fh:
            for i, line in enumerate(fh):
                if not line.strip():
                    continue
                tr = json.loads(line)["translation"]
                tgt, en = tr.get(side, ""), tr.get("en", "")
                calib_out.append({"lang": tgt, "en": en})
                yield {"doc_id": f"{f.stem}_{i}", "text": tgt, "split": split_from_name(f.stem),
                       "label": None, "meta": {}}


# Markup of the NaijaSynCor spoken layer: // and < > prosodic boundaries, { | } pile-ups,
# |c |r tags, & interrupted words, # paragraph marks. "?" and "!" mark question or
# exclamation intonation; ASR does not output them, so they are removed too.
NSC_MARKUP_RE = re.compile(r"\|\w*|//\+?|>\+|[#<>{}()\[\]/=~^&+?!]")


def nsc_markup_to_plain(text: str) -> str:
    """Strip NaijaSynCor transcription markup -> ASR-like plain transcript (for the gap analysis)."""
    t = NSC_MARKUP_RE.sub(" ", text)
    return re.sub(r"\s+", " ", t).strip()


def read_ud_naija(raw: Path, aux_out: list):
    for f in sorted(raw.glob("*.conllu")):
        split = split_from_name(f.stem)
        docs: dict[str, list[str]] = {}
        order: list[str] = []
        sent = {}
        with open(f, encoding="utf-8") as fh:
            for line in fh:
                line = line.rstrip("\n")
                if line.startswith("# sent_id"):
                    sent = {"sent_id": line.split("=", 1)[1].strip()}
                elif line.startswith("# text_ortho"):
                    sent["ortho"] = line.split("=", 1)[1].strip()
                elif line.startswith("# text ="):
                    sent["spoken"] = line.split("=", 1)[1].strip()
                elif line == "" and sent.get("sent_id"):
                    doc = sent["sent_id"].rsplit("__", 1)[0]
                    if doc not in docs:
                        docs[doc] = []
                        order.append(doc)
                    if sent.get("ortho"):
                        docs[doc].append(sent["ortho"])
                    if sent.get("spoken"):
                        aux_out.append({"doc": doc, "split": split,
                                        "text": nsc_markup_to_plain(sent["spoken"])})
                    sent = {}
        for doc in order:
            # e.g. ABJ_GWA_08_David-Lifestory_MG -> title "David-Lifestory"
            m = NSC_TITLE_RE.search(doc)
            title = m.group(1) if m else ""
            # utterances are joined with spaces so records hold several utterances
            yield {"doc_id": doc, "text": " ".join(docs[doc]), "split": split, "label": None,
                   "domain": getattr(C, "NSC_TITLE_DOMAINS", {}).get(title),
                   "domain_method": "recording_title", "per_chunk": True, "meta": {"title": title}}


def read_xlsum(raw: Path):
    for f in sorted(raw.rglob("*.jsonl")):
        with open(f, encoding="utf-8") as fh:
            for i, line in enumerate(fh):
                if not line.strip():
                    continue
                d = json.loads(line)
                yield {"doc_id": str(d.get("id", f"{f.stem}_{i}")), "text": d.get("text", ""),
                       "split": split_from_name(f.stem), "label": None,
                       "meta": {"url": d.get("url", "")}}


def _read_lines(raw: Path, src: dict) -> list[str]:
    member = src.get("zip_member")
    if member:
        import zipfile
        zf = next(iter(sorted(raw.glob("*.zip"))), None)
        if zf is None:
            return []
        with zipfile.ZipFile(zf) as z:
            return z.read(member).decode("utf-8", errors="replace").splitlines()
    lines = []
    for f in sorted(raw.glob("*.txt")):
        lines += f.read_text(encoding="utf-8", errors="replace").splitlines()
    return lines


def read_lines(raw: Path, src: dict):
    """One-sentence-per-line files.

    merge_lines=True (default): consecutive lines are joined into pseudo-documents; a line
    without final punctuation (a headline or caption) is dropped when drop_unterminated is
    set and also starts a new document, because it usually marks a new story.
    merge_lines=False: every line is its own record (e.g. Common Voice prompts).
    """
    lines = _read_lines(raw, src)
    tok = src.get("tokenized", False)
    merge = src.get("merge_lines", True)
    drop_unterm = src.get("drop_unterminated", False)
    run, n_doc, skipped = [], 0, 0

    def flush():
        nonlocal run, n_doc
        if run:
            n_doc += 1
            # pseudo-documents may join several short stories: label each record on its own
            doc = {"doc_id": f"lines_{n_doc}", "text": " ".join(run), "split": "train",
                   "label": None, "per_chunk": True, "meta": {}}
            run = []
            return doc
        return None

    for line in lines:
        line = line.strip()
        if tok:
            line = detokenize(line)
        if not line:
            continue
        terminated = bool(TERMINAL_RE.search(line))
        if drop_unterm and not terminated:
            skipped += 1
            d = flush()
            if d:
                yield d
            continue
        if not merge:
            n_doc += 1
            yield {"doc_id": f"line_{n_doc}", "text": line, "split": "train", "label": None, "meta": {}}
            continue
        run.append(line)
        if sum(n_tokens(x) for x in run) >= 400:    # keep pseudo-documents article-sized
            yield flush()
    d = flush()
    if d:
        yield d
    if skipped:
        print(f"    dropped {skipped:,} lines without final punctuation (headlines/captions)")


def read_wura(raw: Path):
    for f in sorted(raw.rglob("*.jsonl")):
        split = "dev" if "eval" in f.parts else "train"
        with open(f, encoding="utf-8") as fh:
            for i, line in enumerate(fh):
                if not line.strip():
                    continue
                d = json.loads(line)
                yield {"doc_id": str(d.get("id", f"{f.stem}_{i}")),
                       "text": d.get("content") or d.get("text") or "", "split": split,
                       "label": str(d.get("category") or "").strip().lower() or None,
                       "meta": {"url": d.get("url", "")}}


def _iter_parquet(raw: Path, text_cols=("text",)):
    import pyarrow.parquet as pq
    for f in sorted(raw.rglob("*.parquet")):
        pf = pq.ParquetFile(f)
        cols = [c for c in pf.schema_arrow.names]
        tcol = next((c for c in text_cols if c in cols), None)
        if tcol is None:
            print(f"    skip {f.name}: none of {text_cols} in columns {cols}")
            continue
        keep = [c for c in (tcol, "id", "url", "title") if c in cols]
        for batch in pf.iter_batches(batch_size=2000, columns=keep):
            for row in batch.to_pylist():
                yield f, tcol, row


def read_wikipedia(raw: Path):
    for f, tcol, row in _iter_parquet(raw):
        yield {"doc_id": str(row.get("id", "")), "text": row[tcol] or "", "split": "train",
               "label": None, "meta": {"url": row.get("url", ""), "title": row.get("title", "")}}


def read_fineweb(raw: Path):
    for f, tcol, row in _iter_parquet(raw):
        split = "test" if "test" in f.parts else "train"
        yield {"doc_id": str(row.get("id", "")), "text": row[tcol] or "", "split": split,
               "label": None, "meta": {"url": row.get("url", "")}}


def read_asr_transcripts(raw: Path):
    import pyarrow.parquet as pq
    for f in sorted(raw.rglob("*.parquet")):
        names = pq.ParquetFile(f).schema_arrow.names
        col = next((c for c in ("sentence", "transcription", "text") if c in names), None)
        if not col:
            continue
        # read only the transcript column, never the audio
        for i, s in enumerate(pq.read_table(f, columns=[col]).column(col).to_pylist()):
            yield {"doc": f"{f.stem}_{i}", "split": split_from_name(f.stem), "text": s or ""}

# ------------------------------------------------------------------ formatting


def docs_to_records(key: str, docs, src: dict):
    """Assign domains and split documents into records.

    Order of evidence: a domain given by the reader (UD Naija recording titles) ->
    the dataset's own label if LABEL_MAP maps it -> keyword classifier (per document, or
    per record for long mixed-topic documents).
    """
    stats = Counter()
    fallback = src.get("fallback_domain", "general")
    for d in docs:
        text = (d["text"] or "").strip()
        if not text:
            stats["empty_docs"] += 1
            continue
        stats["docs"] += 1
        note = {"doc": d["doc_id"]}
        per_chunk = False
        label = d.get("label")
        if d.get("domain"):
            domain = d["domain"]
            note.update(domain_method=d.get("domain_method", "reader"))
        elif label and label in C.LABEL_MAP:
            domain = C.LABEL_MAP[label]
            note.update(domain_method="source_label", orig_label=label)
        elif label and C.UNMAPPED_LABEL_POLICY == "keep":
            domain = fallback
            note.update(domain_method="source_label", orig_label=label)
        elif d.get("per_chunk"):
            per_chunk = True
        else:
            domain, evidence = classify_domain(text, fallback)
            note.update(domain_method="keyword", kw=evidence)
            if label:
                note.update(orig_label=label)
        note.update({k: v for k, v in d["meta"].items() if v})
        chunks = chunk_document(text)
        for ci, chunk in enumerate(chunks):
            n = dict(note, chunk=f"{ci + 1}/{len(chunks)}")
            if per_chunk:
                domain, evidence = classify_domain(chunk, fallback)
                n.update(domain_method="keyword_chunk", kw=evidence)
            yield make_record(domain, chunk, key, d["split"], src["license"], format_notes(n))
            stats["records"] += 1
            stats[f"dom:{domain}"] += 1
    doms = ", ".join(f"{k[4:]} {v:,}" for k, v in sorted(stats.items(), key=lambda kv: -kv[1]) if k.startswith("dom:"))
    print(f"    documents: {stats['docs']:,}  records: {stats['records']:,}  empty docs skipped: {stats['empty_docs']:,}")
    if doms:
        print(f"    domains: {doms}")


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--sources", nargs="*", default=list(C.SOURCES))
    args = ap.parse_args()

    calib, nsc_spoken = [], []
    for key in args.sources:
        src = C.SOURCES.get(key)
        raw = C.RAW_DIR / key
        if src is None:
            print(f"[{key}] unknown source, skipped")
            continue
        if not raw.exists() or not any(raw.rglob("*")):
            print(f"[{key}] no raw files in {raw} - run step1 first (skipped)")
            continue
        print(f"[{key}] formatting ...")
        kind = src.get("reader")
        reader = {
            "masakhanews": lambda: read_masakhanews(raw),
            "mafand": lambda: read_mafand(raw, src, calib),
            "ud_naija": lambda: read_ud_naija(raw, nsc_spoken),
            "xlsum": lambda: read_xlsum(raw),
            "wikipedia": lambda: read_wikipedia(raw),
            "fineweb": lambda: read_fineweb(raw),
            "lines": lambda: read_lines(raw, src),
            "wura": lambda: read_wura(raw),
        }.get(kind)
        if reader is None:
            print(f"    no reader called '{kind}' (skipped)")
            continue
        try:
            out = C.FORMATTED_DIR / f"{C.LANG}_{key}.jsonl"
            n = write_jsonl(out, docs_to_records(key, reader(), src))
            if n == 0:
                out.unlink()
                print(f"    no records produced - is the download complete? (no file written)")
            else:
                print(f"    -> {out.relative_to(C.ROOT)}")
        except Exception as e:
            print(f"    FAILED: {type(e).__name__}: {e}")

    # ---- auxiliary files (not part of the corpus)
    if calib:
        n = write_jsonl(C.DATA / "calibration" / f"{C.LANG}_pairs.jsonl", calib)
        print(f"[aux] {n:,} aligned {C.LANG}/en sentence pairs for language-check calibration")
    if nsc_spoken:
        recs = (make_record("conversation", r["text"], "ud_naija_nsc_spoken", r["split"],
                            C.SOURCES["ud_naija_nsc"]["license"], format_notes({"doc": r["doc"]}))
                for r in nsc_spoken if r["text"])
        n = write_jsonl(C.AUX_DIR / f"{C.LANG}_ud_naija_nsc_spoken.jsonl", recs)
        print(f"[aux] {n:,} UD Naija spoken-layer transcripts (markup stripped)")
    for akey, asrc in C.AUX_SOURCES.items():
        araw = C.RAW_DIR / akey
        if asrc.get("reader") == "asr_parquet" and araw.exists() and any(araw.rglob("*.parquet")):
            recs = (make_record("general_news", r["text"], akey, r["split"], asrc["license"],
                                format_notes({"doc": r["doc"]}))
                    for r in read_asr_transcripts(araw) if r["text"])
            n = write_jsonl(C.AUX_DIR / f"{C.LANG}_{akey}.jsonl", recs)
            print(f"[aux] {n:,} ASR human transcripts ({akey})")
    return 0


if __name__ == "__main__":
    sys.exit(main())
