"""
CLASSIFIER STEP 3 - Label every text with the trained classifier.

    python clf3_predict.py --lang pcm
    python clf3_predict.py --lang pcm --check-sheet          # + a quick yes/no sheet (20 per class)

Input : data/formatted/<lang>_*.jsonl, models/<lang>_domain_clf.joblib
Output: data/classified/<lang>_<source>.preds.jsonl   one line per formatted record (same order)
        reports/<lang>_clf_coverage.md / .csv         tokens per domain: classifier vs keyword rules
        reviews/<lang>_clf_check.xlsx                 (with --check-sheet) predictions to confirm

Then rebuild the corpus with the classifier's domains:
        python step3_clean.py --lang pcm --use-classifier
Human dataset labels (MasakhaNEWS topics, UD Naija titles) are always kept; the classifier
decides only the texts that had no human label.

The check sheet is the cheap substitute for annotation: ~20 predictions per domain, each a
quick Y/N ("is this prediction right?"). It measures precision for domains that have no
human labels (e.g. law, telecoms), and the answers can be fed back with clf2 --gold.
"""
import argparse
import csv
import random
import sys
from collections import Counter, defaultdict

import config as C
from clf_models import OTHER, decide  # noqa: F401  (decide used below; classes needed for unpickling)
from common import clean_text, fold, md_table, n_tokens, parse_notes, read_jsonl, write_jsonl


def to_class(domain):
    return domain if domain in C.TARGET_DOMAINS else OTHER


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--check-sheet", action="store_true")
    ap.add_argument("--per-class", type=int, default=50, help="predictions per domain in the sheet")
    ap.add_argument("--random", type=int, default=100,
                    help="extra texts drawn at random (measures what the classifier misses)")
    ap.add_argument("--seed", type=int, default=7)
    args = ap.parse_args()

    import joblib
    path = C.ROOT / "models" / f"{C.LANG}_domain_clf.joblib"
    if not path.exists():
        sys.exit("No model. Run clf1_build_dataset.py and clf2_train.py first.")
    bundle = joblib.load(path)
    model, th = bundle["model"], bundle["threshold"]
    if sorted(bundle["domains"]) != sorted(C.TARGET_DOMAINS):
        print(f"NOTE: model was trained for domains {bundle['domains']}; using those.")
        C.TARGET_DOMAINS = list(bundle["domains"])

    files = sorted(C.FORMATTED_DIR.glob(f"{C.LANG}_*.jsonl"))
    cov = defaultdict(Counter)       # source -> Counter((method, class) -> tokens)
    pool = defaultdict(list)         # predicted class -> candidates for the check sheet
    for f in files:
        source = f.stem[len(C.LANG) + 1:]
        recs = list(read_jsonl(f))
        texts = [clean_text(r["raw_text"]) for r in recs]
        ok = [i for i, t in enumerate(texts) if n_tokens(t) >= C.MIN_TOKENS_PER_RECORD]
        preds = [None] * len(recs)
        for start in range(0, len(ok), 5000):
            idx = ok[start:start + 5000]
            proba = model.proba([fold(texts[i]) for i in idx])
            labs = decide(proba, model.classes_, th)
            for i, lab, row in zip(idx, labs, proba):
                preds[i] = {"pred": lab, "prob": round(float(row[model.classes_.index(lab)]), 3)}
        out = C.DATA / "classified" / f"{C.LANG}_{source}.preds.jsonl"
        write_jsonl(out, (p or {"pred": None, "prob": None} for p in preds))
        for i, (r, p) in enumerate(zip(recs, preds)):
            if not p:
                continue
            ntok = n_tokens(texts[i])
            method = parse_notes(r["notes"]).get("domain_method", "")
            human = method in ("source_label", "recording_title")
            final = to_class(r["domain"]) if human else p["pred"]
            cov[source][("classifier", final)] += ntok
            kw = to_class(r["domain"]) if r["domain"] != C.OUT_OF_SCOPE else OTHER
            cov[source][("keywords", kw)] += ntok
            if not human and p["pred"] != OTHER:
                pool[p["pred"]].append({"id": f"{source}:{i + 1}", "source": source, "text": texts[i],
                                        "predicted": p["pred"], "prob": p["prob"]})
            elif not human:
                pool[OTHER].append({"id": f"{source}:{i + 1}", "source": source, "text": texts[i],
                                    "predicted": OTHER, "prob": p["prob"]})
        print(f"[{source}] {len(ok):,} texts classified -> {out.relative_to(C.ROOT)}")

    classes = C.TARGET_DOMAINS + [OTHER]
    rows = []
    for method in ("keywords", "classifier"):
        tot = Counter()
        for source in cov:
            for (m, c), v in cov[source].items():
                if m == method:
                    tot[c] += v
        rows.append({"domains from": method, **{c: tot.get(c, 0) for c in classes}})
    md = [f"# Tokens per domain: keyword rules vs classifier - {C.LANG_NAME}\n",
          "Human dataset labels are kept in both rows; the difference is only in texts without them. "
          f"Target is {C.TARGET_TOKENS_PER_DOMAIN:,} tokens per domain.\n", md_table(rows)]
    (C.REPORTS / f"{C.LANG}_clf_coverage.md").write_text("\n".join(md), encoding="utf-8")
    with open(C.REPORTS / f"{C.LANG}_clf_coverage.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)
    print("\n".join(md))

    if args.check_sheet:
        rng = random.Random(args.seed)
        sheet = []
        taken = set()
        for c in classes:
            cands = sorted(pool.get(c, []), key=lambda r: r["prob"])
            if not cands:
                continue
            # spread over the confidence range: low, middle and high-confidence predictions
            k = min(args.per_class, len(cands))
            step = len(cands) / k
            for j in range(k):
                r = dict(cands[int(j * step + rng.random() * step)], sample_type="by_prediction")
                if r["id"] not in taken:
                    taken.add(r["id"])
                    sheet.append(r)
        everything = [r for c in pool for r in pool[c] if r["id"] not in taken]
        for r in rng.sample(everything, min(args.random, len(everything))):
            sheet.append(dict(r, sample_type="random"))
        rng.shuffle(sheet)
        C.REVIEWS.mkdir(exist_ok=True)
        cols = ["id", "source", "sample_type", "text", "predicted", "prob", "correct", "true_domain", "comment"]
        from openpyxl import Workbook
        from openpyxl.styles import Alignment, Font, PatternFill
        from openpyxl.worksheet.datavalidation import DataValidation
        wb = Workbook()
        ws = wb.active
        ws.title = "check"
        ws.append(cols)
        for r in sheet:
            ws.append([r.get(c, "") for c in cols])
        for cell in ws[1]:
            cell.font = Font(bold=True)
            cell.fill = PatternFill("solid", fgColor="D9E2F3")
        for col, wdt in zip("ABCDEFGHI", (22, 18, 14, 90, 18, 8, 10, 20, 30)):
            ws.column_dimensions[col].width = wdt
        for row in ws.iter_rows(min_row=2):
            row[3].alignment = Alignment(wrap_text=True, vertical="top")
        yn = DataValidation(type="list", formula1='"Y,N"', allow_blank=True)
        dom = DataValidation(type="list", formula1='"' + ",".join(classes) + '"', allow_blank=True)
        ws.add_data_validation(yn)
        ws.add_data_validation(dom)
        yn.add(f"G2:G{len(sheet) + 1}")
        dom.add(f"H2:H{len(sheet) + 1}")
        ws.freeze_panes = "D2"
        out = C.REVIEWS / f"{C.LANG}_clf_check.xlsx"
        wb.save(out)
        print(f"\nCheck sheet: {len(sheet)} predictions -> {out.relative_to(C.ROOT)}")
        print("  correct = Y if the predicted domain is right; if N, pick the right one in true_domain.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
