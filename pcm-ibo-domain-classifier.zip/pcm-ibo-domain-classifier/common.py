"""
Shared helpers: reading/writing JSONL, tokenising, cleaning, sentence splitting, the
keyword domain classifier, the heuristic language check and punctuation statistics.

IMPORTANT for cross-language comparability: every language owner should count tokens
and punctuation with `word_tokens()` and `punct_profile()` from this file, so the
consolidated statistics table uses one counting method.
"""
from __future__ import annotations

import hashlib
import html
import json
import re
import unicodedata
from collections import Counter
from pathlib import Path
from typing import Iterable, Iterator

import config as C

# --------------------------------------------------------------------------------------
# JSONL I/O
# --------------------------------------------------------------------------------------

def read_jsonl(path: str | Path) -> Iterator[dict]:
    with open(path, "r", encoding="utf-8") as f:
        for line_no, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            try:
                yield json.loads(line)
            except json.JSONDecodeError as e:
                raise ValueError(f"{path}:{line_no}: invalid JSON ({e})") from e


def write_jsonl(path: str | Path, records: Iterable[dict]) -> int:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    n = 0
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        for r in records:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
            n += 1
    return n


def make_record(domain: str, text: str, source: str, split: str, license_: str,
                notes: str = "", rec_id: str = "") -> dict:
    """Build one record in the shared schema, fields in the agreed order."""
    return {
        "id": rec_id,
        "language": C.LANG,
        "domain": domain,
        "raw_text": text,
        "source_dataset": source,
        "source_split": split,
        "license": license_,
        "review_status": "unreviewed",
        "notes": notes,
    }


def parse_notes(notes: str) -> dict:
    """Notes are stored as 'key=value; key=value' so they stay one string (shared schema)."""
    out = {}
    for part in (notes or "").split(";"):
        if "=" in part:
            k, v = part.split("=", 1)
            out[k.strip()] = v.strip()
    return out


def format_notes(d: dict) -> str:
    return "; ".join(f"{k}={v}" for k, v in d.items() if v not in (None, ""))

# --------------------------------------------------------------------------------------
# Tokenisation (THE shared counting method)
# --------------------------------------------------------------------------------------
# A word token is a run of letters/digits (any script, diacritics included), optionally
# joined by an internal apostrophe or hyphen, and numbers keep their separators:
#   "don't" -> 1, "Ekiti-based" -> 1, "N1,000.50" -> 1, "2,000 pipo" -> 2.
# Punctuation is never counted as a word token, and a comma inside a number is not
# treated as a COMMA label.
WORD_RE = re.compile(r"[^\W_]+(?:['\-][^\W_]+|(?<=\d)[.,]\d+)*", re.UNICODE)


def word_tokens(text: str) -> list[str]:
    return WORD_RE.findall(text)


def n_tokens(text: str) -> int:
    return len(WORD_RE.findall(text))

# --------------------------------------------------------------------------------------
# Cleaning
# --------------------------------------------------------------------------------------
ZERO_WIDTH = dict.fromkeys(map(ord, "​‌‍⁠﻿­"), None)
DOUBLE_QUOTES = dict.fromkeys(map(ord, "“”„‟«»″"), '"')
SINGLE_QUOTES = dict.fromkeys(map(ord, "‘’‚‛′ʼ`"), "'")
DASHES = dict.fromkeys(map(ord, "–—―−"), "-")
URL_RE = re.compile(r"(https?://\S+|www\.\S+)", re.I)
EMAIL_RE = re.compile(r"\b[\w.+-]+@[\w-]+\.[\w.-]+\b")
MENTION_RE = re.compile(r"(?<!\w)@\w+")
TAG_RE = re.compile(r"<[^>]{1,200}>")
MOJIBAKE_RE = re.compile(r"(Ã[\x80-\xbf]|â€|Â[\x80-\xbf]|�)")


def clean_text(text: str) -> str:
    """Deterministic, language-safe cleaning.

    Uses NFC (not NFKD/ASCII folding) so diacritics and language-specific letters
    (e.g. Yoruba ẹ ọ ṣ with tone marks) are preserved exactly.
    """
    if not text:
        return ""
    t = html.unescape(text)
    t = unicodedata.normalize("NFC", t)
    t = t.translate(ZERO_WIDTH)
    # control characters except newline/tab
    t = "".join(ch for ch in t if ch in "\n\t" or unicodedata.category(ch)[0] != "C")
    t = TAG_RE.sub(" ", t)
    t = URL_RE.sub(" ", t)
    t = EMAIL_RE.sub(" ", t)
    t = MENTION_RE.sub(" ", t)
    t = t.translate(DOUBLE_QUOTES).translate(SINGLE_QUOTES).translate(DASHES)
    t = t.replace("…", "...")
    t = re.sub(r"\.{4,}", "...", t)                 # "....." -> "..."
    t = re.sub(r"([!?,;:])\1+", r"\1", t)           # "!!!" -> "!", ",," -> ","
    t = re.sub(r"[ \t]+([.,!?;:])", r"\1", t)       # "word ." -> "word."
    t = re.sub(r"([,;:!?])(?=[^\W\d_])", r"\1 ", t)  # "word,word" -> "word, word"
    t = re.sub(r'"\s*"', '"', t)                    # empty quote pairs
    t = re.sub(r"[ \t]+", " ", t)
    t = re.sub(r"\s*\n\s*", "\n", t)
    return t.strip()


def has_mojibake(text: str) -> bool:
    return bool(MOJIBAKE_RE.search(text))


def alpha_ratio(text: str) -> float:
    chars = [c for c in text if not c.isspace()]
    if not chars:
        return 0.0
    return sum(c.isalpha() for c in chars) / len(chars)


def fold(text: str) -> str:
    """Lower-case and remove diacritics (ị->i, ọ->o, ụ->u, ṅ->n, tone marks). Used ONLY for
    matching keywords/markers - the stored text keeps every diacritic."""
    t = unicodedata.normalize("NFD", text.lower().replace("\u2019", "'"))
    return "".join(ch for ch in t if not unicodedata.combining(ch))


_CLOSE_PUNCT = ".,;:!?)]"


def _fix_double_quotes(t: str) -> str:
    parts = t.split('"')
    if len(parts) < 3 or len(parts) % 2 == 0:       # no quotes, or unbalanced: leave alone
        return t
    out = parts[0]
    for i, p in enumerate(parts[1:], 1):
        if i % 2 == 1:                               # opening quote
            out = (out.rstrip() + ' "' if out.strip() else '"') + p.lstrip()
        else:                                        # closing quote
            nxt = p.lstrip()
            sep = "" if (not nxt or nxt[0] in _CLOSE_PUNCT) else " "
            out = out.rstrip() + '"' + sep + nxt
    return out


def detokenize(text: str) -> str:
    """Re-join text that was stored tokenised ("word , word" / "na- ahụ" / "n’ ihe")."""
    t = re.sub(r"\s+([.,!?;:%)\]])", r"\1", text)
    t = re.sub(r"([(\[])\s+", r"\1", t)
    t = re.sub(r"(?<![^\W\d_])([nNmM])([\u2019'])\s+(?=[^\W\d_])", r"\1\2", t)  # Igbo elision n' / m'
    t = re.sub(r"(?<=[^\W\d_])-\s+(?=[^\W\d_])", "-", t)                        # na- ahụ -> na-ahụ
    t = re.sub(r"(^|\s)'\s+([^']+?)\s+'(?=\s|[.,;:!?]|$)", r"\1'\2'", t)         # ' word ' -> 'word'
    t = _fix_double_quotes(t)
    return re.sub(r"[ \t]+", " ", t).strip()


def sentence_key(text: str) -> bytes:
    """8-byte hash of a sentence ignoring case, punctuation and ALL spacing."""
    t = re.sub(r"[\W_]+", "", unicodedata.normalize("NFC", text).lower())
    return hashlib.blake2b(t.encode("utf-8"), digest_size=8).digest()


def dedup_key(text: str) -> str:
    """Normalised hash: case, punctuation and spacing differences do not matter."""
    t = unicodedata.normalize("NFC", text).lower()
    t = re.sub(r"[^\w\s]", "", t)
    t = re.sub(r"\s+", " ", t).strip()
    return hashlib.sha1(t.encode("utf-8")).hexdigest()

# --------------------------------------------------------------------------------------
# Sentence splitting and chunking
# --------------------------------------------------------------------------------------
SENT_SPLIT_RE = re.compile(r'(?<=[.!?])["\')\]]?\s+(?=["\'(\[]?[A-Z0-9\u00C0-\u024F\u1E00-\u1EFF])')


def split_sentences(paragraph: str) -> list[str]:
    parts = SENT_SPLIT_RE.split(paragraph.strip())
    return [p.strip() for p in parts if p and p.strip()]


def chunk_document(text: str, max_tokens: int = C.MAX_TOKENS_PER_RECORD) -> list[str]:
    """Split a document into records of whole sentences, never crossing paragraphs.

    Each record holds consecutive sentences up to `max_tokens` word tokens, which keeps
    records a sensible size for manual review, PnC training and TTS.
    """
    chunks: list[str] = []
    for para in re.split(r"\n+", text):
        para = para.strip()
        if not para:
            continue
        cur: list[str] = []
        cur_len = 0
        for sent in split_sentences(para):
            n = n_tokens(sent)
            if cur and cur_len + n > max_tokens:
                chunks.append(" ".join(cur))
                cur, cur_len = [], 0
            cur.append(sent)
            cur_len += n
        if cur:
            chunks.append(" ".join(cur))
    return chunks

# --------------------------------------------------------------------------------------
# Keyword domain classifier (only for sources without domain labels)
# --------------------------------------------------------------------------------------

def _compile_keywords() -> dict[str, re.Pattern]:
    pats = {}
    for dom, words in C.DOMAIN_KEYWORDS.items():
        alts = sorted({re.escape(fold(w)) for w in words}, key=len, reverse=True)
        pats[dom] = re.compile(r"(?<![\w])(" + "|".join(alts) + r")(?![\w])")
    return pats


_KW = _compile_keywords()


def keyword_scores(text: str) -> tuple[str, int, int, int]:
    """Best keyword domain over ALL keyword lists: (domain, hits, runner_up_hits, distinct)."""
    low = fold(text)
    found = {dom: p.findall(low) for dom, p in _KW.items()}
    ranked = sorted(found.items(), key=lambda kv: len(kv[1]), reverse=True)
    (best, hits), (_, nxt) = ranked[0], ranked[1]
    return best, len(hits), len(nxt), len(set(hits))


def keyword_confident(best: str, s1: int, s2: int, distinct: int) -> bool:
    return (s1 >= C.DOMAIN_MIN_HITS and distinct >= C.DOMAIN_MIN_DISTINCT
            and s1 >= C.DOMAIN_MIN_MARGIN * max(s2, 1))


def mask_keywords(text: str, prob: float, rng) -> str:
    """Delete domain keywords (on folded text) with probability `prob`.

    Used when training on keyword-derived labels, so the classifier must learn the
    surrounding words instead of memorising the keywords that produced the label.
    """
    low = fold(text)
    for p in _KW.values():
        low = p.sub(lambda m: " " if rng.random() < prob else m.group(0), low)
    return re.sub(r"\s+", " ", low).strip()


def classify_domain(text: str, fallback: str) -> tuple[str, str]:
    """Return (domain, evidence). Needs DOMAIN_MIN_HITS hits and a clear margin.

    Matching ignores case and diacritics. With STRICT_DOMAINS, a text whose best match is
    a non-target domain (politics, religion, ...) is returned as out_of_scope.
    """
    low = fold(text)
    found = {dom: p.findall(low) for dom, p in _KW.items()}
    scores = {dom: len(v) for dom, v in found.items()}
    ranked = sorted(scores.items(), key=lambda kv: kv[1], reverse=True)
    (best, s1), (_, s2) = ranked[0], ranked[1]
    distinct = len(set(found[best]))
    if (s1 >= C.DOMAIN_MIN_HITS and distinct >= C.DOMAIN_MIN_DISTINCT
            and s1 >= C.DOMAIN_MIN_MARGIN * max(s2, 1)):
        if C.STRICT_DOMAINS and best not in C.TARGET_DOMAINS:
            return C.OUT_OF_SCOPE, f"kw:{best}={s1}(not a target domain)"
        return best, f"kw:{best}={s1},next={s2}"
    return fallback, f"kw:none(best={best}={s1},next={s2})"

# --------------------------------------------------------------------------------------
# Heuristic language check (target language vs English vs neighbouring languages)
# --------------------------------------------------------------------------------------
_LANG_MARKERS = {fold(w) for w in C.LANG_MARKERS}
_OTHER = {code: ({fold(w) for w in spec.get("words", ())}, spec.get("chars", ""))
          for code, spec in C.OTHER_LANG_MARKERS.items()}
_EVIDENCE_CHARS = getattr(C, "LANG_EVIDENCE_CHARS", "")


def lang_check(text: str) -> tuple[str, float, float]:
    """Return (label, target_ratio, english_ratio).

    label is the language code (e.g. 'pcm', 'ibo'), 'eng', 'other:<code>' or 'uncertain'.
    A token counts for a language if it is one of its marker words (compared without
    diacritics) or contains one of its characteristic letters.
    """
    raw = [t.lower() for t in word_tokens(text)]
    if len(raw) < C.LANGCHECK_MIN_TOKENS:
        return "uncertain", 0.0, 0.0
    folded = [fold(t) for t in raw]
    n = len(raw)
    tgt = sum((f in _LANG_MARKERS) or (bool(_EVIDENCE_CHARS) and any(c in r for c in _EVIDENCE_CHARS))
              for r, f in zip(raw, folded)) / n
    eng = sum(r in C.ENG_MARKERS for r in raw) / n
    scores = {C.LANG: tgt, "eng": eng}
    for code, (words, chars) in _OTHER.items():
        scores[f"other:{code}"] = sum((f in words) or (bool(chars) and any(c in r for c in chars))
                                      for r, f in zip(raw, folded)) / n
    best = max(scores, key=scores.get)
    if tgt >= C.LANGCHECK_MIN_RATIO and tgt >= scores[best]:
        return C.LANG, tgt, eng
    if scores[best] >= C.LANGCHECK_MIN_RATIO and best != C.LANG:
        return best, tgt, eng
    return "uncertain", tgt, eng

# --------------------------------------------------------------------------------------
# Punctuation statistics and PnC labels
# --------------------------------------------------------------------------------------
PUNCT_MARKS = {
    "period": ".", "comma": ",", "question": "?", "exclamation": "!",
    "colon": ":", "semicolon": ";", "dquote": '"', "squote_standalone": "'",
    "paren": "(", "hyphen_dash": "-", "ellipsis": "...",
}
TERMINAL_RE = re.compile(r'[.!?]["\')\]]*$')

# PnC label set: punctuation that FOLLOWS a word, plus the word's casing.
# ';' and ':' are folded into COMMA (common practice; they are rare in speech).
PUNCT_LABEL_MAP = {",": "COMMA", ";": "COMMA", ":": "COMMA", ".": "PERIOD",
                   "?": "QUESTION", "!": "EXCLAMATION"}
PNC_LABELS = ["O", "COMMA", "PERIOD", "QUESTION", "EXCLAMATION"]
CASE_LABELS = ["LOWER", "UPPER_FIRST", "ALL_CAPS", "MIXED"]


def pnc_labels(text: str) -> tuple[list[str], list[str], list[str]]:
    """Return (lowercased words, punctuation label after each word, case label of each word).

    This is the training/evaluation format for a punctuation-and-capitalisation model:
    input = the lower-cased, unpunctuated words (what ASR produces); targets = labels.
    """
    words, punct, case = [], [], []
    for m in WORD_RE.finditer(text):
        w = m.group(0)
        tail = text[m.end(): m.end() + 4].lstrip("\"')]")
        label = "O"
        if tail[:3] == "...":
            label = "PERIOD"
        elif tail[:1] in PUNCT_LABEL_MAP:
            label = PUNCT_LABEL_MAP[tail[:1]]
        if w.islower() or not any(c.isalpha() for c in w):
            c = "LOWER"
        elif w.isupper() and len(w) > 1:
            c = "ALL_CAPS"
        elif w[0].isupper() and (w[1:].islower() or len(w) == 1):
            c = "UPPER_FIRST"
        else:
            c = "MIXED"
        words.append(w.lower())
        punct.append(label)
        case.append(c)
    return words, punct, case


def punct_profile(texts: list[str]) -> dict:
    """Punctuation profile of a list of texts using the shared counting method."""
    n_rec = len(texts)
    tok_total = 0
    marks = Counter()
    any_punct = terminal = starts_upper = all_lower = 0
    sent_count = 0
    labels = Counter()
    for t in texts:
        toks = word_tokens(t)
        tok_total += len(toks)
        marks["ellipsis"] += t.count("...")
        t_no_ell = t.replace("...", "")
        for name, ch in PUNCT_MARKS.items():
            if name in ("ellipsis", "squote_standalone"):
                continue
            marks[name] += t_no_ell.count(ch)
        # apostrophes inside words (don't) are not punctuation marks
        marks["squote_standalone"] += len(re.findall(r"(?<![^\W_])'|'(?![^\W_])", t))
        if re.search(r"[.,!?;:]", t):
            any_punct += 1
        if TERMINAL_RE.search(t.strip()):
            terminal += 1
        first_alpha = next((ch for ch in t if ch.isalpha()), "")
        if first_alpha and first_alpha.isupper():
            starts_upper += 1
        if t == t.lower():
            all_lower += 1
        sent_count += max(1, len(re.findall(r"[.!?]+(?:\s|$)", t)))
        _, p, _ = pnc_labels(t)
        labels.update(p)
    per100 = lambda x: round(100.0 * x / tok_total, 2) if tok_total else 0.0
    pct = lambda x: round(100.0 * x / n_rec, 1) if n_rec else 0.0
    lab_total = sum(labels.values()) or 1
    prof = {
        "records": n_rec,
        "tokens": tok_total,
        "mean_tokens_per_record": round(tok_total / n_rec, 1) if n_rec else 0.0,
        "punct_per_100_tokens": per100(sum(marks[k] for k in ("period", "comma", "question",
                                                                "exclamation", "colon",
                                                                "semicolon"))),
        "periods_per_100": per100(marks["period"]),
        "commas_per_100": per100(marks["comma"]),
        "questions_per_100": per100(marks["question"]),
        "exclaims_per_100": per100(marks["exclamation"]),
        "colon_semicolon_per_100": per100(marks["colon"] + marks["semicolon"]),
        "quotes_per_100": per100(marks["dquote"] + marks["squote_standalone"]),
        "any_punct_pct": pct(any_punct),
        "terminal_end_pct": pct(terminal),
        "starts_upper_pct": pct(starts_upper),
        "all_lowercase_pct": pct(all_lower),
        "mean_sentence_len": round(tok_total / sent_count, 1) if sent_count else 0.0,
    }
    for lab in PNC_LABELS:
        prof[f"label_{lab}_pct"] = round(100.0 * labels[lab] / lab_total, 2)
    if C.SPECIAL_CHARS:
        # "diacritics preserved" criterion: share of word tokens containing the language's
        # special letters (e.g. Igbo ị ọ ụ ṅ) and share carrying tone marks (acute/grave/macron)
        spec = tone = 0
        for t in texts:
            for w in word_tokens(t):
                if any(c in w for c in C.SPECIAL_CHARS):
                    spec += 1
                if any(ch in "\u0300\u0301\u0304" for ch in unicodedata.normalize("NFD", w)):
                    tone += 1
        prof["special_char_token_pct"] = per100(spec)
        prof["tone_marked_token_pct"] = per100(tone)
    prof["punct_quality"] = grade_punctuation(prof)
    return prof


def grade_punctuation(p: dict) -> str:
    g, f = C.PUNCT_GOOD, C.PUNCT_FAIR
    if (p["terminal_end_pct"] >= g["terminal_end_pct"] and p["any_punct_pct"] >= g["any_punct_pct"]
            and p["commas_per_100"] >= g["commas_per_100"]):
        return "good"
    if p["terminal_end_pct"] >= f["terminal_end_pct"] and p["any_punct_pct"] >= f["any_punct_pct"]:
        return "fair"
    return "poor"


def md_table(rows: list[dict], cols: list[str] | None = None) -> str:
    """Tiny Markdown table writer (avoids needing the 'tabulate' package)."""
    if not rows:
        return "_(no rows)_\n"
    cols = cols or list(rows[0].keys())
    esc = lambda v: str(v).replace("|", "/").replace("\n", " ")
    out = ["| " + " | ".join(cols) + " |", "|" + "|".join("---" for _ in cols) + "|"]
    out += ["| " + " | ".join(esc(r.get(c, "")) for c in cols) + " |" for r in rows]
    return "\n".join(out) + "\n"
