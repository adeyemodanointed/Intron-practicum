"""
STEP 7 - Score the manual validation: acceptance rate and reviewer agreement.

    python step7_score_reviews.py
    python step7_score_reviews.py --lang ibo
    python step7_score_reviews.py --lang ibo --primary my_sheet.xlsx --second peter_sheet.xlsx

Reads the filled-in review sheets (.xlsx or .csv), then:
  * acceptance rate overall, per dataset and per domain;
  * "yes" rate for each check (is_<language>, domain_correct, punctuation_ok, text_quality_ok);
  * agreement between the two reviewers on the overlapping records:
    percentage agreement and Cohen's kappa for every check and the decision;
  * writes review_status back into data/clean/<lang>_clean.jsonl
    (accepted / rejected; "disputed" where the two reviewers disagree on the decision).

Outputs: reports/<lang>_validation_summary.csv and reports/<lang>_validation_summary.md
"""
import argparse
import csv
import sys
from collections import Counter, defaultdict
from pathlib import Path

import config as C
from common import md_table, read_jsonl, write_jsonl

CHECKS = [C.REVIEW_LANG_COL, "domain_correct", "punctuation_ok", "text_quality_ok", "decision"]
LANG_COL_ALIASES = ["is_pidgin", "is_igbo", "is_target_language"]
YES = {"y", "yes", "1", "true", "accept", "accepted", "ok"}
NO = {"n", "no", "0", "false", "reject", "rejected"}


def norm(v) -> str:
    s = str(v or "").strip().lower()
    if s in YES:
        return "Y"
    if s in NO:
        return "N"
    return ""


def load_sheet(path: Path) -> dict[str, dict]:
    rows = []
    if path.suffix.lower() == ".xlsx":
        from openpyxl import load_workbook
        ws = load_workbook(path, read_only=True).active
        it = ws.iter_rows(values_only=True)
        header = [str(h) for h in next(it)]
        rows = [dict(zip(header, r)) for r in it]
    else:
        with open(path, encoding="utf-8-sig") as f:
            rows = list(csv.DictReader(f))
    out = {}
    for r in rows:
        if not r.get("id"):
            continue
        if C.REVIEW_LANG_COL not in r:          # sheet made with another column name
            alias = next((a for a in LANG_COL_ALIASES if a in r), None)
            if alias:
                r[C.REVIEW_LANG_COL] = r[alias]
        rec = {k: r.get(k) for k in ("id", "source_dataset", "domain", "raw_text")}
        rec.update({c: norm(r.get(c)) for c in CHECKS})
        out[str(r["id"])] = rec
    return out


def cohen_kappa(a: list[str], b: list[str]) -> float | str:
    pairs = [(x, y) for x, y in zip(a, b) if x and y]
    n = len(pairs)
    if n == 0:
        return ""
    po = sum(x == y for x, y in pairs) / n
    ca, cb = Counter(x for x, _ in pairs), Counter(y for _, y in pairs)
    pe = sum((ca[k] / n) * (cb[k] / n) for k in set(ca) | set(cb))
    if pe == 1:
        return 1.0 if po == 1 else 0.0
    return round((po - pe) / (1 - pe), 3)


def pick(path_arg, default_stem):
    if path_arg:
        return Path(path_arg)
    for ext in (".xlsx", ".csv"):
        p = C.REVIEWS / f"{default_stem}{ext}"
        if p.exists():
            return p
    return None


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--primary")
    ap.add_argument("--second")
    ap.add_argument("--no-writeback", action="store_true", help="do not update review_status")
    args = ap.parse_args()

    p_path = pick(args.primary, f"{C.LANG}_review_primary")
    s_path = pick(args.second, f"{C.LANG}_review_second")
    if not p_path or not p_path.exists():
        sys.exit("Primary review sheet not found. Run step6 and fill it in first.")
    primary = load_sheet(p_path)
    done = {k: v for k, v in primary.items() if v["decision"]}
    if not done:
        sys.exit(f"No decisions filled in yet in {p_path.name} (column 'decision': accept/reject).")

    def rates(rows):
        n = len(rows)
        out = {"reviewed": n, "acceptance_pct": round(100 * sum(r["decision"] == "Y" for r in rows) / n, 1)}
        for c in CHECKS[:-1]:
            answered = [r for r in rows if r[c]]
            out[f"{c}_yes_pct"] = round(100 * sum(r[c] == "Y" for r in answered) / len(answered), 1) if answered else ""
        return out

    summary = [{"group": "ALL", **rates(list(done.values()))}]
    for key in ("source_dataset", "domain"):
        grp = defaultdict(list)
        for r in done.values():
            grp[r[key]].append(r)
        for g, rows in sorted(grp.items()):
            summary.append({"group": f"{key}={g}", **rates(rows)})

    agreement = []
    second = load_sheet(s_path) if s_path and s_path.exists() else {}
    overlap = [i for i in second if i in done and second[i]["decision"]]
    if overlap:
        for c in CHECKS:
            a = [done[i][c] for i in overlap]
            b = [second[i][c] for i in overlap]
            both = [(x, y) for x, y in zip(a, b) if x and y]
            agreement.append({"check": c, "items": len(both),
                              "agreement_pct": round(100 * sum(x == y for x, y in both) / len(both), 1) if both else "",
                              "cohen_kappa": cohen_kappa(a, b)})

    C.REPORTS.mkdir(parents=True, exist_ok=True)
    with open(C.REPORTS / f"{C.LANG}_validation_summary.csv", "w", newline="", encoding="utf-8") as f:
        cols = list(summary[0].keys())
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        w.writerows(summary)
        if agreement:
            f.write("\n")
            w2 = csv.DictWriter(f, fieldnames=list(agreement[0].keys()))
            w2.writeheader()
            w2.writerows(agreement)
    md = [f"# Manual validation - {C.LANG_NAME}\n",
          f"Primary reviewer: {len(done)} records reviewed; second reviewer overlap: {len(overlap)} records.\n",
          md_table(summary)]
    if agreement:
        md += ["\n## Reviewer agreement\n", md_table(agreement),
               "\nKappa guide: <0.20 slight, 0.21-0.40 fair, 0.41-0.60 moderate, 0.61-0.80 substantial, >0.80 almost perfect.\n"]
    (C.REPORTS / f"{C.LANG}_validation_summary.md").write_text("\n".join(md), encoding="utf-8")
    print("\n".join(md))

    if not args.no_writeback:
        clean = C.CLEAN_DIR / f"{C.LANG}_clean.jsonl"
        recs = list(read_jsonl(clean))
        # Match each reviewed row to its record by ID *and* text; fall back to the text alone,
        # so sheets drawn before a re-run (when IDs may have shifted) still apply correctly.
        by_text = {}
        for rv in done.values():
            if rv.get("raw_text"):
                by_text[str(rv["raw_text"]).strip()] = rv
        changed = Counter()
        matched = set()
        for r in recs:
            rv = done.get(r["id"])
            if rv and rv.get("raw_text") and str(rv["raw_text"]).strip() != r["raw_text"].strip():
                rv = None                      # same ID, different text: not the reviewed record
            rv = rv or by_text.get(r["raw_text"].strip())
            if not rv:
                continue
            matched.add(rv["id"])
            status = "accepted" if rv["decision"] == "Y" else "rejected"
            sv = second.get(rv["id"])
            if sv and sv["decision"] and sv["decision"] != rv["decision"]:
                status = "disputed"
            r["review_status"] = status
            changed[status] += 1
        write_jsonl(clean, recs)
        print(f"review_status updated in {clean.name}: {dict(changed)}")
        missing = len(done) - len(matched)
        if missing:
            print(f"note: {missing} reviewed rows no longer match a record (text changed or removed "
                  f"by a re-run); they still count in the acceptance statistics above.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
