"""Model classes for the domain classifier (kept in their own module so a saved model can
be loaded by clf3_predict.py and step3_clean.py)."""
import sys

import numpy as np

OTHER = "other"


class TfidfModel:
    def __init__(self, C_reg=4.0):
        from scipy.sparse import hstack  # noqa: F401
        from sklearn.feature_extraction.text import TfidfVectorizer
        from sklearn.linear_model import LogisticRegression
        self.word = TfidfVectorizer(analyzer="word", ngram_range=(1, 2), min_df=2, sublinear_tf=True,
                                    max_features=200_000, token_pattern=r"(?u)\b\w[\w'-]*\b")
        self.char = TfidfVectorizer(analyzer="char_wb", ngram_range=(3, 5), min_df=2, sublinear_tf=True,
                                    max_features=300_000)
        self.clf = LogisticRegression(C=C_reg, class_weight="balanced", max_iter=3000)

    def _x(self, texts, fit=False):
        from scipy.sparse import hstack
        if fit:
            return hstack([self.word.fit_transform(texts), self.char.fit_transform(texts)]).tocsr()
        return hstack([self.word.transform(texts), self.char.transform(texts)]).tocsr()

    def fit(self, texts, y, w):
        self.clf.fit(self._x(texts, fit=True), y, sample_weight=w)
        return self

    def proba(self, texts):
        return self.clf.predict_proba(self._x(texts))

    @property
    def classes_(self):
        return list(self.clf.classes_)


class EmbedModel:
    def __init__(self, name, C_reg=4.0):
        try:
            from sentence_transformers import SentenceTransformer
        except ImportError:
            sys.exit("--embed needs:  pip install sentence-transformers")
        from sklearn.linear_model import LogisticRegression
        self.name = name
        self.enc = SentenceTransformer(name)
        self.prefix = "query: " if "e5" in name.lower() else ""
        self.clf = LogisticRegression(C=C_reg, class_weight="balanced", max_iter=3000)

    def _x(self, texts):
        return self.enc.encode([self.prefix + t for t in texts], batch_size=64, show_progress_bar=False,
                               normalize_embeddings=True)

    def fit(self, texts, y, w):
        self.clf.fit(self._x(texts), y, sample_weight=w)
        return self

    def proba(self, texts):
        return self.clf.predict_proba(self._x(texts))

    @property
    def classes_(self):
        return list(self.clf.classes_)

    def __getstate__(self):           # do not pickle the encoder; reload it by name
        d = dict(self.__dict__)
        d["enc"] = None
        return d

    def __setstate__(self, d):
        self.__dict__.update(d)
        from sentence_transformers import SentenceTransformer
        self.enc = SentenceTransformer(self.name)


def decide(proba, classes, threshold):
    """Top class, but a target domain only if its probability >= its threshold.

    `threshold` is a number (same for all classes) or a dict {class: threshold}.
    """
    out = []
    for row in proba:
        k = int(np.argmax(row))
        lab = classes[k]
        th = threshold.get(lab, 0.5) if isinstance(threshold, dict) else threshold
        out.append(lab if (lab == OTHER or row[k] >= th) else OTHER)
    return out
