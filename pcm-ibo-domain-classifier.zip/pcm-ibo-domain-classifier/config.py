"""
Shared configuration + language selection.

Choose the language on the command line of ANY step:
    python step1_download.py --lang ibo
    python step3_clean.py --lang pcm
(or set the environment variable PIPELINE_LANG=ibo). The default is pcm.

Language-specific settings (sources, domains, keyword lists, language markers) live in
langs/<code>.py. Add a new language by copying langs/ibo.py.
"""
import importlib
import os
import sys
from pathlib import Path

# --------------------------------------------------------------------------------------
# Language selection: "--lang xx" / "--lang=xx" is removed from sys.argv so the steps'
# own argument parsers never see it.
# --------------------------------------------------------------------------------------

def _pick_lang() -> str:
    lang = os.environ.get("PIPELINE_LANG", "pcm")
    argv = sys.argv
    for i, a in enumerate(list(argv)):
        if a == "--lang" and i + 1 < len(argv):
            lang = argv[i + 1]
            del argv[i:i + 2]
            break
        if a.startswith("--lang="):
            lang = a.split("=", 1)[1]
            del argv[i]
            break
    return lang.strip().lower()


ACTIVE = _pick_lang()
try:
    _lang = importlib.import_module(f"langs.{ACTIVE}")
except ModuleNotFoundError:
    sys.exit(f"No settings for language '{ACTIVE}'. Available: "
             f"{sorted(p.stem for p in (Path(__file__).parent / 'langs').glob('[a-z]*.py'))}")

# --------------------------------------------------------------------------------------
# Paths (file names are prefixed with the language code, so languages never collide)
# --------------------------------------------------------------------------------------
ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
RAW_DIR = DATA / "raw"
FORMATTED_DIR = DATA / "formatted"
CLEAN_DIR = DATA / "clean"
AUX_DIR = DATA / "aux"
PNC_DIR = DATA / "pnc"
REPORTS = ROOT / "reports"
REVIEWS = ROOT / "reviews"
MODELS = ROOT / "models"
for _d in (REPORTS, REVIEWS, MODELS):
    _d.mkdir(parents=True, exist_ok=True)

# --------------------------------------------------------------------------------------
# Targets (team's dataset-selection criteria) - same for every language
# --------------------------------------------------------------------------------------
TARGET_TOKENS_PER_DOMAIN = 50_000      # the final dataset keeps up to this many tokens per domain
# (TARGET_TOKENS_TOTAL / FALLBACK_TOKENS_TOTAL are set below, once the domain list is known)

REVIEW_STATUSES = ["unreviewed", "accepted", "rejected", "disputed"]
SCHEMA_FIELDS = [
    "id", "language", "domain", "raw_text", "source_dataset", "source_split",
    "license", "review_status", "notes",
]

# --------------------------------------------------------------------------------------
# Segmentation / cleaning / checks (shared)
# --------------------------------------------------------------------------------------
MIN_TOKENS_PER_RECORD = 5
MAX_TOKENS_PER_RECORD = 120
MIN_ALPHA_RATIO = 0.60
NEAR_DUP_OVERLAP = 0.80        # drop a record if >= 80% of its tokens are in sentences already kept

LANGCHECK_MIN_TOKENS = 8
LANGCHECK_MIN_RATIO = 0.04

DOMAIN_MIN_HITS = 3
DOMAIN_MIN_MARGIN = 1.5
DOMAIN_MIN_DISTINCT = 2         # hits must come from at least 2 different keywords

PUNCT_GOOD = {"terminal_end_pct": 90.0, "any_punct_pct": 95.0, "commas_per_100": 2.0}
PUNCT_FAIR = {"terminal_end_pct": 60.0, "any_punct_pct": 80.0}

DECISION_MIN_LANG_PCT = 85.0
DECISION_MIN_ACCEPTANCE_PCT = 80.0

GH = "https://raw.githubusercontent.com"

# English function words (rare in the target languages) for the language check.
ENG_MARKERS = {
    "the", "is", "are", "was", "were", "has", "have", "been", "their", "they", "which",
    "this", "that", "these", "those", "would", "could", "should", "its", "an",
    "whose", "whom", "does", "being",
}

# --------------------------------------------------------------------------------------
# Pull in the language settings (UPPER_CASE names only) and fill defaults.
# --------------------------------------------------------------------------------------
globals().update({k: v for k, v in vars(_lang).items() if k.isupper()})

_defaults = {
    "OTHER_DOMAINS": [],
    "STRICT_DOMAINS": False,
    "AUX_SOURCES": {},
    "CONSIDERED_NOT_USED": [],
    "OTHER_LANG_MARKERS": {},
    "SPECIAL_CHARS": "",
    "LABEL_MAP": {},
    "UNMAPPED_LABEL_POLICY": "keep",
    "REVIEW_LANG_COL": "is_target_language",
}
for _k, _v in _defaults.items():
    globals().setdefault(_k, _v)

# Optional override of the target domains for one run:  --domains health,sports,law
# (or PIPELINE_DOMAINS=...). Useful to compare domain sets without editing langs/<lang>.py.
def _pick_domains():
    val = os.environ.get("PIPELINE_DOMAINS", "")
    argv = sys.argv
    for i, a in enumerate(list(argv)):
        if a == "--domains" and i + 1 < len(argv):
            val = argv[i + 1]
            del argv[i:i + 2]
            break
        if a.startswith("--domains="):
            val = a.split("=", 1)[1]
            del argv[i]
            break
    return [d.strip() for d in val.split(",") if d.strip()]


_override = _pick_domains()
if _override:
    _old = list(TARGET_DOMAINS)  # noqa: F821
    TARGET_DOMAINS = _override
    OTHER_DOMAINS = [d for d in list(OTHER_DOMAINS) + _old if d not in _override]  # noqa: F821

DOMAIN_VOCAB = list(TARGET_DOMAINS) + [d for d in OTHER_DOMAINS if d not in TARGET_DOMAINS]
TARGET_TOKENS_TOTAL = TARGET_TOKENS_PER_DOMAIN * len(TARGET_DOMAINS)
FALLBACK_TOKENS_TOTAL = TARGET_TOKENS_TOTAL // 2
OUT_OF_SCOPE = "out_of_scope"   # temporary label for text outside the domains (dropped if STRICT)
