"""
STEP 1 - Download the candidate datasets for one language into data/raw/<source>/.

    python step1_download.py --lang ibo           # all Igbo text sources
    python step1_download.py --lang pcm --sources masakhanews_pcm mafand_en_pcm
    python step1_download.py --with-asr           # also the ~956 MB ASR set (gap analysis)

GitHub-hosted sources use plain HTTPS. Hugging Face sources use `huggingface_hub`.
A failed source is reported and skipped; the others still download.
Files that already exist are not downloaded again (use --force to refresh).
"""
import argparse
import sys
import tarfile
import urllib.request
from pathlib import Path

import config as C


def fetch_url(url: str, dest: Path, force: bool) -> None:
    if dest.exists() and dest.stat().st_size > 0 and not force:
        print(f"    exists  {dest.name}")
        return
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_suffix(dest.suffix + ".part")
    with urllib.request.urlopen(url, timeout=120) as r, open(tmp, "wb") as f:
        while chunk := r.read(1 << 16):
            f.write(chunk)
    tmp.replace(dest)
    print(f"    saved   {dest.name} ({dest.stat().st_size / 1e6:.2f} MB)")


def fetch_hf(src: dict, dest_dir: Path, force: bool) -> None:
    try:
        from huggingface_hub import hf_hub_download, snapshot_download
    except ImportError:
        raise RuntimeError("pip install huggingface_hub  (needed for Hugging Face sources)")
    dest_dir.mkdir(parents=True, exist_ok=True)
    repo = src["hf_repo"]
    for fname in src.get("hf_files", []):
        target = dest_dir / fname
        if target.exists() and not force:
            print(f"    exists  {fname}")
            continue
        hf_hub_download(repo_id=repo, repo_type="dataset", filename=fname,
                        local_dir=str(dest_dir), force_download=force)
        print(f"    saved   {fname}")
    if src.get("hf_patterns"):
        snapshot_download(repo_id=repo, repo_type="dataset", local_dir=str(dest_dir),
                          allow_patterns=src["hf_patterns"], force_download=force)
        print(f"    saved   files matching {src['hf_patterns']}")
    # XL-Sum ships as a .tar.bz2 archive: unpack it next to the archive.
    for arc in dest_dir.rglob("*.tar.bz2"):
        out = arc.parent / "extracted"
        if not out.exists() or force:
            with tarfile.open(arc, "r:bz2") as tf:
                try:
                    tf.extractall(out, filter="data")   # safe extraction (Python >= 3.11.4)
                except TypeError:
                    tf.extractall(out)                  # older Python without the filter arg
            print(f"    unpacked {arc.name}")


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--sources", nargs="*", default=list(C.SOURCES), help="source keys from config.SOURCES")
    ap.add_argument("--with-asr", action="store_true", help="also download the ASR transcripts (large)")
    ap.add_argument("--force", action="store_true", help="re-download files that already exist")
    args = ap.parse_args()

    todo = {k: C.SOURCES[k] for k in args.sources if k in C.SOURCES}
    unknown = [k for k in args.sources if k not in C.SOURCES]
    if unknown:
        print(f"Unknown source keys ignored: {unknown}. Valid: {list(C.SOURCES)}")
    if args.with_asr:
        todo.update(C.AUX_SOURCES)

    ok, failed = [], []
    for key, src in todo.items():
        print(f"[{key}] {src['title']}  ({src['hosting']})")
        dest = C.RAW_DIR / key
        try:
            if src["hosting"] == "github":
                for fname, url in src["files"].items():
                    fetch_url(url, dest / fname, args.force)
            else:
                fetch_hf(src, dest, args.force)
            ok.append(key)
        except Exception as e:  # keep going: one blocked source should not stop the rest
            print(f"    FAILED: {type(e).__name__}: {e}")
            failed.append(key)

    print(f"\nDownloaded: {ok}")
    if failed:
        print(f"Failed:     {failed}  (check your internet / Hugging Face access, then rerun)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
