"""
CLASSIFIER STEP 1 - Build training / dev / test sets for the domain classifier,
WITHOUT manual annotation.

    python clf1_build_dataset.py --lang pcm
    python clf1_build_dataset.py --lang pcm --teacher nli          # + zero-shot teacher (GPU recommended)
    python clf1_build_dataset.py --lang pcm --domains telecommunications,health,education,sports,law

Input : data/formatted/<lang>_*.jsonl   (run step1 + step2 first)
Output: data/classifier/<lang>_{train,dev,test,unlabeled}.jsonl
        reports/<lang>_clf_dataset.md   label counts by where each label came from

Labels = the target domains + "other". Where labels come from, strongest first:

  gold    dataset labels made by people: MasakhaNEWS topic labels, UD Naija recording
          titles. Topics outside the target domains (politics, entertainment, ...)
          become "other". These are the ONLY labels used for the test set.
  teacher optional zero-shot model (multilingual NLI) that labels unlabeled text it is
          confident about. Needs `pip install transformers torch`; use a GPU on Colab.
  weak    keyword rules (3+ hits, 2+ different keywords, clear lead). Keywords are later
          masked during training so the model learns the context, not the keywords.

Splits:
  test  = gold labels from MasakhaNEWS 'test' split + all UD Naija titled recordings
          (speech transcripts, a harder out-of-domain check)
  dev   = gold labels from MasakhaNEWS 'dev' split (used to tune the "other" threshold)
  train = everything else that has a label; training texts that overlap a test/dev
          article (same sentences) are removed to avoid leakage
  unlabeled = no confident label; the classifier will label these in clf3.
"""
import argparse
import hashlib
import random
import sys
from collections import Counter

import config as C
from common import (clean_text, keyword_confident, keyword_scores, md_table, n_tokens, parse_notes,
                    read_jsonl, sentence_key, split_sentences, write_jsonl)

OTHER = "other"

# Short English descriptions of each domain for the zero-shot teacher. Non-target topics are
# offered too, so the teacher has somewhere to put politics or football stories.
TEACHER_DESCRIPTIONS = {
    "health": "health, disease, hospitals and medicine",
    "finance": "money, banking, prices and the economy",
    "agriculture": "farming, crops, livestock and agriculture",
    "telecommunications": "mobile phones, telecom networks, SIM cards, data and the internet",
    "law": "law, courts, judges, police and crime",
    "education": "schools, students, teachers, exams and education",
    "sports": "sports, football and athletes",
    "politics_government": "politics, elections and government",
    "entertainment": "music, films, celebrities and entertainment",
    "religion": "religion, church, mosque and faith",
}


def to_class(domain: str) -> str:
    return domain if domain in C.TARGET_DOMAINS else OTHER


def doc_bucket(key: str) -> float:
    return int(hashlib.md5(key.encode()).hexdigest()[:8], 16) / 0xFFFFFFFF


def load_examples():
    files = sorted(C.FORMATTED_DIR.glob(f"{C.LANG}_*.jsonl"))
    if not files:
        sys.exit("No formatted files. Run step1_download.py and step2_format.py first.")
    label_map = dict(C.LABEL_MAP)
    for f in files:
        source = f.stem[len(C.LANG) + 1:]
        for i, r in enumerate(read_jsonl(f)):
            text = clean_text(r["raw_text"])
            if n_tokens(text) < C.MIN_TOKENS_PER_RECORD:
                continue
            notes = parse_notes(r["notes"])
            method = notes.get("domain_method", "")
            ex = {"text": text, "source": source, "line": i, "split": r["source_split"],
                  "doc": f"{source}:{notes.get('doc', i)}", "label": None, "label_source": None}
            orig = notes.get("orig_label", "")
            curated = C.SOURCES.get(source, {}).get("reader") == "masakhanews"
            if orig and (curated or orig in label_map):
                # a topic label given by the dataset itself: MasakhaNEWS labels are curated by
                # people, so every label counts (non-target topics -> "other"); for other datasets
                # (e.g. WURA categories) only labels that map straight onto a target domain count
                ex["label"] = to_class(label_map.get(orig, orig))
                ex["label_source"] = "gold:dataset_label"
            elif method == "recording_title":
                ex["label"] = to_class(r["domain"])
                ex["label_source"] = "gold:recording_title"
            else:
                best, s1, s2, distinct = keyword_scores(text)
                if keyword_confident(best, s1, s2, distinct):
                    ex["label"] = to_class(best)
                    ex["label_source"] = "weak:keywords"
            yield ex


def run_teacher(examples, model_name: str, threshold: float, max_n: int, batch: int, seed: int):
    try:
        from transformers import pipeline
    except ImportError:
        sys.exit("The NLI teacher needs:  pip install transformers torch sentencepiece")
    import torch
    device = 0 if torch.cuda.is_available() else -1
    print(f"[teacher] {model_name} on {'GPU' if device == 0 else 'CPU (slow)'}")
    clf = pipeline("zero-shot-classification", model=model_name, device=device)
    if device == 0:
        clf.model.half()            # half precision on GPU: about 2x faster, same labels
    labels = [d for d in TEACHER_DESCRIPTIONS if d in C.TARGET_DOMAINS] + \
             [d for d in TEACHER_DESCRIPTIONS if d not in C.TARGET_DOMAINS]
    desc = [TEACHER_DESCRIPTIONS[d] for d in labels]
    back = dict(zip(desc, labels))
    # Prioritise texts with at least one target keyword (likely positives), then a random rest.
    rng = random.Random(seed)
    cand = []
    for ex in examples:
        best, s1, _, _ = keyword_scores(ex["text"])
        cand.append((0 if (s1 > 0 and best in C.TARGET_DOMAINS) else 1, rng.random(), ex))
    cand.sort(key=lambda t: (t[0], t[1]))
    todo = [ex for _, _, ex in cand[:max_n]]
    n_lab = 0
    for i in range(0, len(todo), batch):
        part = todo[i:i + batch]
        outs = clf([e["text"][:1000] for e in part], candidate_labels=desc,
                   hypothesis_template="This text is about {}.", multi_label=False,
                   batch_size=batch)
        for e, o in zip(part, outs if isinstance(outs, list) else [outs]):
            top, p = o["labels"][0], o["scores"][0]
            if p >= threshold:
                e["label"] = to_class(back[top])
                e["label_source"] = "teacher:nli"
                e["teacher_prob"] = round(p, 3)
                n_lab += 1
        done = min(i + batch, len(todo))
        if done == len(todo) or (i // batch) % 10 == 0:
            print(f"    teacher: {done:,}/{len(todo):,} done, {n_lab:,} confident labels", flush=True)
    return n_lab


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--teacher", choices=["none", "nli"], default="none")
    ap.add_argument("--teacher-model", default="MoritzLaurer/mDeBERTa-v3-base-mnli-xnli")
    ap.add_argument("--teacher-threshold", type=float, default=0.70)
    ap.add_argument("--teacher-max", type=int, default=6000, help="max unlabeled texts sent to the teacher")
    ap.add_argument("--teacher-batch", type=int, default=32)
    ap.add_argument("--seed", type=int, default=13)
    args = ap.parse_args()

    examples = list(load_examples())
    print(f"Loaded {len(examples):,} texts from data/formatted/ ({C.LANG}); "
          f"classes: {C.TARGET_DOMAINS + [OTHER]}")

    # ---- split: gold test/dev; everything else labelled -> train
    test, dev, train, unlabeled = [], [], [], []
    for ex in examples:
        gold = (ex["label_source"] or "").startswith("gold")
        if gold and ex["label_source"] == "gold:recording_title":
            test.append(ex)
        elif gold and ex["split"] == "test":
            test.append(ex)
        elif gold and ex["split"] == "dev":
            dev.append(ex)
        elif ex["label"] is not None:
            train.append(ex)
        else:
            unlabeled.append(ex)

    if args.teacher == "nli":
        n = run_teacher(unlabeled, args.teacher_model, args.teacher_threshold, args.teacher_max,
                        args.teacher_batch, args.seed)
        moved = [e for e in unlabeled if e["label"] is not None]
        unlabeled = [e for e in unlabeled if e["label"] is None]
        train += moved
        print(f"[teacher] {n:,} texts labelled and added to train")

    # ---- leakage: drop training texts that share sentences with dev/test articles
    held = set()
    for ex in test + dev:
        for s in split_sentences(ex["text"]):
            if n_tokens(s) >= 4:
                held.add(sentence_key(s))
    clean_train, leaked = [], 0
    for ex in train:
        sents = [s for s in split_sentences(ex["text"]) if n_tokens(s) >= 4]
        tot = sum(n_tokens(s) for s in sents) or 1
        hit = sum(n_tokens(s) for s in sents if sentence_key(s) in held)
        if hit / tot >= 0.5:
            leaked += 1
            continue
        clean_train.append(ex)
    train = clean_train

    out = C.DATA / "classifier"
    for name, rows in (("train", train), ("dev", dev), ("test", test), ("unlabeled", unlabeled)):
        write_jsonl(out / f"{C.LANG}_{name}.jsonl", rows)

    # ---- report
    classes = C.TARGET_DOMAINS + [OTHER]
    table = []
    for name, rows in (("train", train), ("dev", dev), ("test", test)):
        cnt = Counter((r["label"], (r["label_source"] or "").split(":")[0]) for r in rows)
        for src in ("gold", "teacher", "weak"):
            row = {"split": name, "label_from": src}
            row.update({c: cnt.get((c, src), 0) for c in classes})
            if sum(row[c] for c in classes):
                table.append(row)
    missing = [c for c in C.TARGET_DOMAINS
               if not any(r["label"] == c for r in test)]
    thin = [c for c in C.TARGET_DOMAINS if sum(r["label"] == c for r in train) < 50]
    md = [f"# Domain-classifier data - {C.LANG_NAME}\n",
          f"Classes: {', '.join(classes)}\n",
          md_table(table),
          f"\nUnlabeled texts (to be labelled by the classifier): {len(unlabeled):,}",
          f"\nTraining texts removed because they repeat a dev/test article: {leaked:,}"]
    if missing:
        md.append(f"\n**No gold test examples for: {', '.join(missing)}.** Scores for these classes "
                  f"cannot be measured from existing labels - use `clf3_predict.py --check-sheet` and "
                  f"mark ~20 predictions per class (quick yes/no), then rerun clf2 with `--gold`.")
    if thin:
        md.append(f"\n**Fewer than 50 training examples for: {', '.join(thin)}.** Add more raw text "
                  f"(XL-Sum, WURA, FineWeb via step1), use `--teacher nli`, or extend the keyword lists.")
    (C.REPORTS / f"{C.LANG}_clf_dataset.md").write_text("\n".join(md), encoding="utf-8")
    print("\n".join(md))
    return 0


if __name__ == "__main__":
    sys.exit(main())
