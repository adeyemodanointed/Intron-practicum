"""
STEP 5 - Token counts, punctuation statistics, language-check shares and domain coverage.

    python step5_stats.py --lang ibo
    python step5_stats.py --lang ibo --inputs other_file.jsonl   # any file in the shared schema

Outputs (reports/):
    <lang>_punctuation_stats.csv    one row per dataset (+ ALL, + speech-transcript rows)
    <lang>_punctuation_by_domain.csv  one row per dataset x domain
    <lang>_domain_coverage.csv      tokens per domain vs the 200k-per-domain target
    <lang>_stats_summary.md         the same tables as Markdown, with the totals vs targets

Counting method (identical for every language; see common.py):
    token      = run of letters/digits incl. diacritics, internal ' or - allowed
    punctuation per 100 tokens counts . , ? ! : ;  (quotes/brackets reported separately)
    terminal_end_pct = % records ending in . ? or ! (optionally followed by a quote/bracket)
    label_*_pct = distribution of PnC labels over word tokens
"""
import argparse
import csv
import sys
from collections import Counter, defaultdict
from pathlib import Path

import config as C
from common import md_table, parse_notes, punct_profile, read_jsonl

STAT_COLS = ["records", "tokens", "mean_tokens_per_record", "punct_per_100_tokens", "periods_per_100",
             "commas_per_100", "questions_per_100", "exclaims_per_100", "colon_semicolon_per_100",
             "quotes_per_100", "any_punct_pct", "terminal_end_pct", "starts_upper_pct",
             "all_lowercase_pct", "mean_sentence_len", "label_O_pct", "label_COMMA_pct",
             "label_PERIOD_pct", "label_QUESTION_pct", "label_EXCLAMATION_pct", "punct_quality"]
if C.SPECIAL_CHARS:
    STAT_COLS += ["special_char_token_pct", "tone_marked_token_pct"]


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        return
    cols = list(rows[0].keys())
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        w.writerows(rows)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--inputs", nargs="*", default=None, help="clean JSONL files (default: this language's)")
    ap.add_argument("--aux", nargs="*", default=None, help="speech-transcript JSONL files for the gap rows")
    args = ap.parse_args()
    args.lang = C.LANG
    C.REPORTS.mkdir(parents=True, exist_ok=True)

    inputs = [Path(p) for p in (args.inputs or [C.CLEAN_DIR / f"{args.lang}_clean.jsonl"])]
    aux = [Path(p) for p in (args.aux if args.aux is not None else sorted(C.AUX_DIR.glob(f"{args.lang}_*.jsonl")))]
    missing = [str(p) for p in inputs if not p.exists()]
    if missing:
        sys.exit(f"Missing: {missing}. Run step3_clean.py first.")

    by_source = defaultdict(list)
    by_source_domain = defaultdict(list)
    by_domain = defaultdict(list)
    lang_share = defaultdict(Counter)
    domain_sources = defaultdict(Counter)
    all_texts = []
    for p in inputs:
        for r in read_jsonl(p):
            t, s, d = r["raw_text"], r["source_dataset"], r["domain"]
            by_source[s].append(t)
            by_source_domain[(s, d)].append(t)
            by_domain[d].append(t)
            all_texts.append(t)
            lang_share[s][parse_notes(r.get("notes", "")).get("langcheck", "n/a")] += 1

    # ---- per dataset
    rows = []
    for s, texts in sorted(by_source.items(), key=lambda kv: -len(kv[1])):
        prof = punct_profile(texts)
        ls = lang_share[s]
        tot = sum(ls.values()) or 1
        rows.append({"language": args.lang, "dataset": s, "role": "text corpus",
                     "langcheck_lang_pct": round(100 * ls[C.LANG] / tot, 1),
                     "langcheck_uncertain_pct": round(100 * ls["uncertain"] / tot, 1),
                     **{k: prof[k] for k in STAT_COLS}})
    all_prof = punct_profile(all_texts)
    rows.append({"language": args.lang, "dataset": "ALL (clean corpus)", "role": "text corpus",
                 "langcheck_lang_pct": "", "langcheck_uncertain_pct": "",
                 **{k: all_prof[k] for k in STAT_COLS}})
    for p in aux:
        if not p.exists():
            continue
        texts = [r["raw_text"] for r in read_jsonl(p)]
        if texts:
            prof = punct_profile(texts)
            rows.append({"language": args.lang, "dataset": p.stem.replace(f"{args.lang}_", ""),
                         "role": "speech transcript (gap analysis)",
                         "langcheck_lang_pct": "", "langcheck_uncertain_pct": "",
                         **{k: prof[k] for k in STAT_COLS}})
    write_csv(C.REPORTS / f"{args.lang}_punctuation_stats.csv", rows)

    # ---- per dataset x domain
    sd_rows = []
    for (s, d), texts in sorted(by_source_domain.items()):
        prof = punct_profile(texts)
        sd_rows.append({"dataset": s, "domain": d, "target_domain": d in C.TARGET_DOMAINS,
                        "records": prof["records"], "tokens": prof["tokens"],
                        "punct_per_100_tokens": prof["punct_per_100_tokens"],
                        "terminal_end_pct": prof["terminal_end_pct"],
                        "punct_quality": prof["punct_quality"]})
    write_csv(C.REPORTS / f"{args.lang}_punctuation_by_domain.csv", sd_rows)

    # ---- domain coverage vs targets
    for (s, d), texts in by_source_domain.items():
        domain_sources[d][s] += sum(1 for _ in texts)
    cov = []
    for d in C.TARGET_DOMAINS + sorted(set(by_domain) - set(C.TARGET_DOMAINS)):
        prof = punct_profile(by_domain.get(d, []))
        tok = prof["tokens"]
        is_target = d in C.TARGET_DOMAINS
        cov.append({"domain": d, "target_domain": "yes" if is_target else "no",
                    "records": prof["records"], "tokens": tok,
                    "target_tokens": C.TARGET_TOKENS_PER_DOMAIN if is_target else "",
                    "pct_of_target": round(100 * tok / C.TARGET_TOKENS_PER_DOMAIN, 1) if is_target else "",
                    "gap_tokens": max(0, C.TARGET_TOKENS_PER_DOMAIN - tok) if is_target else "",
                    "sources": "; ".join(f"{k}:{v}" for k, v in domain_sources[d].most_common())})
    write_csv(C.REPORTS / f"{args.lang}_domain_coverage.csv", cov)

    # ---- markdown summary
    total = all_prof["tokens"]
    target_tok = sum(r["tokens"] for r in cov if r["target_domain"] == "yes")
    md = [f"# {C.LANG_NAME} ({args.lang}) data statistics\n",
          *([f"- Domains (strict): {', '.join(C.TARGET_DOMAINS)}; text outside them was dropped"] if C.STRICT_DOMAINS else []),
          f"- Clean corpus: **{all_prof['records']:,} records, {total:,} word tokens**",
          f"- Against the 1,000,000-token working target: **{100 * total / C.TARGET_TOKENS_TOTAL:.1f}%**; "
          f"against the 500,000 fallback: **{100 * total / C.FALLBACK_TOKENS_TOTAL:.1f}%**",
          f"- Tokens in the five project domains: **{target_tok:,}** "
          f"({100 * target_tok / (5 * C.TARGET_TOKENS_PER_DOMAIN):.1f}% of 5 x 200,000)\n",
          "## Punctuation statistics by dataset\n",
          md_table(rows, ["dataset", "role", "records", "tokens", "punct_per_100_tokens", "commas_per_100",
                          "any_punct_pct", "terminal_end_pct", "starts_upper_pct", "all_lowercase_pct",
                          "langcheck_lang_pct", "punct_quality"]
                 + (["special_char_token_pct", "tone_marked_token_pct"] if C.SPECIAL_CHARS else [])),
          "\n## Domain coverage (tokens vs 200,000 per domain)\n",
          md_table(cov, ["domain", "target_domain", "records", "tokens", "pct_of_target", "gap_tokens", "sources"]),
          "\n## PnC label distribution (share of word tokens)\n",
          md_table(rows, ["dataset", "label_O_pct", "label_COMMA_pct", "label_PERIOD_pct",
                          "label_QUESTION_pct", "label_EXCLAMATION_pct"])]
    (C.REPORTS / f"{args.lang}_stats_summary.md").write_text("\n".join(md), encoding="utf-8")

    print("\n".join(md[:4]))
    print(f"\nReports written to {C.REPORTS.relative_to(C.ROOT)}/ ({args.lang}_punctuation_stats.csv, "
          f"{args.lang}_domain_coverage.csv, {args.lang}_stats_summary.md, ...)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
