"""
STEP 4 - Validate JSONL files against the shared schema (works for ANY team language).

    python step4_validate_schema.py                                  # checks data/clean/pcm_clean.jsonl
    python step4_validate_schema.py --inputs swa.jsonl yor.jsonl pcm.jsonl --merge-out all_languages.jsonl

Checks: exact field set and order, value types, strict UTF-8, NFC normalisation,
language code, domain label, ID pattern and that the ID's domain matches the
domain field, duplicate IDs (within and across files), empty text, licence present,
review_status value. Exit code 1 if any error is found, so it can gate a merge.
"""
import argparse
import json
import re
import sys
import unicodedata
from collections import Counter
from pathlib import Path

import config as C

LANG_CODES = {"swa", "yor", "kin", "ibo", "pcm"}
ID_RE = re.compile(r"^(swa|yor|kin|ibo|pcm)_([a-z_]+)_(\d{4,})$")


def validate(paths: list[Path], allowed_domains: set[str]) -> tuple[list[str], list[dict], Counter]:
    errors, records = [], []
    ids = Counter()
    summary = Counter()
    for p in paths:
        raw = p.read_bytes()
        try:
            text = raw.decode("utf-8", errors="strict")
        except UnicodeDecodeError as e:
            errors.append(f"{p.name}: not valid UTF-8 ({e})")
            continue
        if text.startswith("﻿"):
            errors.append(f"{p.name}: file starts with a BOM")
        for n, line in enumerate(text.splitlines(), 1):
            if not line.strip():
                continue
            where = f"{p.name}:{n}"
            try:
                r = json.loads(line)
            except json.JSONDecodeError as e:
                errors.append(f"{where}: invalid JSON ({e})")
                continue
            if list(r.keys()) != C.SCHEMA_FIELDS:
                missing = [f for f in C.SCHEMA_FIELDS if f not in r]
                extra = [f for f in r if f not in C.SCHEMA_FIELDS]
                if missing or extra:
                    errors.append(f"{where}: fields missing={missing} extra={extra}")
                else:
                    summary["field_order_differs"] += 1
            for f in C.SCHEMA_FIELDS:
                if f in r and not isinstance(r[f], str):
                    errors.append(f"{where}: field '{f}' must be a string")
            rid = str(r.get("id", ""))
            ids[rid] += 1
            m = ID_RE.match(rid)
            if not m:
                errors.append(f"{where}: bad id '{rid}' (expected e.g. pcm_health_0001)")
            else:
                if m.group(1) != r.get("language"):
                    errors.append(f"{where}: id language '{m.group(1)}' != language '{r.get('language')}'")
                if m.group(2) != r.get("domain"):
                    errors.append(f"{where}: id domain '{m.group(2)}' != domain '{r.get('domain')}'")
            if r.get("language") not in LANG_CODES:
                errors.append(f"{where}: unknown language '{r.get('language')}'")
            if r.get("domain") not in allowed_domains:
                errors.append(f"{where}: domain '{r.get('domain')}' not in agreed list")
            t = r.get("raw_text", "")
            if not str(t).strip():
                errors.append(f"{where}: empty raw_text")
            elif unicodedata.normalize("NFC", t) != t:
                errors.append(f"{where}: raw_text is not NFC-normalised")
            if not str(r.get("license", "")).strip():
                errors.append(f"{where}: missing license")
            if not str(r.get("source_dataset", "")).strip():
                errors.append(f"{where}: missing source_dataset")
            if r.get("review_status") not in C.REVIEW_STATUSES:
                errors.append(f"{where}: review_status '{r.get('review_status')}' not in {C.REVIEW_STATUSES}")
            summary[f"lang={r.get('language')}"] += 1
            summary[f"domain={r.get('domain')}"] += 1
            records.append(r)
    for rid, c in ids.items():
        if c > 1:
            errors.append(f"duplicate id '{rid}' appears {c} times")
    return errors, records, summary


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--inputs", nargs="*", default=[str(C.CLEAN_DIR / f"{C.LANG}_clean.jsonl")])
    ap.add_argument("--extra-domains", nargs="*", default=[],
                    help="additional domain labels the team agreed on (e.g. politics_government)")
    ap.add_argument("--merge-out", help="if valid, write all inputs merged into this file")
    args = ap.parse_args()

    paths = [Path(p) for p in args.inputs]
    missing = [str(p) for p in paths if not p.exists()]
    if missing:
        sys.exit(f"Missing input files: {missing}")
    allowed = set(C.DOMAIN_VOCAB) | set(args.extra_domains)
    errors, records, summary = validate(paths, allowed)

    print(f"Checked {len(records):,} records in {len(paths)} file(s).")
    for k, v in sorted(summary.items()):
        print(f"    {k}: {v:,}")
    if errors:
        print(f"\nFAILED with {len(errors):,} error(s). First 30:")
        for e in errors[:30]:
            print("   ", e)
        return 1
    print("\nPASSED: all records match the shared schema.")
    if args.merge_out:
        with open(args.merge_out, "w", encoding="utf-8", newline="\n") as f:
            for r in records:
                f.write(json.dumps(r, ensure_ascii=False) + "\n")
        print(f"Merged file written: {args.merge_out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
