"""Turn wiki_raw.jsonl into passages in the shared schema, with the same quality gates as the main pool.

Gates: paragraph >= 25 words, ends with terminal punctuation, Swahili function-word ratio, low English ratio,
caption filter, exact + near-duplicate (word 8-gram Jaccard >= 0.5) against itself and against swahili_shared.jsonl.
Output is AUTO-FILTERED and UNREVIEWED (no AI or human domain decision), licence CC BY-SA 4.0 (attribution + share-alike).
"""
import json, re, os, csv, collections, unicodedata
from caption_filter import is_caption

OUT = os.path.dirname(os.path.abspath(__file__))
SW = set("na ya wa kwa ni katika za la cha hii huu kuwa pia au ambayo hiyo vya kama hadi kutoka huo hizo yake wake lake ili sana kuhusu lakini kwamba pamoja".split())
EN = set("the of and is in to was were with for that this from which are by".split())
TERM = tuple('.!?"”)»…')


def words(t): return len(t.split())


def clean_para(p):
    p = unicodedata.normalize("NFC", re.sub(r"\s+", " ", p)).strip()
    p = re.sub(r"\[\d+\]", "", p)
    return p


def shingles(t, n=8):
    w = re.findall(r"\w+", t.lower())
    return {hash(" ".join(w[i:i + n])) for i in range(max(len(w) - n + 1, 1))}


def is_swahili(t):
    toks = re.findall(r"[a-zA-Z']+", t.lower())
    if not toks: return False
    sw = sum(x in SW for x in toks) / len(toks); en = sum(x in EN for x in toks) / len(toks)
    return sw >= 0.08 and en <= 0.04


cands, rej = [], collections.Counter()
for line in open(os.path.join(OUT, "wiki_raw.jsonl"), encoding="utf-8"):
    a = json.loads(line)
    for para in a["text"].split("\n"):
        para = clean_para(para)
        if not para or para.startswith("="): continue
        if words(para) < 25: rej["short"] += 1; continue
        if not para.endswith(TERM): rej["no_terminal_punct"] += 1; continue
        if not is_swahili(para): rej["not_swahili"] += 1; continue
        if is_caption(para): rej["caption_like"] += 1; continue
        cands.append({**{k: a[k] for k in ("domain", "title", "url", "category", "lastrevid")}, "text": para})

# reference shingles from the existing pool
ref = []
with open(os.path.join(OUT, "swahili_shared.jsonl"), encoding="utf-8") as f:
    for line in f: ref.append(shingles(json.loads(line)["raw_text"]))
inv = collections.defaultdict(list)
for i, s in enumerate(ref):
    for h in s: inv[h].append(i)


def dup_of_pool(sh):
    cnt = collections.Counter()
    for h in sh:
        for j in inv.get(h, ()): cnt[j] += 1
    return any(c / (len(sh) + len(ref[j]) - c) >= 0.5 for j, c in cnt.items())


seen_txt, seen_sh, final = set(), [], []
local_inv = collections.defaultdict(list)
for c in cands:
    k = re.sub(r"\s+", " ", c["text"]).lower()
    if k in seen_txt: rej["exact_dup"] += 1; continue
    sh = shingles(c["text"])
    if dup_of_pool(sh): rej["near_dup_vs_pool"] += 1; continue
    cnt = collections.Counter()
    for h in sh:
        for j in local_inv.get(h, ()): cnt[j] += 1
    if any(n / (len(sh) + len(seen_sh[j]) - n) >= 0.5 for j, n in cnt.items()): rej["near_dup_within_wiki"] += 1; continue
    seen_txt.add(k); idx = len(seen_sh); seen_sh.append(sh)
    for h in sh: local_inv[h].append(idx)
    final.append(c)

counters = collections.Counter(); wc = collections.Counter(); rows = []
with open(os.path.join(OUT, "wiki_candidates.jsonl"), "w", encoding="utf-8", newline="\n") as f:
    for c in final:
        d = c["domain"]; counters[d] += 1; wc[d] += words(c["text"])
        rec = {"id": f"swa_{d}_wiki_{counters[d]:05d}", "language": "swa", "domain": d, "raw_text": c["text"],
               "source_dataset": "sw.wikipedia.org: " + c["title"], "source_split": "unspecified",
               "license": "CC-BY-SA-4.0 (Wikipedia; attribution and share-alike apply)", "review_status": "auto_filtered_unreviewed",
               "notes": f"category:{c['category']}; revid:{c['lastrevid']}; url:{c['url']}; domain_from_category_only"}
        f.write(json.dumps(rec, ensure_ascii=False) + "\n")
summary = {"paragraph_candidates": len(cands), "final_passages": len(final), "words_per_domain": dict(wc), "total_words": sum(wc.values()), "rejections": dict(rej)}
json.dump(summary, open(os.path.join(OUT, "wiki_summary.json"), "w", encoding="utf-8"), indent=2)
print(json.dumps(summary, indent=2))

# ---------- strict domain-relevance filter (lexicon, >= 2 distinct stems in the passage) ----------
LEX = {
    "law": "sheri mahakam jaji hakim katiba haki kifungu mkataba wakili kesi hukumu adhabu uhalifu mashtaka bunge uchaguzi polisi gereza azimio itifaki mwanasheria kanuni".split(),
    "telecoms": "simu mawasiliano intaneti mtandao redio televisheni setilaiti satelaiti utangazaji posta masafa ujumbe waya mnara wireless broadband gsm 3g 4g 5g mpokeaji".split(),
    "finance": "benki fedha pesa uchumi biashara bima mkopo soko hisa kodi bei mapato faida uwekezaji mtaji sarafu shilingi dola malipo akiba mteja kampuni".split(),
    "agriculture": "kilimo mazao mkulima wakulima shamba mbegu udongo mifugo ng'ombe mbolea mavuno zao mmea mimea ufugaji kuku maziwa umwagiliaji wadudu mvua".split(),
    "health": "afya ugonjwa magonjwa dawa tiba daktari hospitali chanjo mgonjwa virusi bakteria dalili matibabu lishe mimba damu kinga maambukizi".split(),
}
RXL = {d: [re.compile(r"\b" + re.escape(st) + r"\w*", re.I) for st in v] for d, v in LEX.items()}
strict, swc = [], collections.Counter()
with open(os.path.join(OUT, "wiki_candidates.jsonl"), encoding="utf-8") as f, \
     open(os.path.join(OUT, "wiki_candidates_strict.jsonl"), "w", encoding="utf-8", newline="\n") as g:
    for line in f:
        r = json.loads(line)
        hits = sum(1 for rx in RXL[r["domain"]] if rx.search(r["raw_text"]))
        if hits >= 2:
            r["notes"] += f"; domain_lexicon_hits:{hits}"
            g.write(json.dumps(r, ensure_ascii=False) + "\n"); swc[r["domain"]] += len(r["raw_text"].split())
summary["strict_words_per_domain"] = dict(swc); summary["strict_total_words"] = sum(swc.values())
json.dump(summary, open(os.path.join(OUT, "wiki_summary.json"), "w", encoding="utf-8"), indent=2)
print("strict", dict(swc), sum(swc.values()))
