"""Swahili question set from TyDi QA (apache-2.0 on card; text from sw.wikipedia, CC BY-SA) and Belebele (cc-by-sa-4.0).
Domain tag = lexicon stems (same lexicon as process_wikipedia.py) found in the question only (article-level tagging was tried and dropped: it tagged giraffe and city articles as agriculture).
Output: questions_swahili.jsonl (shared-style schema, review_status auto_tagged_unreviewed), questions_summary.json.
"""
import json, re, os, collections, duckdb
OUT = os.path.dirname(os.path.abspath(__file__)); EXT = os.path.join(OUT, "external")
LEX = {
    "law": "sheri mahakam jaji hakim katiba haki mkataba wakili kesi hukumu adhabu uhalifu mashtaka bunge uchaguzi polisi gereza azimio itifaki mwanasheria kanuni".split(),
    "telecoms": "simu mawasiliano intaneti mtandao redio televisheni setilaiti satelaiti utangazaji posta masafa ujumbe waya mnara wireless broadband gsm mpokeaji".split(),
    "finance": "benki fedha pesa uchumi biashara bima mkopo soko hisa kodi bei mapato faida uwekezaji mtaji sarafu shilingi dola malipo akiba mteja kampuni".split(),
    "agriculture": "kilimo mazao mkulima wakulima shamba mbegu udongo mifugo ng'ombe mbolea mavuno zao mmea mimea ufugaji kuku maziwa umwagiliaji wadudu mvua".split(),
    "health": "afya ugonjwa magonjwa dawa tiba daktari hospitali chanjo mgonjwa virusi bakteria dalili matibabu lishe mimba damu kinga maambukizi".split(),
}
RX = {d: [re.compile(r"\b" + re.escape(s) + r"\w*", re.I) for s in v] for d, v in LEX.items()}
def hits(t): return {d: sum(1 for r in rs if r.search(t)) for d, rs in RX.items()}
def tag(q, doc):
    hq = hits(q); best = max(hq, key=hq.get)
    if hq[best] >= 1 and sorted(hq.values())[-2] < hq[best]: return best, "question_lexicon"
    if False:
        hd = hits(doc); b = max(hd, key=hd.get)
        if hd[b] >= 3 and sorted(hd.values())[-2] < hd[b]: return b, "article_lexicon"
    return None, None
fix = lambda q: re.sub(r"^(Je),(\S)", r"\1, \2", q.strip())
recs = []
c = duckdb.connect()
for q, title, url, doc in c.sql("select question_text, document_title, document_url, document_plaintext from '%s' where language='swahili'" % os.path.join(EXT, "tydi_val.parquet").replace("\\", "/")).fetchall():
    q = fix(q); d, how = tag(q, doc)
    recs.append({"language": "swa", "domain": d or "other", "raw_text": q, "source_dataset": "TyDi QA primary_task validation (Swahili)", "source_split": "validation",
                 "license": "apache-2.0 (dataset card); article text sw.wikipedia CC BY-SA", "review_status": "auto_tagged_unreviewed", "notes": f"article={title}; tag={how}"})
for l in open(os.path.join(EXT, "belebele_swh.jsonl"), encoding="utf-8"):
    r = json.loads(l); q = r["question"].strip(); d, how = tag(q, r["flores_passage"])
    recs.append({"language": "swa", "domain": d or "other", "raw_text": q, "source_dataset": "Belebele swh_Latn (FLORES passages)", "source_split": "test",
                 "license": "cc-by-sa-4.0 (dataset card)", "review_status": "auto_tagged_unreviewed", "notes": f"tag={how}"})
seen, out = set(), []
for r in recs:
    k = r["raw_text"].lower()
    if k in seen or not r["raw_text"].endswith("?"): continue
    seen.add(k); out.append(r)
for i, r in enumerate(out, 1): r["id"] = f"swa_q_{i:05d}"
with open(os.path.join(OUT, "questions_swahili.jsonl"), "w", encoding="utf-8", newline="\n") as f:
    for r in out: f.write(json.dumps(r, ensure_ascii=False) + "\n")
S = collections.Counter((r["source_dataset"].split()[0], r["domain"]) for r in out)
summ = {"total_questions": len(out), "by_source_domain": {f"{a}/{b}": v for (a, b), v in sorted(S.items())}, "words": sum(len(r["raw_text"].split()) for r in out)}
json.dump(summ, open(os.path.join(OUT, "questions_summary.json"), "w"), indent=1); print(json.dumps(summ, indent=1))
