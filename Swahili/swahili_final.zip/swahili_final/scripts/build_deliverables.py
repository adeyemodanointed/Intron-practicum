"""Build Michael's Swahili deliverables from the AI-screened review workbook.

Everything produced here is AI-screened. Nothing is recorded as human-verified.
"""
import csv, json, random, re, collections, os
import openpyxl

XLSX = r"C:\Users\HP\Downloads\ALL_PASSAGES_HUMAN_REVIEW_CLEANED.xlsx"
HOLD = r"C:\Users\HP\OneDrive\Documents\Practicum\outputs\agent-work-2026-09-29\duplicate_reconciliation\quarantine_manifest.jsonl"
OUT = os.path.dirname(os.path.abspath(__file__))

wb = openpyxl.load_workbook(XLSX, read_only=True)
it = wb.active.iter_rows(values_only=True)
H = next(it)
rows = [dict(zip(H, r)) for r in it if r and r[1]]

hold_ids, hold_split = set(), {}
with open(HOLD, encoding="utf-8") as f:
    for line in f:
        m = json.loads(line)
        hold_ids.add(m["id"]); hold_split[m["id"]] = m.get("source_split")


def legacy_id(r):
    return (r["locator"] or "").split(",")[0].strip() or r["id"]


def final_text(r):
    if r["decision"] == "NEEDS_EDIT" and r["corrected_text"]:
        return r["corrected_text"]
    return r["cleaned_text"]


def words(t):
    return len(t.split())


for r in rows:
    r["lid"] = legacy_id(r)
    r["held"] = r["lid"] in hold_ids
    r["text"] = final_text(r)
    r["domain"] = r["reviewed_domain"] or r["candidate_domain"]

# ---------- 1. shared JSONL ----------
def licence_tier(r):
    src = r["src"].lower()
    if r["licence_review_status"] == "documented_terms_check_conditions":
        return "documented", r["licence"]
    if "afrivoice" in src:
        return "dataset_card_cc_by_4.0", "CC-BY-4.0 (dataset card, DigitalUmuganda/Afrivoice_Swahili)"
    if "fineweb" in src:
        return "dataset_odc_by_client_approved", "ODC-By (HuggingFaceFW/fineweb-2); client approved use (relayed by Michael 2026-10-05; written confirmation pending)"
    return "unresolved", r["licence"] or "unresolved"

def norm(t): return re.sub(r"\s+", " ", t).strip().lower()

for r in rows:
    r["src"] = r["source_title"] or r["publisher"] or "unspecified_source"
from caption_filter import is_caption, score as cap_score
cands_all = [r for r in rows if r["decision"] in ("ACCEPT", "NEEDS_EDIT") and not r["held"]]
for r in cands_all: r["caption_score"] = cap_score(r["text"])
cands = [r for r in cands_all if not is_caption(r["text"])]
cap_excl = [r for r in cands_all if is_caption(r["text"])]
with open(os.path.join(OUT, "caption_exclusions.csv"), "w", encoding="utf-8-sig", newline="") as f:
    w = csv.writer(f); w.writerow(["review_id", "domain", "source", "caption_score", "words", "text_start"])
    for r in cap_excl: w.writerow([r["id"], r["domain"], r["src"], r["caption_score"], words(r["text"]), r["text"][:160]])
before_words = {d: sum(words(r["text"]) for r in cands_all if r["domain"] == d) for d in ["agriculture","finance","health","law","telecoms"]}
seen_txt, keep, exact_dups = set(), [], 0
for r in cands:
    k = norm(r["text"])
    if k in seen_txt: exact_dups += 1; continue
    seen_txt.add(k); keep.append(r)
# near-duplicate pass: word 8-gram Jaccard >= 0.5 within the same domain; keep the longest of each cluster
def shingles(t, n=8):
    w = re.findall(r"\w+", t.lower())
    return {hash(" ".join(w[i:i+n])) for i in range(max(len(w) - n + 1, 1))}
for r in keep: r["sh"] = shingles(r["text"])
parent = list(range(len(keep)))
def find(x):
    while parent[x] != x: parent[x] = parent[parent[x]]; x = parent[x]
    return x
inv = collections.defaultdict(list)
for i, r in enumerate(keep):
    cnt = collections.Counter()
    for h in r["sh"]:
        for j in inv[h]: cnt[j] += 1
        inv[h].append(i)
    for j, c in cnt.items():
        if keep[j]["domain"] != r["domain"]: continue
        jac = c / (len(r["sh"]) + len(keep[j]["sh"]) - c)
        if jac >= 0.5: parent[find(i)] = find(j)
clusters = collections.defaultdict(list)
for i in range(len(keep)): clusters[find(i)].append(i)
drop = set(); nd_rows = []
for c in clusters.values():
    if len(c) > 1:
        c.sort(key=lambda i: -len(keep[i]["text"]))
        for i in c[1:]:
            drop.add(i); nd_rows.append([keep[i]["id"], keep[i]["domain"], keep[i]["src"], keep[c[0]]["id"], words(keep[i]["text"])])
with open(os.path.join(OUT, "near_dup_exclusions.csv"), "w", encoding="utf-8-sig", newline="") as f:
    w = csv.writer(f); w.writerow(["review_id", "domain", "source", "kept_review_id", "words"]); w.writerows(nd_rows)
near_dup_removed = len(drop); near_dup_words = sum(r[4] for r in nd_rows)
keep = [r for i, r in enumerate(keep) if i not in drop]
gsize = collections.Counter(r["duplicate_group_id"] for r in keep)
multi_groups = sum(1 for v in gsize.values() if v > 1)
multi_members = sum(v for v in gsize.values() if v > 1)
counters = collections.Counter(); mapping = []; bad = 0
with open(os.path.join(OUT, "swahili_shared.jsonl"), "w", encoding="utf-8", newline="\n") as f:
    for r in keep:
        counters[r["domain"]] += 1
        rid = f"swa_{r['domain']}_{counters[r['domain']]:05d}"
        r["new_id"] = rid
        status = "ai_screened_accepted" if r["decision"] == "ACCEPT" else "ai_screened_needs_edit_corrected"
        note = []
        if "bulk_screened_not_individually_read" in (r["quality_flags"] or ""): note.append("bulk_screened_not_individually_read")
        tier, lic = licence_tier(r)
        r["tier"] = tier
        note.append("licence_tier:" + tier)
        if r["domain"] == "law" and "fineweb" in r["src"].lower(): note.append("law_subtype:news_web")
        elif r["domain"] == "law": note.append("law_subtype:legal_or_other_document")
        if gsize[r["duplicate_group_id"]] > 1: note.append("near_dup_group:" + str(r["duplicate_group_id"]))
        if r["source_title"] is None: note.append("source_from_publisher_field")
        rec = {"id": rid, "language": "swa", "domain": r["domain"], "raw_text": r["text"],
               "source_dataset": r["src"], "source_split": hold_split.get(r["lid"]) or "unspecified",
               "license": lic, "review_status": status, "notes": "; ".join(note)}
        if any(not rec[k] for k in ("id", "domain", "raw_text", "source_dataset", "license")): bad += 1
        mapping.append({"new_id": rid, "review_id": r["id"], "locator": r["locator"]})
        f.write(json.dumps(rec, ensure_ascii=False) + "\n")
with open(os.path.join(OUT, "id_mapping.csv"), "w", encoding="utf-8-sig", newline="") as f:
    w = csv.DictWriter(f, fieldnames=["new_id", "review_id", "locator"]); w.writeheader(); w.writerows(mapping)
dups = exact_dups

# ---------- 2. punctuation statistics ----------
TERM = tuple('.!?"”)»…')


def pstats(subset):
    n = len(subset); w = sum(words(r["text"]) for r in subset)
    c = collections.Counter()
    term = nopunct = 0
    for r in subset:
        t = r["text"].strip()
        if t.endswith(TERM): term += 1
        if not re.search(r"[.,!?;:]", t): nopunct += 1
        for ch in ",.?!;:": c[ch] += t.count(ch)
    per = lambda k: round(100 * c[k] / w, 2) if w else 0
    return {"passages": n, "words": w, "pct_terminal_punct": round(100 * term / n, 1) if n else 0,
            "pct_no_punct": round(100 * nopunct / n, 1) if n else 0,
            "commas_per100w": per(","), "periods_per100w": per("."), "question_per100w": per("?"),
            "exclam_per100w": per("!"), "semicolon_per100w": per(";"), "colon_per100w": per(":")}


def write_csv(name, header, data):
    with open(os.path.join(OUT, name), "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=header); w.writeheader(); w.writerows(data)


doms = ["agriculture", "finance", "health", "law", "telecoms"]
ps = []
for d in doms + ["ALL"]:
    sub = [r for r in keep if d == "ALL" or r["domain"] == d]
    ps.append({"language": "swa", "domain": d, **pstats(sub)})
write_csv("punctuation_stats.csv", list(ps[0].keys()), ps)

# ---------- 4. validation sample ----------
rng = random.Random(42)
sample = []
quota = {"REJECT": 4, "NEEDS_EDIT": 2}
for d in doms:
    pool = collections.defaultdict(list)
    for r in rows:
        if r["domain"] == d or r["candidate_domain"] == d:
            if not r["held"]: pool[r["decision"]].append(r)
    pick = []
    for dec, q in quota.items():
        pick += rng.sample(pool[dec], min(q, len(pool[dec])))
    rest = 20 - len(pick)
    pick += rng.sample(pool["ACCEPT"], min(rest, len(pool["ACCEPT"])))
    sample += pick
rng.shuffle(sample)
vs = []
for i, r in enumerate(sample, 1):
    vs.append({"sample_id": f"V{i:03d}", "domain": r["candidate_domain"], "source_dataset": r["src"],
               "passage_id": r["lid"], "text": r["text"], "ai_decision": r["decision"],
               "ai_note": r["reviewer_notes"], "individually_read_by_ai": "bulk_screened_not_individually_read" not in (r["quality_flags"] or ""),
               "reviewer1_name": "", "reviewer1_decision": "", "reviewer1_notes": "",
               "reviewer2_name": "", "reviewer2_decision": "", "reviewer2_notes": ""})
write_csv("manual_validation_sample.csv", list(vs[0].keys()), vs)

# ---------- 5. presentation table ----------
keep_ids = {id(r) for r in keep}
grp = collections.defaultdict(list)
for r in rows:
    grp[(r["src"], r["domain"])].append(r)
pt = []
for (src, d), rs in sorted(grp.items(), key=lambda x: -sum(words(r["text"]) for r in x[1])):
    acc = [r for r in rs if id(r) in keep_ids]
    tiers = collections.Counter(licence_tier(r)[0] for r in acc)
    lic = licence_tier(acc[0])[1] if acc else (rs[0]["licence"] or "unresolved")
    cleared = acc and all(t in ("documented", "dataset_card_cc_by_4.0") for t in tiers)
    p = pstats(acc) if acc else {"pct_terminal_punct": 0, "words": 0}
    rej = sum(r["decision"] == "REJECT" for r in rs)
    pt.append({"language": "swa", "domain": d, "source_dataset": src, "licence": lic,
               "candidate_passages": len(rs), "ai_rejected": rej,
               "accepted_passages": len(acc), "accepted_words": p["words"],
               "domain_target_words": 200000, "pct_terminal_punct": p["pct_terminal_punct"],
               "validation_result": "Human review by Michael (n=100, stratified, all sources pooled): keep 19%; 35% among caption-filter passes. Second reviewer and fluent-speaker check pending",
               "decision": "use (licence stated at dataset level; confirm conditions)" if cleared else
                           ("reject" if not acc else "hold: rights unresolved")})
write_csv("presentation_table.csv", list(pt[0].keys()), pt)

# ---------- summary ----------
tot = collections.Counter(r["decision"] for r in rows)
tier_words = {d: collections.Counter() for d in ["agriculture","finance","health","law","telecoms"]}
for r in keep: tier_words[r["domain"]][r["tier"]] += words(r["text"])
summ = {"near_dup_removed_passages": near_dup_removed, "near_dup_removed_words": near_dup_words, "licence_tier_words_per_domain": {d: dict(v) for d, v in tier_words.items()}, "words_before_caption_filter": before_words, "caption_filtered_passages": len(cap_excl), "caption_filtered_words": sum(words(r["text"]) for r in cap_excl), "rows": len(rows), "decisions": dict(tot), "held_by_dup_manifest": sum(r["held"] for r in rows),
        "held_accepted": sum(1 for r in rows if r["held"] and r["decision"] in ("ACCEPT", "NEEDS_EDIT")),
        "jsonl_records": len(keep), "exact_text_duplicates_removed": dups, "near_dup_groups_with_multiple_kept": multi_groups, "near_dup_kept_members": multi_members, "hold_manifest_ids_matching_pool": len(hold_ids & set(r["lid"] for r in rows)), "jsonl_missing_field_records": bad,
        "bulk_not_individually_read_accepted": sum(1 for r in keep if "bulk_screened_not_individually_read" in (r["quality_flags"] or "")),
        "accepted_documented_licence": sum(1 for r in keep if r["licence_review_status"] == "documented_terms_check_conditions"),
        "validation_sample": len(vs),
        "per_domain_words": {d: sum(words(r["text"]) for r in keep if r["domain"] == d) for d in doms},
        "per_domain_words_documented_licence": {d: sum(words(r["text"]) for r in keep if r["domain"] == d and r["licence_review_status"] == "documented_terms_check_conditions") for d in doms}}
json.dump(summ, open(os.path.join(OUT, "summary.json"), "w", encoding="utf-8"), indent=2)
print(json.dumps(summ, indent=2)); print(len(pt), "presentation rows")
for p in ps: print(p)

# ---------- source register + target gap report ----------
EVID = {"afrivoice": "https://huggingface.co/datasets/DigitalUmuganda/Afrivoice_Swahili",
        "fineweb": "https://huggingface.co/datasets/HuggingFaceFW/fineweb-2"}
reg = collections.defaultdict(lambda: {"passages": 0, "words": 0, "tiers": collections.Counter(), "lic": "", "ev": ""})
for r in keep:
    g = reg[r["src"]]; g["passages"] += 1; g["words"] += words(r["text"])
    t, l = licence_tier(r); g["tiers"][t] += 1; g["lic"] = l
    key = next((k for k in EVID if k in r["src"].lower()), None)
    g["ev"] = g["ev"] or (EVID[key] if key else (r["licence_evidence_url"] or ""))
with open(os.path.join(OUT, "source_register.csv"), "w", encoding="utf-8-sig", newline="") as f:
    w = csv.writer(f); w.writerow(["source_dataset", "passages", "words", "licence_tier", "licence", "evidence_url"])
    for k, g in sorted(reg.items(), key=lambda x: -x[1]["words"]):
        w.writerow([k, g["passages"], g["words"], g["tiers"].most_common(1)[0][0], g["lic"], g["ev"]])
D = ["agriculture", "finance", "health", "law", "telecoms"]
lines = ["# Target gap report (words, whitespace tokens; tokenizer = whitespace word, see README)", "",
         "| Domain | AI-accepted | After caption + near-dup filter | Licence stated (documented or dataset card CC-BY) | + ODC-By dataset, underlying rights unresolved | Target | Gap to target (licence stated) |",
         "|---|---:|---:|---:|---:|---:|---:|"]
tot = collections.Counter()
for d in D:
    tw = tier_words[d]; fin = sum(tw.values())
    lic = tw["documented"] + tw["dataset_card_cc_by_4.0"]; odc = tw["dataset_odc_by_client_approved"]
    tot.update({"b": before_words[d], "f": fin, "l": lic, "o": odc})
    lines.append(f"| {d} | {before_words[d]:,} | {fin:,} | {lic:,} | {lic+odc:,} | 200,000 | {max(200000-lic,0):,} |")
lines.append(f"| **total** | {tot['b']:,} | {tot['f']:,} | {tot['l']:,} | {tot['l']+tot['o']:,} | 1,000,000 (fallback 500,000) | {max(1000000-tot['l'],0):,} |")
open(os.path.join(OUT, "TARGET_GAP.md"), "w", encoding="utf-8").write("\n".join(lines) + "\n")
print("\n".join(lines))
