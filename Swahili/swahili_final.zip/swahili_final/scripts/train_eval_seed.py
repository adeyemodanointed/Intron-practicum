"""Retrain the domain classifier on seed v1 and test on Michael's human-reviewed passages.

Train : seed_v1_10k_per_domain.jsonl (rule-filtered, licence-clear, NOT human-verified), minus any passage that also appears in the test set.
Test  : all 100 passages Michael reviewed; the human-checked domain label is the candidate domain where domain_ok = YES (97 rows).
        Also reported: the 19 passages he kept (gold) and caption-like vs other rows.
Baseline: last week's recipe re-fitted on the 10,000-passage bootstrap sample (weak keyword labels).
Same model spec both times: word 1-2 gram TF-IDF + class-balanced logistic regression.
"""
import json, os, re, collections
import openpyxl
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from caption_filter import is_caption

OUT = os.path.dirname(os.path.abspath(__file__))
CLS = os.path.join(os.path.dirname(OUT), "swahili-classifier-first-2026-10-01")
D = ["agriculture", "finance", "health", "law", "telecoms"]
norm = lambda t: re.sub(r"\s+", " ", t).strip().lower()


def model(min_df):
    return Pipeline([("tfidf", TfidfVectorizer(analyzer="word", lowercase=True, max_df=0.98, max_features=75000, min_df=min_df, ngram_range=(1, 2), norm="l2", smooth_idf=True, sublinear_tf=True, use_idf=True, token_pattern=r"(?u)\b\w\w+\b")),
                     ("classifier", LogisticRegression(C=1.0, class_weight="balanced", max_iter=300, random_state=42))])


# test set
ws = openpyxl.load_workbook(os.path.join(OUT, "manual_validation_sample_EN.xlsx"))["Swahili"]
h = [c.value for c in ws[1]]; ix = {n: i for i, n in enumerate(h)}
test = []
for r in ws.iter_rows(min_row=2, values_only=True):
    test.append({"text": r[ix["raw_text"]].strip(), "domain": r[ix["domain"]], "domain_ok": r[ix["domain_ok"]], "keep": r[ix["keep"]],
                 "caption": is_caption(r[ix["raw_text"]]), "words": len(r[ix["raw_text"]].split())})
test_norm = {norm(t["text"]) for t in test}
verified = [t for t in test if t["domain_ok"] == "YES"]

# seed (train)
Xs, ys, dropped = [], [], 0
for l in open(os.path.join(OUT, "seed_v1_10k_per_domain.jsonl"), encoding="utf-8"):
    r = json.loads(l)
    if norm(r["raw_text"]) in test_norm: dropped += 1; continue
    Xs.append(r["raw_text"]); ys.append(r["domain"])

# baseline (weak labels)
manifest = {json.loads(l)["id"]: json.loads(l)["partition"] for l in open(os.path.join(CLS, "split_manifest.jsonl"), encoding="utf-8")}
Xb, yb = [], []
for l in open(os.path.join(CLS, "bootstrap_training_sample.jsonl"), encoding="utf-8"):
    a = json.loads(l)
    if manifest.get(a["id"]) == "train" and norm(a["text"]) not in test_norm: Xb.append(a["text"]); yb.append(a["domain"])

res = {"train_seed": {"passages": len(Xs), "words": sum(len(x.split()) for x in Xs), "overlap_removed": dropped},
       "train_baseline_weak": {"passages": len(Xb)}, "test_passages_domain_verified": len(verified), "test_words": sum(t["words"] for t in verified)}


def evaluate(name, m, subset, label):
    pred = m.predict([t["text"] for t in subset]); true = [t["domain"] for t in subset]
    acc = accuracy_score(true, pred)
    return {"subset": label, "n": len(subset), "accuracy": round(acc, 3), "pred": list(pred), "true": true}


for name, X, y, md in (("seed_v1", Xs, ys, 2), ("baseline_weak", Xb, yb, 2)):
    m = model(md).fit(X, y)
    subs = {"all human-reviewed, domain verified": verified,
            "gold (Michael kept)": [t for t in verified if t["keep"] == "YES"],
            "caption-like (rule flag)": [t for t in verified if t["caption"]],
            "not caption-like": [t for t in verified if not t["caption"]]}
    res[name] = {k: {kk: vv for kk, vv in evaluate(name, m, s, k).items() if kk in ("n", "accuracy")} for k, s in subs.items()}
    ev = evaluate(name, m, verified, "all")
    res[name]["per_class"] = classification_report(ev["true"], ev["pred"], labels=D, output_dict=True, zero_division=0)
    res[name]["confusion_labels"] = D
    res[name]["confusion"] = confusion_matrix(ev["true"], ev["pred"], labels=D).tolist()
json.dump(res, open(os.path.join(OUT, "classifier_seed_eval.json"), "w", encoding="utf-8"), indent=1)
print(json.dumps({k: v for k, v in res.items() if k in ("train_seed", "train_baseline_weak", "test_passages_domain_verified", "test_words")}))
for name in ("seed_v1", "baseline_weak"):
    print("\n==", name)
    for k, v in res[name].items():
        if k not in ("per_class",) and isinstance(v, dict) and "accuracy" in v: print(f"  {k:40s} n={v['n']:3d} accuracy={v['accuracy']:.3f}")
    pc = res[name]["per_class"]; print("  per class recall:", {d: round(pc[d]["recall"], 2) for d in D}, " precision:", {d: round(pc[d]["precision"], 2) for d in D})
    print("  confusion (rows=true, cols=pred", D, "):")
    for d, row in zip(D, res[name]["confusion"]): print("   ", f"{d:12s}", row)
