"""FineWeb-2 Swahili TRAIN file (local copy external/fineweb2_swh_train.parquet; ODC-By; use approved by the client, written confirmation pending).
Targets agriculture, finance and telecoms (the domains still short). Same rules as the other pipelines: 40-200 word passages, quality_rules, Swahili check, no replacement chars,
domain = the lexicon with >= 2 distinct stems and a strictly higher count than the others, 8-gram near-duplicate removal (vs this run and vs the test-shard passages).
Selection choices that are not quality rules: hosts that look machine-translated or spam are skipped (hostname starts 'sw.', libretexts, cryptosignals, binaryoptions, airbnb);
each domain stops at CAP words so that the run ends and one site cannot dominate: at most HOSTCAP words per host per domain.
"""
import json, os, re, sys, unicodedata, collections, duckdb
import quality_rules as Q
OUT = os.path.dirname(os.path.abspath(__file__)); SRC = os.path.join(OUT, "external", "fineweb2_swh_train.parquet").replace("\\", "/")
CAP, HOSTCAP = 120000, 9000
LEX = {
    "agriculture": "kilimo mazao mkulima wakulima shamba mbegu udongo mifugo ng'ombe mbolea mavuno zao mmea mimea ufugaji kuku maziwa umwagiliaji wadudu mvua kahawa mahindi".split(),
    "finance": "benki fedha pesa uchumi biashara bima mkopo soko hisa kodi bei mapato faida uwekezaji mtaji sarafu shilingi dola malipo akiba mteja kampuni".split(),
    "telecoms": "simu mawasiliano intaneti mtandao redio televisheni setilaiti satelaiti utangazaji posta masafa ujumbe waya mnara wireless broadband gsm mpokeaji".split(),
}
RX = {d: [re.compile(r"\b" + re.escape(s) + r"\w*", re.I) for s in v] for d, v in LEX.items()}
SW = set("na ya wa kwa ni katika za la cha hii huu kuwa pia au ambayo hiyo vya kama hadi kutoka huo hizo yake wake lake ili sana kuhusu lakini kwamba pamoja".split())
EN = set("the of and is in to was were with for that this from which are by".split())
def is_sw(t):
    k = re.findall(r"[a-zA-Z']+", t.lower())
    return bool(k) and sum(x in SW for x in k) / len(k) >= 0.08 and sum(x in EN for x in k) / len(k) <= 0.04
reasons = lambda t: [x for x in Q.reasons(t) if x != "over_long_scraped"]
def sh(t, n=8):
    w = re.findall(r"\w+", t.lower()); return {" ".join(w[i:i+n]) for i in range(max(1, len(w)-n+1))}
badhost = lambda h: h.startswith("sw.") or h.endswith(("libretexts.org", "cryptosignals.org", "binaryoptions.com", "airbnb.com"))
host = lambda u: re.sub(r"^https?://(www\.)?", "", u).split("/")[0]
seen = []
for fn in ("fineweb_agri_fin_kept.jsonl", "fineweb_agri_fin_passages.jsonl"):
    for l in open(os.path.join(OUT, fn), encoding="utf-8"): seen.append(sh(json.loads(l)["raw_text"]))
idx = collections.defaultdict(set)
for i, s in enumerate(seen):
    for g in s: idx[g].add(i)
def is_dup(s8):
    cnt = collections.Counter(j for g in s8 for j in idx.get(g, ()))
    return bool(cnt) and max(cnt.values()) / max(1, len(s8)) >= 0.5
words = collections.Counter(); hostw = collections.Counter(); keep = []; rej = collections.Counter(); docs = 0
cur = duckdb.connect().sql(f"select text, url, id from '{SRC}'")
out = open(os.path.join(OUT, "fineweb_train_passages.jsonl"), "w", encoding="utf-8", newline="\n")
done = False
while not done:
    batch = cur.fetchmany(2000)
    if not batch: break
    for text, url, did in batch:
        docs += 1
        h = host(url)
        if badhost(h): continue
        if sum(1 for d in RX for r in RX[d] if r.search(text)) < 2: continue
        t = unicodedata.normalize("NFC", text.replace("\xa0", " "))
        for para in re.split(r"\n+", t):
            para = re.sub(r"\s+", " ", para).strip()
            sents = re.split(r"(?<=[.!?])\s+(?=[A-Z\"'])", para); cu = []
            for s in sents + [None]:
                if s is not None and len(s.split()) >= 3: cu.append(s)
                n = sum(len(x.split()) for x in cu)
                if (s is None and n >= 40) or n >= 80:
                    p = " ".join(cu); cu = []
                    hs = {d: sum(1 for r in RX[d] if r.search(p)) for d in RX}; dom = max(hs, key=hs.get)
                    if hs[dom] < 2 or sorted(hs.values())[-2] == hs[dom]: rej["off_domain_lexicon"] += 1; continue
                    if words[dom] >= CAP or hostw[(dom, h)] >= HOSTCAP: rej["cap"] += 1; continue
                    why = reasons(p)
                    if "\ufffd" in p: why.append("replacement_char")
                    if n > 200: why.append("too_long")
                    if not is_sw(p): why.append("not_swahili")
                    if why:
                        for x in why: rej[x] += 1
                        continue
                    s8 = sh(p)
                    if is_dup(s8): rej["near_duplicate"] += 1; continue
                    k = len(seen); seen.append(s8)
                    for g in s8: idx[g].add(k)
                    words[dom] += len(p.split()); hostw[(dom, h)] += len(p.split())
                    out.write(json.dumps({"id": f"swa_{dom}_fw2train_{len(keep)+1:06d}", "language": "swa", "domain": dom, "raw_text": p, "source_dataset": "HuggingFaceFW/fineweb-2 swh_Latn",
                        "source_split": "train", "license": "ODC-By (HuggingFaceFW/fineweb-2); client approved use (relayed by Michael 2026-10-05; written confirmation pending)",
                        "review_status": "auto_filtered_unreviewed", "notes": f"url={url}; doc={did}; lexicon>=2"}, ensure_ascii=False) + "\n")
                    keep.append(dom)
                elif s is None: cu = []
    out.flush(); print("docs", docs, "kept", dict(words), flush=True)
    if all(words[d] >= CAP for d in LEX): done = True
out.close(); print("FINAL docs", docs, "words", dict(words), "rejected", dict(rej))
