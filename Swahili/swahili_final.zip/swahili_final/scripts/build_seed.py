"""Seed corpus v1: >= 10,000 words per domain, licence-clear, rule-filtered, with PnC labels.

Honest status (written into every record): rule_filtered_not_individually_verified. The rules were fitted to Michael's 100 labels
(precision about 0.71 on non-AfriVoice rule-passing rows). A separate gold file holds the passages Michael kept (human_verified = true).
Licence-clear = CC BY, CC BY-SA (incl. Wikipedia), public-domain legislative/agency text, CC BY-SA-3.0 dataset card.
Excluded: AfriVoice (0/54 kept), FineWeb-2 (client confirmation pending), unresolved licences.
"""
import json, os, re, random, collections, openpyxl

OUT = os.path.dirname(os.path.abspath(__file__))
D = ["agriculture", "finance", "health", "law", "telecoms"]
TARGET = 10000
CLEAR = re.compile(r"^(CC-BY|CC-BY-SA|Legislative text excluded|CDC public-domain|Public domain \(VOA|ODC-By \(HuggingFaceFW/fineweb-2\); client approved)", re.I)
rng = random.Random(5)

hits = {}
for l in open(os.path.join(OUT, "wiki_candidates_strict.jsonl"), encoding="utf-8"):
    r = json.loads(l); m = re.search(r"domain_lexicon_hits:(\d+)", r["notes"]); hits[r["id"]] = int(m.group(1)) if m else 0

pool = {d: {"main": [], "wiki": []} for d in D}
for l in open(os.path.join(OUT, "pnc_annotated.jsonl"), encoding="utf-8"):
    r = json.loads(l)
    if not CLEAR.match(r["license"] or ""): continue
    r["words"] = len(r["tokens"])
    if r["words"] > 250: continue
    (pool[r["domain"]]["wiki" if r["set"] == "wikipedia" else "main"]).append(r)

seed, summ = [], {}
for d in D:
    main = pool[d]["main"][:]; rng.shuffle(main)
    wiki = sorted(pool[d]["wiki"], key=lambda r: (-hits.get(r["id"], 0), r["id"]))
    chosen, total = [], 0
    for r in main + wiki:
        if total >= TARGET: break
        chosen.append(r); total += r["words"]
    for r in chosen:
        txt = " ".join(t["pre"] + t["word"] + t["post"] for t in r["tokens"])
        seed.append({"id": r["id"], "language": "swa", "domain": d, "raw_text": txt, "source_dataset": r["source_dataset"], "license": r["license"],
                     "review_status": "rule_filtered_not_individually_verified", "human_verified": False,
                     "pnc_tokens": r["tokens"]})
    src = collections.Counter("wikipedia" if r["set"] == "wikipedia" else "documents" for r in chosen)
    punct = collections.Counter(t["punct"] for r in chosen for t in r["tokens"])
    summ[d] = {"passages": len(chosen), "words": total, "from_documents": src["documents"], "from_wikipedia": src["wikipedia"],
               "punct_marks": sum(v for k, v in punct.items() if k != "O"), "questions": punct["QUESTION"],
               "available_clear_words": sum(r["words"] for r in pool[d]["main"] + pool[d]["wiki"])}
with open(os.path.join(OUT, "seed_v1_10k_per_domain.jsonl"), "w", encoding="utf-8", newline="\n") as f:
    for r in seed: f.write(json.dumps(r, ensure_ascii=False) + "\n")

# gold: Michael's human-kept passages
ws = openpyxl.load_workbook(os.path.join(OUT, "manual_validation_sample_EN.xlsx"))["Swahili"]
h = [c.value for c in ws[1]]; ix = {n: i for i, n in enumerate(h)}
gold = []
for r in ws.iter_rows(min_row=2, values_only=True):
    if r[ix["keep"]] == "YES":
        gold.append({"id": r[ix["id"]], "language": "swa", "domain": r[ix["domain"]], "raw_text": r[ix["raw_text"]], "source_dataset": r[ix["source_dataset"]],
                     "license": r[ix["license"]], "review_status": "human_verified_reviewer1_michael", "human_verified": True})
with open(os.path.join(OUT, "gold_human_verified.jsonl"), "w", encoding="utf-8", newline="\n") as f:
    for r in gold: f.write(json.dumps(r, ensure_ascii=False) + "\n")
gw = collections.Counter(); [gw.update({r["domain"]: len(r["raw_text"].split())}) for r in gold]
summ["_gold_human_verified"] = {"passages": len(gold), "words_by_domain": dict(gw), "total_words": sum(gw.values())}
json.dump(summ, open(os.path.join(OUT, "seed_summary.json"), "w", encoding="utf-8"), indent=1)
for d in D: print(d, summ[d])
print("gold", summ["_gold_human_verified"])
