"""Rules approximating Michael's human standard (derived from his 100 labels; NOT yet validated on fresh data).

A passage passes only if: not caption-like, ends with terminal punctuation, no web-page boilerplate tail,
no spacing errors around punctuation, and not an over-long scraped article.
"""
import re
from caption_filter import is_caption

TERM = tuple('.!?"”)')
BOILER = re.compile(r"Tanbihi|Chanzo\s*:|Mwandishi\s*:|Mhariri\b|All Rights Reserved|Picha zote|Endelea kusoma|Sambaza kwa|Laws\.Africa|Soma zaidi|Soma kwa undani|\bPosted\b|Kwa ufupi|https?://|www\.|<p |&nbsp;|pic\.twitter", re.I)
SPACE_BEFORE = re.compile(r"\s[,.;:](?!\d)")
GLUED = re.compile(r"[a-z]{2}\.[A-Z][a-z]")
LONG_WORDS = 380


def reasons(text):
    t = text.strip(); out = []
    if is_caption(t): out.append("caption_like")
    if not t.endswith(TERM): out.append("no_terminal_punct")
    if BOILER.search(t): out.append("web_boilerplate")
    if SPACE_BEFORE.search(t): out.append("space_before_punct")
    if GLUED.search(t): out.append("glued_sentences")
    if len(t.split()) >= LONG_WORDS: out.append("over_long_scraped")
    return out


def passes(text):
    return not reasons(text)
