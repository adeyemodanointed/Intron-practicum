"""Finance passages from Mollel/SwahiliNewsClassification, category uchumi (card: cc-by-4.0; underlying news rights unresolved).
Same rules as process_swahili_news.py (40-200 words, quality_rules, Swahili check, no replacement chars, >= 2 finance-lexicon stems, 8-gram near-duplicate removal incl. against the
swahili_news passages). Option: REPAIR=1 inserts the missing space in glued sentences ('huu.Misafara' -> 'huu. Misafara') before the rules; those passages are tagged repaired_glue.
"""
import json, os, re, sys, unicodedata, duckdb
import quality_rules as Q
OUT = os.path.dirname(os.path.abspath(__file__)); EXT = os.path.join(OUT, "external")
REPAIR = os.environ.get("REPAIR") == "1"
LEX = "benki fedha pesa uchumi biashara bima mkopo soko hisa kodi bei mapato faida uwekezaji mtaji sarafu shilingi dola malipo akiba mteja kampuni".split()
RX = [re.compile(r"\b" + re.escape(s) + r"\w*", re.I) for s in LEX]
SW = set("na ya wa kwa ni katika za la cha hii huu kuwa pia au ambayo hiyo vya kama hadi kutoka huo hizo yake wake lake ili sana kuhusu lakini kwamba pamoja".split())
EN = set("the of and is in to was were with for that this from which are by".split())
def is_sw(t):
    toks = re.findall(r"[a-zA-Z']+", t.lower())
    return bool(toks) and sum(x in SW for x in toks) / len(toks) >= 0.08 and sum(x in EN for x in toks) / len(toks) <= 0.04
reasons = lambda t: [x for x in Q.reasons(t) if x != "over_long_scraped"]
def sh(t, n=8):
    w = re.findall(r"\w+", t.lower()); return {" ".join(w[i:i+n]) for i in range(max(1, len(w)-n+1))}
seen = []
for l in open(os.path.join(OUT, "swahili_news_passages.jsonl"), encoding="utf-8"):
    r = json.loads(l)
    if r["domain"] == "finance": seen.append(sh(r["raw_text"]))
n_prior = len(seen); rej = {}; keep = []
for (text,) in duckdb.connect().sql("select content from '%s' where category='uchumi'" % os.path.join(EXT, "mollel_news.parquet").replace("\\", "/")).fetchall():
    t = unicodedata.normalize("NFC", text.replace("\xa0", " ")); t = re.sub(r"\s+", " ", t).strip()
    glued = False
    if REPAIR:
        t2 = re.sub(r"(?<=[a-z]{2}[.?!])(?=[A-Z][a-z])", " ", t); glued = t2 != t; t = t2
    sents = re.split(r"(?<=[.!?])\s+(?=[A-Z\"'])", t); cur = []
    for s in sents + [None]:
        if s is not None and len(s.split()) >= 3: cur.append(s)
        n = sum(len(x.split()) for x in cur)
        if (s is None and n >= 40) or n >= 80:
            p = " ".join(cur); cur = []; why = reasons(p)
            if "\ufffd" in p: why.append("replacement_char")
            if n > 200: why.append("too_long")
            if not is_sw(p): why.append("not_swahili")
            if sum(1 for r in RX if r.search(p)) < 2: why.append("off_domain_lexicon")
            if why:
                for x in why: rej[x] = rej.get(x, 0) + 1
                continue
            s8 = sh(p)
            if any(len(s8 & o) / max(1, len(s8 | o)) >= 0.5 for o in seen): rej["near_duplicate"] = rej.get("near_duplicate", 0) + 1; continue
            seen.append(s8); keep.append((p, glued))
        elif s is None: cur = []
fn = "mollel_finance_passages_repaired.jsonl" if REPAIR else "mollel_finance_passages.jsonl"
with open(os.path.join(OUT, fn), "w", encoding="utf-8", newline="\n") as f:
    for i, (p, g) in enumerate(keep, 1):
        f.write(json.dumps({"id": f"swa_finance_mollel_{i:06d}", "language": "swa", "domain": "finance", "raw_text": p, "source_dataset": "Mollel/SwahiliNewsClassification (uchumi)",
                            "source_split": "train", "license": "dataset_card_cc_by_4.0_underlying_unresolved", "review_status": "auto_filtered_unreviewed",
                            "notes": "lexicon>=2" + ("; repaired_glue" if g else "")}, ensure_ascii=False) + "\n")
print(fn, "repair" if REPAIR else "no repair", "kept", len(keep), "words", sum(len(p.split()) for p, _ in keep), "(prior swahili_news finance passages", n_prior, ") rejected", rej)
