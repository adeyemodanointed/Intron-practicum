"""Build and pre-execute the self-contained Colab notebook 'Swahili_Corpus_Audit_Colab.ipynb'."""
import json, os, re, io, sys, base64, contextlib, textwrap, collections
import nbformat
from nbformat.v4 import new_notebook, new_markdown_cell, new_code_cell
import openpyxl

OUT = os.path.dirname(os.path.abspath(__file__))
rd = lambda f: open(os.path.join(OUT, f), encoding="utf-8").read()
js = lambda f: json.load(open(os.path.join(OUT, f), encoding="utf-8"))
summary, seed, std, wiki = js("summary.json"), js("seed_summary.json"), js("standard_estimate.json"), js("wiki_summary.json")

# ---- embedded example passages from the validation workbook (Michael's labels)
from quality_rules import reasons
ws = openpyxl.load_workbook(os.path.join(OUT, "manual_validation_sample_EN.xlsx"))["Swahili"]
h = [c.value for c in ws[1]]; ix = {n: i for i, n in enumerate(h)}
rows = list(ws.iter_rows(min_row=2, values_only=True))
def pick(pred, n, maxw):
    out = []
    for r in rows:
        t = r[ix["raw_text"]].strip()
        if len(t.split()) <= maxw and pred(r, t): out.append({"domain": r[ix["domain"]], "text": t, "gloss": r[ix["english_gloss_MACHINE_TRANSLATED"]], "keep": r[ix["keep"]]})
        if len(out) == n: break
    return out
cap = pick(lambda r, t: "caption" in " ".join(reasons(t)) and r[ix["keep"]] == "NO", 3, 45)
good = pick(lambda r, t: r[ix["keep"]] == "YES", 3, 90)
bad = pick(lambda r, t: r[ix["keep"]] == "NO" and "no_terminal_punct" in reasons(t), 2, 140)
examples = cap + good + bad

D = ["agriculture", "finance", "health", "law", "telecoms"]
cells = []
md = lambda s: cells.append(new_markdown_cell(textwrap.dedent(s).strip()))
code = lambda s: cells.append(new_code_cell(textwrap.dedent(s).strip("\n")))

md("""
# Swahili corpus audit: what is really in the data
**Michael · Practicum (CMU Africa) · 4 Oct 2026**

This notebook runs end to end with no uploads. It shows (1) how many passages survive each cleaning step, (2) what human review found, (3) licences and the word counts against the target, (4) a seed corpus of 10,000 words per domain, and (5) word-level punctuation and capitalisation annotation.

**Honesty box:** the main pool was screened by an AI pass, not by humans. Michael personally reviewed 100 passages (19 kept). The rules below were fitted to those labels (about 71% precision), so every estimate here is a *rule-filtered estimate*, not verified data.
""")
code("""
import re, json, collections, unicodedata
import matplotlib
import matplotlib.pyplot as plt
plt.rcParams.update({"figure.figsize": (8, 3.8), "axes.spines.top": False, "axes.spines.right": False, "font.size": 11})
INK, ACCENT, TEAL, GREY = "#14202B", "#B5530F", "#1F6F78", "#9AA7B2"
D = ["agriculture", "finance", "health", "law", "telecoms"]
print("ready")
""")
md("## 1. Cleaning funnel")
code(f"""
funnel = [("Review pool (AI-screened)", 13948), ("Accepted or edited by AI", 11722), ("After caption filter", 6406), ("After near-duplicate pass", {summary['jsonl_records']})]
fig, ax = plt.subplots()
ax.barh([f[0] for f in funnel][::-1], [f[1] for f in funnel][::-1], color=[TEAL, TEAL, GREY, GREY][::-1])
for i, f in enumerate(funnel[::-1]): ax.text(f[1] + 150, i, f"{{f[1]:,}}", va="center")
ax.set_xlim(0, 16500); ax.set_title("Passages surviving each step"); plt.tight_layout(); plt.show()
print("Caption filter removed 5,316 passages (266,983 words, 33% of accepted words), almost all from AfriVoice.")
""")
md("## 2. The caption problem, and rules fitted to Michael's labels\nMost AfriVoice 'text' is people describing a picture. Keyword labels call it agriculture or health because it contains farm or clinic words.")
# embed rule code
cap_src = rd("caption_filter.py"); qr_src = rd("quality_rules.py").replace("from caption_filter import is_caption\n", "")
code(cap_src.split('"""', 2)[2].lstrip("\n"))
code(qr_src.split('"""', 2)[2].lstrip("\n"))
code("EXAMPLES = " + json.dumps(examples, ensure_ascii=False, indent=1))
code("""
for e in EXAMPLES:
    r = reasons(e["text"])
    print(f"[{e['domain']}] Michael: keep={e['keep']} | rules: {'PASS' if not r else ', '.join(r)}")
    print("   ", e["text"][:230].replace("\\n", " ") + (" ..." if len(e["text"]) > 230 else ""))
    print("    EN:", e["gloss"][:160]); print()
""")
md("## 3. Human review results (Michael, 100 passages)")
code("""
crit = [("Genuine Swahili", 99), ("Domain correct", 97), ("Punctuation usable", 53), ("Quality OK", 29), ("Kept (all four)", 19)]
fig, ax = plt.subplots()
ax.bar([c[0] for c in crit], [c[1] for c in crit], color=[TEAL, TEAL, TEAL, TEAL, ACCENT])
for i, c in enumerate(crit): ax.text(i, c[1] + 2, f"{c[1]}/100", ha="center")
ax.set_ylim(0, 112); ax.set_title("Passages meeting each criterion (n = 100, stratified)"); plt.xticks(rotation=15); plt.tight_layout(); plt.show()
print("AfriVoice: 0 of 54 kept (95% upper bound ~7%).  Everything else passing the rules: 17 of 24 kept (71%).")
print("Agreement with the AI screening: 31%.  The caption filter flagged 49 rows; Michael kept 1.")
""")
md("## 4. Licences and the word target (capped at 200,000 per domain)")
sc = {d: std["domains"][d] for d in D}
A = [sc[d]["licence_stated"] for d in D]; B = [sc[d]["licence_stated"] + sc[d]["wiki_rule_passing"] for d in D]; C = [sc[d]["licence_stated"] + sc[d]["wiki_rule_passing"] + sc[d]["fineweb_odc"] for d in D]
code(f"""
A, B, C = {A}, {B}, {C}
import numpy as np
x = np.arange(len(D)); w = 0.27
fig, ax = plt.subplots(figsize=(9, 4))
ax.bar(x - w, A, w, label="A: licence stated", color=TEAL); ax.bar(x, B, w, label="B: + Wikipedia (unvalidated)", color=GREY); ax.bar(x + w, C, w, label="C: + FineWeb-2 (client to confirm)", color=ACCENT)
ax.axhline(200000, color=INK, lw=1, ls="--"); ax.text(4.45, 203000, "target 200k", ha="right")
ax.set_xticks(x); ax.set_xticklabels(D); ax.set_ylabel("words"); ax.legend(frameon=False, fontsize=9); ax.set_title("Standard-conforming words per domain"); plt.tight_layout(); plt.show()
cap = lambda L: sum(min(v, 200000) for v in L)
print("Capped totals  A:", f"{{cap(A):,}}", " B:", f"{{cap(B):,}}", " C:", f"{{cap(C):,}}", "  (target 1,000,000; fallback 500,000)")
""")
md("## 5. Seed corpus v1: at least 10,000 words per domain\nBuilt from licence-clear text only (CC BY, CC BY-SA incl. Wikipedia, public-domain legislation) that passes the rules. **Not individually human-verified**; Michael's 19 kept passages are a separate gold file.")
code("SEED = " + json.dumps({d: seed[d] for d in D}, indent=1) + "\nGOLD = " + json.dumps(seed["_gold_human_verified"]))
code("""
print(f"{'domain':12s} {'words':>7s} {'passages':>9s} {'documents':>10s} {'wikipedia':>10s} {'punct marks':>12s} {'questions':>10s}")
for d in D:
    s = SEED[d]; print(f"{d:12s} {s['words']:7,d} {s['passages']:9d} {s['from_documents']:10d} {s['from_wikipedia']:10d} {s['punct_marks']:12d} {s['questions']:10d}")
print()
print("Gold (human-verified, Michael):", GOLD["total_words"], "words in", GOLD["passages"], "passages ->", GOLD["words_by_domain"])
fig, ax = plt.subplots(figsize=(8, 3.6))
ax.bar(D, [SEED[d]["from_documents"] for d in D], label="from documents", color=TEAL)
ax.bar(D, [SEED[d]["from_wikipedia"] for d in D], bottom=[SEED[d]["from_documents"] for d in D], label="from Wikipedia", color=GREY)
ax.set_title("Seed passages by origin"); ax.legend(frameon=False); plt.tight_layout(); plt.show()
print("Caveat: Wikipedia dominates finance, health, law and telecoms; its domain labels come from article categories plus a vocabulary filter and were not in the human sample.")
""")
md("## 6. Word-level punctuation and capitalisation annotation (PnC labels)")
ann_src = rd("annotate_pnc.py")
body = ann_src[ann_src.index("LEAD = re.compile"):ann_src.index("records, stats =")]
body = body.replace("def reasons(t): return [x for x in Q.reasons(t) if x != \"over_long_scraped\"]\n\n\n", "")
code(body)
code("""
demo = "Mkulima alisema, \\"Mvua ni nyingi mwaka huu.\\" Je, tutavuna mahindi mengi? Ndiyo!"
toks = annotate(demo)
print("round trip ok:", rebuild(toks) == normalise(demo))
print(f"{'word':14s} {'punct':9s} {'cap':6s}")
for t in toks: print(f"{t['pre']+t['word']:14s} {t['punct']:9s} {t['cap']:6s}")
""")
code("""
dist = {"No punctuation": 90.6, "Comma": 4.7, "Period": 4.4, "Other": 0.3, "Question": 0.02, "Exclamation": 0.005}
fig, ax = plt.subplots(figsize=(8, 3.4))
ax.barh(list(dist)[::-1], list(dist.values())[::-1], color=TEAL); ax.set_xscale("log"); ax.set_xlabel("% of 438,996 words (log scale)")
ax.set_title("Punctuation labels in the annotated set"); plt.tight_layout(); plt.show()
print("Only 90 question-mark words in 438,996: this corpus (news, government, encyclopedia) barely teaches questions, which a spoken-QA project needs.")
""")

md("""
## 7. Domain classifier: retrained on seed v1, tested on human-reviewed passages
Same model spec (TF-IDF + logistic regression). Test = Michael's 97 reviewed passages whose domain he confirmed (17,118 words).
""")
code("""
rows = [("All reviewed (n=97)", 66.0, 100), ("Gold, Michael kept (n=19)", 84.2, 100), ("Caption-like (n=48)", 75.0, 100), ("Not caption-like (n=49)", 57.1, 100)]
x = np.arange(len(rows)); w = 0.38
fig, ax = plt.subplots(figsize=(9, 3.8))
ax.bar(x - w/2, [r[1] for r in rows], w, label="trained on seed v1", color=TEAL); ax.bar(x + w/2, [r[2] for r in rows], w, label="trained on weak keyword labels", color=GREY)
for i, r in enumerate(rows): ax.text(i - w/2, r[1] + 1.5, f"{r[1]}%", ha="center", fontsize=9)
ax.set_xticks(x); ax.set_xticklabels([r[0] for r in rows], fontsize=9); ax.set_ylim(0, 112); ax.set_ylabel("accuracy %"); ax.legend(frameon=False, fontsize=9)
ax.set_title("Domain accuracy on human-reviewed passages"); plt.tight_layout(); plt.show()
print("The weak-label model's 100% is inflated: 13 of 100 test passages have a near-duplicate in its training data and it learned keyword labels.")
print("The seed-trained model has 1 near-duplicate; it is 57% on non-caption text and 75% on picture descriptions; law (statute text) and finance are the weakest classes.")
""")
md("""
## 8. Word target by licence tier (latest counts)
Licence-clear = documents with a stated CC licence, Wikipedia (CC BY-SA), and FineWeb-2 (client said yes, written confirmation pending). News tier = Swahili news datasets whose card says CC BY 4.0 but whose newspaper text rights are not cleared. All text passes the same quality rules; none is human-verified; news finance text had glued sentences repaired.
""")
code("""
import json, os
T = json.load(open(os.path.join(DIR, "clear_words_now.json"))) if "DIR" in globals() else json.load(open("clear_words_now.json"))
doms = ["agriculture", "finance", "health", "law", "telecoms"]
cl = [min(T["licence_clear"][d], 200000) for d in doms]; nw = [min(T["news_tier"][d], max(0, 200000 - cl[i])) for i, d in enumerate(doms)]
fig, ax = plt.subplots(figsize=(9, 3.8)); x = np.arange(5)
ax.bar(x, cl, color=TEAL, label="licence-clear"); ax.bar(x, nw, bottom=cl, color=ACCENT, label="news tier (rights unresolved)")
ax.axhline(200000, color="black", lw=1, ls="--"); ax.axhline(100000, color="grey", lw=1, ls=":")
ax.set_xticks(x); ax.set_xticklabels(doms); ax.set_ylabel("words (capped at 200k)"); ax.legend(frameon=False, fontsize=9); ax.set_title("Words per domain against 200k target (dashed) and 100k fallback share (dotted)")
plt.tight_layout(); plt.show()
print("Licence-clear total:", f"{T['totals']['licence_clear']:,}", " | news tier:", f"{T['totals']['news_tier']:,}", " | 500k fallback met by licence-clear alone:", T['totals']['licence_clear'] >= 500000)
""")
md("""
## 9. Next steps
| Item | Status |
|---|---|
| Second reviewer and a fluent-speaker check | pending |
| FineWeb-2 (ODC-By) | client said yes; written confirmation pending |
| Licensed agriculture and finance sources (non-caption text) | needed |
| Question-style text for PnC | needed |
| Model selection (Whisper, Gemma 3n, MMS; benchmark script ready) | next, with Rose |
""")

nb = new_notebook(cells=cells)
nb.metadata = {"colab": {"name": "Swahili_Corpus_Audit_Colab.ipynb", "provenance": []}, "kernelspec": {"name": "python3", "display_name": "Python 3"}, "language_info": {"name": "python"}}

# ---- pre-execute (lightweight executor so outputs and charts are saved in the file)
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
ns = {"__name__": "__main__"}; n = 0
for c in nb.cells:
    if c.cell_type != "code": continue
    n += 1; buf = io.StringIO(); c.outputs = []
    with contextlib.redirect_stdout(buf):
        try: exec(compile(c.source, f"cell{n}", "exec"), ns)
        except Exception as e: print("ERROR:", repr(e))
    if buf.getvalue(): c.outputs.append(nbformat.v4.new_output("stream", name="stdout", text=buf.getvalue()))
    for num in plt.get_fignums():
        bio = io.BytesIO(); plt.figure(num).savefig(bio, format="png", dpi=110, bbox_inches="tight")
        c.outputs.append(nbformat.v4.new_output("display_data", data={"image/png": base64.b64encode(bio.getvalue()).decode(), "text/plain": "<Figure>"}))
    plt.close("all"); c.execution_count = n
nbformat.write(nb, os.path.join(OUT, "Swahili_Corpus_Audit_Colab.ipynb"))
errs = [o for c in nb.cells if c.cell_type == "code" for o in c.outputs if o.get("output_type") == "stream" and "ERROR" in o["text"]]
print("cells", len(nb.cells), "code cells", n, "errors", len(errs)); [print(e["text"][:300]) for e in errs]
