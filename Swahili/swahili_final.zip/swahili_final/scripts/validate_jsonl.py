"""Independent check of swahili_shared.jsonl against the shared schema from the assignment sheet."""
import json, collections, os, unicodedata
P = os.path.join(os.path.dirname(os.path.abspath(__file__)), "swahili_shared.jsonl")
REQ = ["id", "language", "domain", "raw_text", "source_dataset", "source_split", "license", "review_status", "notes"]
DOMAINS = {"agriculture", "finance", "health", "law", "telecoms"}
ids, errs, c = set(), collections.Counter(), collections.Counter()
n = 0
with open(P, "rb") as fb:
    raw = fb.read()
raw.decode("utf-8")  # raises on bad encoding
for line in raw.decode("utf-8").splitlines():
    n += 1
    r = json.loads(line)
    for k in REQ:
        if k not in r: errs["missing_" + k] += 1
    if set(r) - set(REQ): errs["extra_fields"] += 1
    if r["language"] != "swa": errs["bad_language"] += 1
    if r["domain"] not in DOMAINS: errs["bad_domain"] += 1
    if not r["raw_text"].strip(): errs["empty_text"] += 1
    if r["id"] in ids: errs["dup_id"] += 1
    ids.add(r["id"])
    if not r["id"].startswith(f"swa_{r['domain']}_"): errs["id_domain_mismatch"] += 1
    if "�" in r["raw_text"]: errs["replacement_char"] += 1
    if unicodedata.normalize("NFC", r["raw_text"]) != r["raw_text"]: errs["not_nfc"] += 1
    c[r["domain"]] += 1
print("records", n, "per domain", dict(c))
print("errors", dict(errs) if errs else "none")
