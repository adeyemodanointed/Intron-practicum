"""Annotate Swahili text with word-level punctuation and capitalisation labels (PnC training format).

Input : passages that meet the human standard estimate (not AfriVoice, pass quality_rules except the over-long rule)
        from swahili_shared.jsonl, plus the rule-passing Wikipedia strict set (flagged as unvalidated).
Output: pnc_annotated.jsonl (one passage per line: tokens with pre, word, post, punct label, cap label), pnc_stats.json.

Normalisation before labelling (deterministic): NFC, curly quotes/apostrophes -> straight, whitespace collapsed,
space before , . ; : ? ! removed. A round-trip check rebuilds each passage from its tokens and compares.
Punct labels: O (none), COMMA, PERIOD, QUESTION, EXCL, OTHER (; : ellipsis). Cap labels: LOWER, TITLE, UPPER, MIXED.
"""
import json, os, re, collections, unicodedata
import quality_rules as Q

OUT = os.path.dirname(os.path.abspath(__file__))
LEAD = re.compile(r"^[(\[\"«]+")
TRAIL = re.compile(r"[,.;:?!…)\"\]»]+$")


def reasons(t): return [x for x in Q.reasons(t) if x != "over_long_scraped"]


def normalise(t):
    t = unicodedata.normalize("NFC", t)
    t = t.replace("’", "'").replace("‘", "'").replace("ʼ", "'").replace("“", '"').replace("”", '"')
    t = re.sub(r"\s+", " ", t).strip()
    return re.sub(r"\s+([,.;:?!])", r"\1", t)


def punct_label(post):
    for ch in post:
        if ch == ",": return "COMMA"
        if ch == "?": return "QUESTION"
        if ch == "!": return "EXCL"
        if ch in ";:…": return "OTHER"
        if ch == ".":
            return "OTHER" if "..." in post else "PERIOD"
    return "O"


def cap_label(w):
    letters = [c for c in w if c.isalpha()]
    if not letters: return "LOWER"
    if len(letters) > 1 and all(c.isupper() for c in letters): return "UPPER"
    if letters[0].isupper(): return "TITLE" if not any(c.isupper() for c in letters[1:]) else "MIXED"
    return "MIXED" if any(c.isupper() for c in letters) else "LOWER"


def annotate(text):
    toks = []
    for raw in normalise(text).split(" "):
        pre = LEAD.match(raw); pre = pre.group(0) if pre else ""
        rest = raw[len(pre):]
        post = TRAIL.search(rest); post = post.group(0) if post else ""
        core = rest[: len(rest) - len(post)]
        if not core:  # punctuation-only token: attach to previous token's post
            if toks: toks[-1]["post"] += " " + raw; toks[-1]["punct"] = punct_label(toks[-1]["post"]) if toks[-1]["punct"] == "O" else toks[-1]["punct"]
            continue
        toks.append({"pre": pre, "word": core, "post": post, "punct": punct_label(post), "cap": cap_label(core)})
    return toks


def rebuild(toks): return " ".join(t["pre"] + t["word"] + t["post"] for t in toks)


records, stats = [], collections.defaultdict(collections.Counter)
rt_ok = rt_bad = 0; skipped = collections.Counter()
srcs = [("main", "swahili_shared.jsonl"), ("wikipedia", "wiki_candidates_strict.jsonl"), ("documents_new", "tari_rice_passages.jsonl"), ("documents_new", "tanzlii_law_passages.jsonl"), ("documents_new", "voa_agri_passages.jsonl"), ("documents_new", "fineweb_agri_fin_kept.jsonl"), ("documents_new", "fineweb_train_passages.jsonl"), ("news_tier", "swahili_news_passages.jsonl"), ("news_tier", "mollel_finance_passages_repaired.jsonl")]
for tag, fn in srcs:
    for line in open(os.path.join(OUT, fn), encoding="utf-8"):
        r = json.loads(line)
        if "afrivoice" in r["source_dataset"].lower(): skipped["afrivoice"] += 1; continue
        if reasons(r["raw_text"]): skipped["rules"] += 1; continue
        toks = annotate(r["raw_text"])
        if rebuild(toks) != normalise(r["raw_text"]): rt_bad += 1; skipped["roundtrip_fail"] += 1; continue
        rt_ok += 1
        recs = {"id": r["id"], "set": tag, "domain": r["domain"], "source_dataset": r["source_dataset"], "license": r["license"],
                "review_status": "rule_filtered_" + ("unvalidated_wikipedia" if tag == "wikipedia" else "standard_estimate"), "tokens": toks}
        records.append(recs)
        key = (tag, r["domain"])
        for t in toks: stats[key]["words"] += 1; stats[key]["punct_" + t["punct"]] += 1; stats[key]["cap_" + t["cap"]] += 1
        stats[key]["passages"] += 1
with open(os.path.join(OUT, "pnc_annotated.jsonl"), "w", encoding="utf-8", newline="\n") as f:
    for r in records: f.write(json.dumps(r, ensure_ascii=False) + "\n")
summ = {"passages": len(records), "roundtrip_ok": rt_ok, "roundtrip_fail": rt_bad, "skipped": dict(skipped),
        "by_set_domain": {f"{a}/{b}": dict(v) for (a, b), v in stats.items()}}
json.dump(summ, open(os.path.join(OUT, "pnc_stats.json"), "w", encoding="utf-8"), indent=1)
tot = collections.Counter()
for v in stats.values(): tot.update(v)
w = tot["words"]
print("passages", len(records), "words", w, "roundtrip fail", rt_bad, "skipped", dict(skipped))
print({k: f"{v} ({100*v/w:.1f}%)" for k, v in sorted(tot.items()) if k.startswith(("punct_", "cap_"))})
