"""Score manual_validation_sample_EN.xlsx (team audit-tab layout) once real people fill it in.

Reviewer 1 fills Is_Swa, domain_ok, punctuation_ok, quality_ok, keep (YES/NO); reviewer 2 fills reviewer2_keep on a subset.
AI and Claude columns are NOT used as reviewers.
"""
import collections, os
import openpyxl
P = os.path.join(os.path.dirname(os.path.abspath(__file__)), "manual_validation_sample_EN.xlsx")
ws = openpyxl.load_workbook(P, read_only=True)["Swahili"]
it = ws.iter_rows(values_only=True)
h = next(it)
rows = [dict(zip(h, ["" if v is None else str(v).strip().upper() if k in ("Is_Swa", "domain_ok", "punctuation_ok", "quality_ok", "keep", "reviewer2_keep") else ("" if v is None else str(v)) for k, v in zip(h, r)])) for r in it if r and r[0]]
r1 = [r for r in rows if r["keep"] in ("YES", "NO")]
both = [r for r in r1 if r["reviewer2_keep"] in ("YES", "NO")]
print(f"reviewed by reviewer 1: {len(r1)}/{len(rows)}; double-reviewed: {len(both)}")
if r1:
    keep = sum(r["keep"] == "YES" for r in r1)
    print(f"keep rate (acceptance): {keep}/{len(r1)} = {100*keep/len(r1):.1f}%")
    for c in ("Is_Swa", "domain_ok", "punctuation_ok", "quality_ok"):
        ok = sum(r[c] == "YES" for r in r1)
        print(f"  {c}: {ok}/{len(r1)} YES")
    bad = [r["id"] for r in r1 if r["keep"] == "YES" and "NO" in (r["Is_Swa"], r["domain_ok"], r["punctuation_ok"], r["quality_ok"])]
    if bad: print("WARNING keep=YES but a criterion is NO (team rule says reject):", len(bad), "rows")
    ai = [r for r in r1 if r["ai_decision"]]
    agree = sum((r["keep"] == "YES") == (r["ai_decision"] in ("ACCEPT", "NEEDS_EDIT")) for r in ai)
    print(f"agreement with AI screening (keep vs accept): {agree}/{len(ai)} = {100*agree/len(ai):.1f}%")
    cap = [r for r in r1 if "image description" in r["claude_suggestions_NOT_DECISIONS"].lower()]
    if cap: print(f"rows Claude flagged as captions that you kept: {sum(r['keep']=='YES' for r in cap)}/{len(cap)}")
if both:
    a = [r["keep"] for r in both]; b = [r["reviewer2_keep"] for r in both]
    n = len(a); po = sum(x == y for x, y in zip(a, b)) / n
    pe = sum((a.count(k) / n) * (b.count(k) / n) for k in ("YES", "NO"))
    kappa = (po - pe) / (1 - pe) if pe < 1 else 1.0
    print(f"reviewer1 vs reviewer2 on keep: raw agreement {100*po:.1f}%, Cohen's kappa {kappa:.2f} (n={n})")
