"""Fetch Swahili Wikipedia (CC BY-SA 4.0) text by topic category, via the public MediaWiki API.

Polite: identifying User-Agent, sequential requests, short sleeps. Output: wiki_raw.jsonl (one article per line).
Category membership is only a domain *candidate*; it is not a verified label.
"""
import json, time, urllib.request, urllib.parse, os, sys, collections

API = "https://sw.wikipedia.org/w/api.php"
UA = "PracticumResearch/1.0 (CMU-Africa practicum, research use; CMU practicum, research use)"
OUT = os.path.dirname(os.path.abspath(__file__))
ROOTS = {
    "agriculture": ["Kilimo", "Mazao", "Ufugaji", "Mimea ya chakula", "Wanyama wa kufugwa", "Matunda", "Mboga"],
    "health": ["Afya", "Magonjwa", "Tiba", "Dawa", "Magonjwa ya binadamu", "Lishe", "Magonjwa ya kuambukiza"],
    "law": ["Sheria", "Katiba", "Haki za binadamu", "Mahakama", "Sheria ya Tanzania", "Sheria ya Kenya"],
    "finance": ["Uchumi", "Benki", "Fedha", "Biashara", "Bima", "Sarafu"],
    "telecoms": ["Mawasiliano", "Simu", "Intaneti", "Teknolojia ya habari", "Simu za mkononi", "Kompyuta", "Mtandao"],
}
EXTRA = {
    "agriculture": ["Mazao ya biashara", "Nafaka", "Kahawa", "Chai", "Mahindi", "Mifugo", "Wadudu waharibifu", "Udongo", "Umwagiliaji", "Mbolea", "Uvuvi", "Wanyama wa shamba", "Kilimo cha Tanzania", "Kilimo cha Kenya", "Mimea ya biashara", "Viungo"],
    "law": ["Sheria ya jinai", "Sheria ya kimataifa", "Mahakama ya Tanzania", "Serikali ya Tanzania", "Haki", "Uhalifu", "Polisi", "Mikataba", "Uchaguzi", "Bunge", "Majaji", "Wanasheria", "Uraia", "Uhamiaji", "Magereza"],
    "finance": ["Uchumi wa Tanzania", "Uchumi wa Kenya", "Benki Kuu", "Mabenki", "Fedha za kigeni", "Sarafu za Afrika", "Hisa", "Soko la hisa", "Kodi", "Ushuru", "Biashara ya kimataifa", "Makampuni", "Mashirika ya kimataifa", "Uchumi wa Afrika", "Uchumi wa dunia", "Soko", "Viwanda", "Madini", "Mafuta", "Usafiri wa biashara", "Ajira", "Umaskini", "Maendeleo ya uchumi", "Ushirika", "Bima ya afya"],
    "telecoms": ["Mawasiliano ya simu", "Redio", "Televisheni", "Utangazaji", "Posta", "Satelaiti", "Mitandao ya kijamii", "Waya", "Teknolojia ya mawasiliano", "Makampuni ya simu", "Simu za mkononi", "Vyombo vya habari", "Magazeti", "Gazeti", "Habari", "Wavuti", "Tovuti", "Barua pepe", "Programu za kompyuta", "Mifumo ya uendeshaji", "Vifaa vya kielektroniki", "Umeme", "Elektroniki", "Teknolojia", "Mtandao wa kompyuta", "Sayansi ya kompyuta", "Lugha za programu", "Michezo ya kompyuta", "Simu ya mkononi", "Usafiri wa anga"],
}
if os.environ.get("EXTRA"): ROOTS = {k: v for k, v in EXTRA.items()}
MAX_PER_DOMAIN = 700
DEPTH = 2


def call(params, tries=3):
    q = urllib.parse.urlencode({**params, "format": "json"})
    for i in range(tries):
        try:
            req = urllib.request.Request(API + "?" + q, headers={"User-Agent": UA})
            with urllib.request.urlopen(req, timeout=30) as r:
                return json.loads(r.read().decode("utf-8"))
        except Exception as e:
            time.sleep(1.5 * (i + 1))
    return {}


def members(cat):
    out, cont = [], {}
    while True:
        d = call({"action": "query", "list": "categorymembers", "cmtitle": "Jamii:" + cat, "cmlimit": "500", **cont})
        out += d.get("query", {}).get("categorymembers", [])
        if "continue" in d and len(out) < 3000: cont = d["continue"]
        else: break
        time.sleep(0.15)
    return out


def titles_for(domain):
    seen_cat, titles, frontier = set(), collections.OrderedDict(), [(c, 0) for c in ROOTS[domain]]
    while frontier and len(titles) < MAX_PER_DOMAIN:
        cat, depth = frontier.pop(0)
        if cat in seen_cat: continue
        seen_cat.add(cat)
        for m in members(cat):
            if m["ns"] == 0: titles.setdefault(m["title"], cat)
            elif m["ns"] == 14 and depth < DEPTH: frontier.append((m["title"].split(":", 1)[1], depth + 1))
        time.sleep(0.15)
    return list(titles.items())[:MAX_PER_DOMAIN], len(seen_cat)


def extracts(batch):
    d = call({"action": "query", "prop": "extracts|info", "explaintext": "1", "exlimit": "max", "inprop": "url",
              "titles": "|".join(batch), "redirects": "1"})
    return d.get("query", {}).get("pages", {})


if __name__ == "__main__":
    n = 0
    doms = sys.argv[1:] or list(ROOTS)
    with open(os.path.join(OUT, "wiki_raw.jsonl"), "a" if sys.argv[1:] else "w", encoding="utf-8", newline="\n") as f:
        for dom in doms:
            tl, ncat = titles_for(dom)
            print(dom, "titles", len(tl), "categories visited", ncat, flush=True)
            for title, cat in tl:
                pages = extracts([title])
                for p in pages.values():
                    txt = p.get("extract") or ""
                    if not txt: continue
                    f.write(json.dumps({"domain": dom, "title": p["title"], "pageid": p["pageid"], "url": p.get("fullurl", ""),
                                        "category": cat, "lastrevid": p.get("lastrevid"), "text": txt}, ensure_ascii=False) + "\n")
                    n += 1
                f.flush()
                time.sleep(0.12)
            print(dom, "done, total articles so far", n, flush=True)
