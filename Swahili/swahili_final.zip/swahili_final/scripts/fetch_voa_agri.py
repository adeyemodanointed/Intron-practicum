"""Agriculture passages from VOA Swahili (voaswahili.com). VOA-produced text is public domain per VOA's usage terms; third-party wire material (AFP, AP, Reuters) is not,
so articles that mention those agencies are excluded entirely. Only pages with a text body (wsw container) are used; video/audio pages have none.
Same rules as the other pipelines (40-200 word passages, quality_rules, Swahili check, >= 2 agriculture-lexicon stems, 8-gram near-duplicate removal vs the existing pool).
Outputs: voa_raw.jsonl (all text articles fetched), voa_agri_passages.jsonl.
"""
import re, os, json, time, urllib.request, urllib.parse, unicodedata
import quality_rules as Q
OUT = os.path.dirname(os.path.abspath(__file__)); BASE = "https://www.voaswahili.com"
TERMS = ["kilimo", "wakulima", "mazao", "ukame", "mbolea", "mifugo", "chakula", "mavuno", "kahawa", "mahindi", "umwagiliaji", "ufugaji"]
def get(u):
    for i in range(3):
        try: return urllib.request.urlopen(urllib.request.Request(u, headers={"User-Agent": "PracticumResearch/1.0 (CMU-Africa practicum, research use)"}), timeout=40).read().decode("utf-8", "replace")
        except Exception: time.sleep(3)
    return ""
ids = []
for term in TERMS:
    for pi in range(1, 5):
        s = get(f"{BASE}/s?k={urllib.parse.quote(term)}&tab=all&pi={pi}&r=any&pp=50")
        new = [i for i in dict.fromkeys(re.findall(r'href="(/a/\d+\.html)"', s)) if i not in ids]
        ids += new
        if not new: break
        time.sleep(0.4)
print("article ids", len(ids), flush=True)
raw = open(os.path.join(OUT, "voa_raw.jsonl"), "w", encoding="utf-8", newline="\n")
nt = 0
for k, i in enumerate(ids):
    t = get(BASE + i); time.sleep(0.4)
    if "wsw" not in t: continue
    m = re.search(r'class="wsw[^"]*"[^>]*>(.*?)(?:<div class="[^"]*(?:links|tags|share)|<footer)', t, re.S)
    body = m.group(1) if m else t
    ps = [re.sub(r"<[^>]+>", "", p).strip() for p in re.findall(r"<p[^>]*>(.*?)</p>", body, re.S)]
    ps = [unicodedata.normalize("NFC", re.sub(r"&[a-z#0-9]+;", " ", x)) for x in ps if len(x.split()) > 6]
    if not ps: continue
    title = re.sub(r"\s+", " ", (re.search(r"<title>([^<]*)", t) or [0, ""])[1]).strip()
    date = (re.search(r'datetime="([^"]+)"', t) or [0, ""])[1]
    raw.write(json.dumps({"id": i, "title": title, "date": date, "text": " ".join(ps)}, ensure_ascii=False) + "\n"); raw.flush(); nt += 1
    if k % 100 == 0: print(k, "of", len(ids), "text articles", nt, flush=True)
raw.close(); print("done text articles", nt)
