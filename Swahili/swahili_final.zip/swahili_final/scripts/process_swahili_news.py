"""Passages from community-datasets/swahili_news (dataset card: cc-by-4.0; underlying news-site text rights NOT resolved).
Uses label uchumi (economy) -> finance candidates and afya (health) -> health candidates, then requires >= 2 distinct domain-lexicon stems per passage
(same rule as the Wikipedia strict set), 40-200 word passages, quality_rules (no glued sentences, no boilerplate), Swahili function-word check, no replacement characters.
Licence string is deliberately NOT 'CC-BY...' so build_seed.py does not count it as licence-clear; it is reported as its own tier.
"""
import json, os, re, unicodedata, duckdb
import quality_rules as Q
OUT = os.path.dirname(os.path.abspath(__file__)); EXT = os.path.join(OUT, "external")
LEX = {
    "finance": "benki fedha pesa uchumi biashara bima mkopo soko hisa kodi bei mapato faida uwekezaji mtaji sarafu shilingi dola malipo akiba mteja kampuni".split(),
    "health": "afya ugonjwa magonjwa dawa tiba daktari hospitali chanjo mgonjwa virusi bakteria dalili matibabu lishe mimba damu kinga maambukizi".split(),
}
RX = {d: [re.compile(r"\b" + re.escape(s) + r"\w*", re.I) for s in v] for d, v in LEX.items()}
SW = set("na ya wa kwa ni katika za la cha hii huu kuwa pia au ambayo hiyo vya kama hadi kutoka huo hizo yake wake lake ili sana kuhusu lakini kwamba pamoja".split())
EN = set("the of and is in to was were with for that this from which are by".split())
def is_sw(t):
    toks = re.findall(r"[a-zA-Z']+", t.lower())
    return bool(toks) and sum(x in SW for x in toks) / len(toks) >= 0.08 and sum(x in EN for x in toks) / len(toks) <= 0.04
reasons = lambda t: [x for x in Q.reasons(t) if x != "over_long_scraped"]
c = duckdb.connect(); out, rej = [], {}
for split in ("train", "test"):
    for label, dom in ((0, "finance"), (5, "health")):
        for (text,) in c.sql(f"select text from '{os.path.join(EXT, f'swnews_{split}.parquet').replace(chr(92), '/')}' where label={label}").fetchall():
            t = unicodedata.normalize("NFC", text.replace("\xa0", " "))
            t = re.sub(r"\s+", " ", t).strip()
            sents = re.split(r"(?<=[.!?])\s+(?=[A-Z\"'])", t); cur = []
            for s in sents + [None]:
                if s is not None and len(s.split()) >= 3: cur.append(s)
                n = sum(len(x.split()) for x in cur)
                if (s is None and n >= 40) or n >= 80:
                    p = " ".join(cur); cur = []
                    why = reasons(p)
                    if "\ufffd" in p: why.append("replacement_char")
                    if n > 200: why.append("too_long")
                    if not is_sw(p): why.append("not_swahili")
                    if sum(1 for r in RX[dom] if r.search(p)) < 2: why.append("off_domain_lexicon")
                    if why:
                        for x in why: rej[x] = rej.get(x, 0) + 1
                        continue
                    out.append((dom, p, split))
                elif s is None: cur = []
seen, keep = set(), []
for dom, p, split in out:
    k = re.sub(r"\W+", " ", p.lower())[:200]
    if k in seen: continue
    seen.add(k); keep.append((dom, p, split))
with open(os.path.join(OUT, "swahili_news_passages.jsonl"), "w", encoding="utf-8", newline="\n") as f:
    for i, (dom, p, split) in enumerate(keep, 1):
        f.write(json.dumps({"id": f"swa_{dom}_swnews_{i:06d}", "language": "swa", "domain": dom, "raw_text": p, "source_dataset": "community-datasets/swahili_news",
                            "source_split": split, "license": "dataset_card_cc_by_4.0_underlying_unresolved", "review_status": "auto_filtered_unreviewed",
                            "notes": "label=" + ("uchumi" if dom == "finance" else "afya") + "; lexicon>=2"}, ensure_ascii=False) + "\n")
by = {}
for dom, p, s in keep: by.setdefault(dom, [0, 0]); by[dom][0] += 1; by[dom][1] += len(p.split())
print("kept", by, "rejected for", rej)
