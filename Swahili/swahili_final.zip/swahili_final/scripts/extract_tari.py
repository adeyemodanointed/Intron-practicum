"""Extract clean agriculture passages from the TARI/IITA rice training guide (CC BY 4.0 printed on PDF page 3).

Heuristics: skip front matter and references, drop headings and table-of-contents lines, join wrapped lines, split to sentences,
group sentences into passages of 40-150 words, keep passages that pass quality_rules and the Swahili function-word check.
Output: tari_rice_passages.jsonl (shared schema, review_status = auto_filtered_unreviewed).
"""
import json, os, re, glob, unicodedata
import pypdf
import quality_rules as Q

OUT = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(os.path.dirname(OUT), "kimi-batch-1-2026-09-27", "raw", "tari-rice-guide.pdf")
SW = set("na ya wa kwa ni katika za la cha hii huu kuwa pia au ambayo hiyo vya kama hadi kutoka huo hizo yake wake lake ili sana kuhusu lakini kwamba pamoja".split())
EN = set("the of and is in to was were with for that this from which are by".split())
reasons = lambda t: [x for x in Q.reasons(t) if x != "over_long_scraped"]


def is_sw(t):
    toks = re.findall(r"[a-zA-Z']+", t.lower())
    return bool(toks) and sum(x in SW for x in toks) / len(toks) >= 0.08 and sum(x in EN for x in toks) / len(toks) <= 0.04


r = pypdf.PdfReader(SRC); stop = None; lines = []
for i, p in enumerate(r.pages):
    if i < 6: continue
    txt = p.extract_text() or ""
    if re.search(r"Rejea mbalimbali zilizotumika", txt) and i > 20: break
    for ln in txt.split("\n"):
        ln = unicodedata.normalize("NFC", ln).strip()
        if not ln or re.fullmatch(r"\d+", ln) or re.search(r"\.{4,}|\s\d{1,2}$", ln) and len(ln.split()) < 12: continue
        lines.append(ln)
text = " ".join(lines)
text = re.sub(r"[A-Z][^.]{0,220}\.\s*Picha na:\s*[^.]{0,90}\.", " ", text)  # drop figure caption + photo credit
text = re.sub(r"Picha na:\s*[^.]{0,90}\.", " ", text)
sents = re.split(r"(?<=[.!?])\s+(?=[A-Z\"'])", text)
passages, cur = [], []
for s in sents:
    if len(s.split()) < 5: continue
    cur.append(s)
    if sum(len(x.split()) for x in cur) >= 50:
        passages.append(" ".join(cur)); cur = []
if cur and sum(len(x.split()) for x in cur) >= 40: passages.append(" ".join(cur))
keep, rej = [], {}
for p in passages:
    n = len(p.split()); rs = reasons(p)
    if n > 200: rs.append("too_long")
    if not is_sw(p): rs.append("not_swahili")
    if rs:
        for x in rs: rej[x] = rej.get(x, 0) + 1
        continue
    keep.append(p)
with open(os.path.join(OUT, "tari_rice_passages.jsonl"), "w", encoding="utf-8", newline="\n") as f:
    for i, p in enumerate(keep, 1):
        f.write(json.dumps({"id": f"swa_agriculture_tari_{i:04d}", "language": "swa", "domain": "agriculture", "raw_text": p,
                            "source_dataset": "TARI/IITA rice training guide (tari.go.tz)", "source_split": "unspecified",
                            "license": "CC-BY-4.0 (printed on PDF page 3)", "review_status": "auto_filtered_unreviewed", "notes": "rules_applied"}, ensure_ascii=False) + "\n")
print("passages built", len(passages), "kept", len(keep), "words", sum(len(p.split()) for p in keep), "rejected for", rej)
