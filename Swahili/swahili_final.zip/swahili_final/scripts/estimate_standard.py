"""Re-estimate usable words under Michael's human standard (derived from his 100 labels).

Standard-conforming = not AfriVoice (0/54 kept in his sample) AND passes quality_rules (minus the over-long rule, which was uninformative).
Expected keepable = rule-passing words x measured precision (non-AfriVoice, rule-passing rows: 17/24, Wilson 95% CI 0.51-0.85).
Wikipedia was NOT in his sample, so its precision is unvalidated; it is reported separately.
"""
import json, os, re, collections
import quality_rules as Q

OUT = os.path.dirname(os.path.abspath(__file__))
D = ["agriculture", "finance", "health", "law", "telecoms"]
P, LO, HI = 17 / 24, 0.51, 0.85


def reasons(t): return [x for x in Q.reasons(t) if x != "over_long_scraped"]


main = {d: collections.Counter() for d in D}; tiers = {d: collections.Counter() for d in D}
mw = {d: collections.Counter() for d in D}
drop_reason = collections.Counter(); total_words = collections.Counter(); kept_words = collections.Counter()
for line in open(os.path.join(OUT, "swahili_shared.jsonl"), encoding="utf-8"):
    r = json.loads(line); d = r["domain"]; w = len(r["raw_text"].split())
    total_words[d] += w
    if "afrivoice" in r["source_dataset"].lower(): drop_reason["afrivoice_source"] += 1; continue
    rs = reasons(r["raw_text"])
    if rs:
        for x in rs: drop_reason[x] += 1
        continue
    t = re.search(r"licence_tier:(\S+?)(?:;|$)", r["notes"]); t = t.group(1) if t else "unknown"
    mw[d][t] += w; kept_words[d] += w

wiki = collections.Counter(); wiki_total = collections.Counter()
for line in open(os.path.join(OUT, "wiki_candidates_strict.jsonl"), encoding="utf-8"):
    r = json.loads(line); d = r["domain"]; w = len(r["raw_text"].split()); wiki_total[d] += w
    if not reasons(r["raw_text"]): wiki[d] += w

def lic_stated(d): return mw[d].get("documented", 0) + mw[d].get("dataset_card_cc_by_4.0", 0)
def odc(d): return mw[d].get("dataset_odc_by_client_approved", 0)

res = {"precision_nonAfriVoice_rule_pass": [round(P, 3), LO, HI], "drop_reasons_main_passages": dict(drop_reason), "domains": {}}
lines = ["# Re-estimate under Michael's human standard", "",
 "Standard-conforming = not AfriVoice (0 of 54 kept in the human sample) AND passes the quality rules (terminal punctuation, no web-page tails, no spacing errors, not caption-like). Derived from the same 100 labels it is tested on, so treat it as an estimate, not a validated result.", "",
 "Expected keepable = rule-passing words x measured precision 0.71 (17 of 24; 95% CI 0.51 to 0.85). Wikipedia was not in the sample, so its precision is unvalidated.", "",
 "| Domain | Main pool before | Rule-passing, non-AfriVoice | of which licence stated | of which FineWeb-2 (ODC-By) | Wikipedia rule-passing (unvalidated) |", "|---|---:|---:|---:|---:|---:|"]
T = collections.Counter()
for d in D:
    k = kept_words[d]; res["domains"][d] = {"main_before": total_words[d], "rule_passing": k, "licence_stated": lic_stated(d), "fineweb_odc": odc(d), "wiki_rule_passing": wiki[d]}
    lines.append(f"| {d} | {total_words[d]:,} | {k:,} | {lic_stated(d):,} | {odc(d):,} | {wiki[d]:,} |")
    T.update({"b": total_words[d], "k": k, "l": lic_stated(d), "o": odc(d), "w": wiki[d]})
lines.append(f"| **total** | {T['b']:,} | {T['k']:,} | {T['l']:,} | {T['o']:,} | {T['w']:,} |")
lines += ["", "## Words toward the 200,000-per-domain target (capped), by scenario", "",
          "| Domain | A: licence stated only | B: A + Wikipedia | C: B + FineWeb-2 (if client confirms) |", "|---|---:|---:|---:|"]
cap = collections.Counter()
for d in D:
    a = lic_stated(d); b = a + wiki[d]; c = b + odc(d)
    cap.update({"A": min(a, 200000), "B": min(b, 200000), "C": min(c, 200000)})
    lines.append(f"| {d} | {a:,} | {b:,} | {c:,} |")
lines.append(f"| **capped total** | **{cap['A']:,}** | **{cap['B']:,}** | **{cap['C']:,}** |")
lines += ["", "Expected human-keepable words (multiply the rule-passing figures by about 0.71; 0.51 to 0.85 is the plausible range):",
          f"- Scenario C rule-passing capped total {cap['C']:,} -> about {int(cap['C']*P):,} (range {int(cap['C']*LO):,} to {int(cap['C']*HI):,}).",
          f"- Scenario A {cap['A']:,} -> about {int(cap['A']*P):,}.", "",
          "Targets: 1,000,000 words (fallback 500,000). Previously reported without the human standard: 487,474 (strict Wikipedia) and about 656k with FineWeb-2.", "",
          f"Why main-pool passages were dropped (a passage can have several reasons): {dict(drop_reason)}"]
res["capped"] = dict(cap)
open(os.path.join(OUT, "STANDARD_ESTIMATE.md"), "w", encoding="utf-8").write("\n".join(lines) + "\n")
json.dump(res, open(os.path.join(OUT, "standard_estimate.json"), "w", encoding="utf-8"), indent=1)
print("\n".join(lines))
