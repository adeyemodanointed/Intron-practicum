"""Rule-based detector for image-description ("caption") passages.

Spoken/visual descriptions of pictures (AfriVoice-style) are not natural domain text.
Score = number of distinct description markers; passages with score >= THRESH are flagged.
"""
import re

# Present-participle / visual-description cues in Swahili
MARKERS = [
    r"\binaonekana\b", r"\bnaona\b", r"\btunaona\b", r"\btunayoona\b", r"\bunaona\b", r"\banaonekana\b", r"\bwanaonekana\b", r"\bzinaonekana\b",
    r"\bakiwa\b", r"\bwakiwa\b", r"\bikiwa\b", r"\bzikiwa\b", r"\bkikiwa\b", r"\bukiwa\b", r"\bwamevaa\b", r"\bamevaa\b", r"\bamevalia\b", r"\bwamevalia\b", r"\bamevaa\b", r"\bwa?mevaa\b", r"\bamevalia\b",
    r"\bpicha\b", r"\btaswira\b", r"\bmandhari\b", r"\bkwenye lebo\b", r"\bkifungashio\b", r"\bvifungashio\b", r"\bmuonekano\b",
    r"\bhii ni (?:picha|taswira)\b", r"\bhuu ni mfumo\b", r"\bhili ni (?:eneo|duka|tangazo)\b", r"\bhii ni (?:simu|mashine|chumba)\b",
    r"\brangi (?:ya|ye|za|nyekundu|nyeupe|nyeusi|ya kijani|ya bluu|ya manjano)\b",
    r"\bnyuma yake\b", r"\bupande wa kushoto\b", r"\bupande wa kulia\b", r"\bkatikati\b",
    r"\bishara kwamba\b", r"\bikionyesha\b", r"\bikionesha\b", r"\bikiashiria\b", r"\bikidokeza\b", r"\bzikionyesha\b",
]
RX = [re.compile(m, re.I) for m in MARKERS]
# Strong lead patterns that start a description
LEAD = re.compile(r"^(?:mtu|watu|mwanaume|mwanamke|mkulima|wakulima|mfanyakazi|daktari|madaktari|wauguzi|muuguzi|mashine|chupa|noti|pesa|mkono|shamba|msururu|mpangilio|sehemu|hii ni|hili ni|hapa ni|hapa nayo|ni (?:ng'ombe|mtu|moja)|katika chumba|ndani ya|mfumo wa|tunayoona|huku tunaona|kifaa hiki|pakiti|tofauti kabla|wafanya kazi|wafanyakazi|mwezeshaji|mashine mbili|kilimo cha)\b", re.I)
# Strong news/document cues that argue against a caption
NEWS = re.compile(r"\b(?:alisema|amesema|ameeleza|serikali|waziri|mheshimiwa|mahakama|sheria|kifungu|tcra|rais|polisi|kampuni ya)\b", re.I)
THRESH = 3


def score(text: str) -> int:
    t = text.strip()
    n = sum(1 for rx in RX if rx.search(t))
    if LEAD.search(t[:60]):
        n += 2
    # short + descriptive tends to be caption
    words = len(t.split())
    if words < 90: n += 1
    if NEWS.search(t): n -= 3
    return n


def is_caption(text: str) -> bool:
    return score(text) >= THRESH
