"""Law passages from TanzLII PDFs saved in external/tanzlii_pdfs/ (downloaded by Michael in his own browser).
Steps: text per PDF (identical files de-duplicated by hash), drop running headers (lines repeated on >= 30% of pages), drop page numbers,
sentence-split, group to 40-150 word passages, skip number/coordinate-heavy passages, apply quality_rules + Swahili check, near-duplicate removal.
Licence: recorded as in source_register.csv for TanzLII (CC-BY-4.0); the PDFs themselves print no licence, so this must be confirmed on tanzlii.org.
"""
import json, os, re, glob, hashlib, unicodedata, collections
import pypdf
import quality_rules as Q
OUT = os.path.dirname(os.path.abspath(__file__)); SRC = os.path.join(OUT, "external", "tanzlii_pdfs")
SW = set("na ya wa kwa ni katika za la cha hii huu kuwa pia au ambayo hiyo vya kama hadi kutoka huo hizo yake wake lake ili sana kuhusu lakini kwamba pamoja".split())
EN = set("the of and is in to was were with for that this from which are by".split())
reasons = lambda t: [x for x in Q.reasons(t) if x != "over_long_scraped"]
def is_sw(t):
    toks = re.findall(r"[a-zA-Z']+", t.lower())
    return bool(toks) and sum(x in SW for x in toks) / len(toks) >= 0.08 and sum(x in EN for x in toks) / len(toks) <= 0.04
seen_hash, docs = set(), []
for fn in sorted(glob.glob(os.path.join(SRC, "*.pdf"))):
    h = hashlib.sha1(open(fn, "rb").read()).hexdigest()
    if h in seen_hash: continue
    seen_hash.add(h); docs.append(fn)
keep, rej, per = [], collections.Counter(), {}
shingle_seen = []
def sh(t, n=8):
    w = re.findall(r"\w+", t.lower()); return {" ".join(w[i:i+n]) for i in range(max(1, len(w)-n+1))}
for fn in docs:
    pages = [unicodedata.normalize("NFC", p.extract_text() or "") for p in pypdf.PdfReader(fn).pages]
    cnt = collections.Counter(ln.strip() for pg in pages for ln in set(pg.split("\n")) if ln.strip())
    lines = []
    for pg in pages:
        for ln in pg.split("\n"):
            ln = ln.strip()
            if not ln or re.fullmatch(r"\d+", ln) or (len(pages) > 2 and cnt[ln] >= max(3, 0.3 * len(pages))): continue
            lines.append(ln)
    text = re.sub(r"\s+", " ", " ".join(lines))
    text = re.sub(r"_{3,}", " ", text); text = re.sub(r"\s+", " ", text)
    sents = [s for s in re.split(r"(?<=[.!?;:])\s+(?=[A-Z\"'(\d])", text) if len(s.split()) >= 5]
    cur, ps = [], []
    for s in sents:
        cur.append(s)
        if sum(len(x.split()) for x in cur) >= 60: ps.append(" ".join(cur)); cur = []
    if cur and sum(len(x.split()) for x in cur) >= 40: ps.append(" ".join(cur))
    n_ok = w_ok = 0
    for p in ps:
        n = len(p.split()); rs = reasons(p)
        digits = sum(c.isdigit() for c in p) / max(1, len(p))
        if digits > 0.06: rs.append("number_heavy")
        if n > 200: rs.append("too_long")
        if not is_sw(p): rs.append("not_swahili")
        if rs:
            for x in rs: rej[x] += 1
            continue
        s8 = sh(p)
        if any(len(s8 & o) / max(1, len(s8 | o)) >= 0.5 for o in shingle_seen): rej["near_duplicate"] += 1; continue
        shingle_seen.append(s8); keep.append((os.path.basename(fn), p)); n_ok += 1; w_ok += n
    per[os.path.basename(fn)] = {"pages": len(pages), "words": len(text.split()), "passages_kept": n_ok, "words_kept": w_ok}
with open(os.path.join(OUT, "tanzlii_law_passages.jsonl"), "w", encoding="utf-8", newline="\n") as f:
    for i, (fn, p) in enumerate(keep, 1):
        f.write(json.dumps({"id": f"swa_law_tanzliipdf_{i:05d}", "language": "swa", "domain": "law", "raw_text": p, "source_dataset": "TanzLII PDF: " + fn,
                            "source_split": "unspecified", "license": "CC-BY-4.0 (TanzLII per source_register.csv; PDF prints no licence, confirm on tanzlii.org)",
                            "review_status": "auto_filtered_unreviewed", "notes": "rules_applied"}, ensure_ascii=False) + "\n")
print(json.dumps(per, indent=1)); print("unique PDFs", len(docs), "kept", len(keep), "words", sum(len(p.split()) for _, p in keep), "rejected", dict(rej))
