"""Agriculture and finance passages from FineWeb-2 Swahili (HuggingFaceFW/fineweb-2, swh_Latn; ODC-By; use approved by the client, written confirmation pending).
Documents are streamed from Hugging Face with duckdb; only text and url are read. Per document: split to sentences, group to 40-200 word passages, apply quality_rules,
Swahili check, no replacement chars, domain = the lexicon with >= 2 distinct stems and a strictly higher count than the other (agriculture vs finance), 8-gram near-duplicate removal
against everything already kept. Same rules as the other pipelines; no extra filters. Args: split names to read (test, train).
"""
import json, os, re, sys, unicodedata, duckdb
import quality_rules as Q
OUT = os.path.dirname(os.path.abspath(__file__))
LEX = {
    "agriculture": "kilimo mazao mkulima wakulima shamba mbegu udongo mifugo ng'ombe mbolea mavuno zao mmea mimea ufugaji kuku maziwa umwagiliaji wadudu mvua kahawa mahindi".split(),
    "finance": "benki fedha pesa uchumi biashara bima mkopo soko hisa kodi bei mapato faida uwekezaji mtaji sarafu shilingi dola malipo akiba mteja kampuni".split(),
}
RX = {d: [re.compile(r"\b" + re.escape(s) + r"\w*", re.I) for s in v] for d, v in LEX.items()}
SW = set("na ya wa kwa ni katika za la cha hii huu kuwa pia au ambayo hiyo vya kama hadi kutoka huo hizo yake wake lake ili sana kuhusu lakini kwamba pamoja".split())
EN = set("the of and is in to was were with for that this from which are by".split())
def is_sw(t):
    k = re.findall(r"[a-zA-Z']+", t.lower())
    return bool(k) and sum(x in SW for x in k) / len(k) >= 0.08 and sum(x in EN for x in k) / len(k) <= 0.04
reasons = lambda t: [x for x in Q.reasons(t) if x != "over_long_scraped"]
def sh(t, n=8):
    w = re.findall(r"\w+", t.lower()); return {" ".join(w[i:i+n]) for i in range(max(1, len(w)-n+1))}
c = duckdb.connect(); c.sql("install httpfs; load httpfs;")
keep, seen, rej = [], [], {}
for split in (sys.argv[1:] or ["test"]):
    u = f"https://huggingface.co/datasets/HuggingFaceFW/fineweb-2/resolve/main/data/swh_Latn/{split}/000_00000.parquet"
    cur = c.sql(f"select text, url, id from '{u}'")
    while True:
        batch = cur.fetchmany(2000)
        if not batch: break
        for text, url, did in batch:
            if sum(1 for r in RX["agriculture"] + RX["finance"] if r.search(text)) < 2: continue
            t = unicodedata.normalize("NFC", text.replace("\xa0", " "))
            for para in re.split(r"\n+", t):
                para = re.sub(r"\s+", " ", para).strip()
                sents = re.split(r"(?<=[.!?])\s+(?=[A-Z\"'])", para); cu = []
                for s in sents + [None]:
                    if s is not None and len(s.split()) >= 3: cu.append(s)
                    n = sum(len(x.split()) for x in cu)
                    if (s is None and n >= 40) or n >= 80:
                        p = " ".join(cu); cu = []; why = reasons(p)
                        if "\ufffd" in p: why.append("replacement_char")
                        if n > 200: why.append("too_long")
                        if not is_sw(p): why.append("not_swahili")
                        h = {d: sum(1 for r in RX[d] if r.search(p)) for d in RX}
                        dom = max(h, key=h.get)
                        if h[dom] < 2 or h["agriculture"] == h["finance"]: why.append("off_domain_lexicon")
                        if why:
                            for x in why: rej[x] = rej.get(x, 0) + 1
                            continue
                        s8 = sh(p)
                        if any(len(s8 & o) / max(1, len(s8 | o)) >= 0.5 for o in seen[-3000:]): rej["near_duplicate"] = rej.get("near_duplicate", 0) + 1; continue
                        seen.append(s8); keep.append((dom, p, url, did, split))
                    elif s is None: cu = []
fn = os.path.join(OUT, "fineweb_agri_fin_passages.jsonl")
with open(fn, "w", encoding="utf-8", newline="\n") as f:
    for i, (dom, p, url, did, split) in enumerate(keep, 1):
        f.write(json.dumps({"id": f"swa_{dom}_fw2_{i:06d}", "language": "swa", "domain": dom, "raw_text": p, "source_dataset": "HuggingFaceFW/fineweb-2 swh_Latn", "source_split": split,
                            "license": "ODC-By (HuggingFaceFW/fineweb-2); client approved use (relayed by Michael 2026-10-05; written confirmation pending)",
                            "review_status": "auto_filtered_unreviewed", "notes": f"url={url}; doc={did}; lexicon>=2"}, ensure_ascii=False) + "\n")
tot = {}
for dom, p, *_ in keep: tot[dom] = tot.get(dom, 0) + len(p.split())
print("kept", len(keep), tot, "rejected", rej)
