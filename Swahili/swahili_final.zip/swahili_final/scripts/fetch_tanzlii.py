"""List and fetch Swahili legislation from TanzLII (licence per site: CC BY 4.0, see source_register.csv). Raw HTML saved to external/tanzlii/."""
import re, os, time, json, urllib.request
OUT = os.path.dirname(os.path.abspath(__file__)); D = os.path.join(OUT, "external", "tanzlii"); os.makedirs(D, exist_ok=True)
def get(u):
    for i in range(3):
        try: return urllib.request.urlopen(urllib.request.Request(u, headers={"User-Agent": "Mozilla/5.0"}), timeout=60).read().decode("utf-8", "replace")
        except Exception as e: time.sleep(2)
    return ""
links = []
for sect in ("all",):
    for p in range(1, 60):
        t = get(f"https://tanzlii.org/en/legislation/{sect}?languages=sw&page={p}")
        new = [l for l in dict.fromkeys(re.findall(r'href="(/en/akn/[^"]*swa@[^"]*)"', t)) if l not in links]
        if not new: break
        links += new
print("swahili legislation links", len(links))
json.dump(links, open(os.path.join(D, "links.json"), "w"))
for i, l in enumerate(links):
    fn = os.path.join(D, re.sub(r"[^A-Za-z0-9]+", "_", l) + ".html")
    if os.path.exists(fn): continue
    open(fn, "w", encoding="utf-8").write(get("https://tanzlii.org" + l)); time.sleep(0.5)
print("done")
