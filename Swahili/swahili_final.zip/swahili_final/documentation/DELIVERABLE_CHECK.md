# Deliverable check against the sheet (Michael's rows)

Source: Google Sheet "Practicum", Task Assignment tab, read 4 Oct 2026 (sheet last modified 4 Oct 07:34 UTC; it has no separate "Deliverables" section). Status key: MET / MET (AI-screened) / PARTLY / NOT MET / NOT STARTED.

## NEW TASK ASSIGNMENT rows

| Sheet task (due) | Requirement in the sheet | Status | Evidence | What is still needed |
|---|---|---|---|---|
| Dataset gathering and audit, Swahili (9/27) | Domain-labelled, clean punctuated text; verify licence, language/variant, domain, token count, punctuation coverage, text quality; manually review samples; format accepted records in shared JSONL | PARTLY | JSONL, source register, licence tiers, punctuation stats, caption + near-dup filters; `TARGET_GAP.md` | Manual review of samples by a human; second reviewer; the 1M/500k token target is not met on licence-stated text (487k capped with Wikipedia, below the 500k fallback) |
| Punctuation statistics for all selected datasets (9/27) | One comparable table across languages, same counting method | PARTLY | `punctuation_stats.csv` (Swahili, whitespace words) | Other languages' tables; confirm they used the same counting method |
| Manual validation sample (9/27) | Each owner reviews 50-100 records; second member checks a subset; report acceptance rate and agreement | PARTLY: reviewer 1 done (100 rows, keep 19%); second reviewer pending | `manual_validation_sample_EN.xlsx` (100 rows, team audit-tab layout), `score_validation.py` | A second person checks ~25 rows and the scorer is rerun for agreement |
| Shared data formatting (9/27) | Merge and validate language files against the shared schema: required fields, duplicate IDs, encoding, language/domain labels | MET for Swahili (AI-screened) | `swahili_shared.jsonl` 6,366 records; `validate_jsonl.py` reports no errors | Merge with the other languages once they send theirs. Note: schema domain list for Swahili is agriculture, finance, health, law, telecoms |
| Proposed cleaning process (9/28, with Rose) | Document Unicode/whitespace cleanup, quote and apostrophe normalisation, duplicate removal, malformed-record filtering, punctuation-label extraction | PARTLY | `CLEANING_PROCESS.md` (steps marked observed vs proposed) | Quote/apostrophe normalisation and punctuation-label extraction are proposed, not implemented; Rose's review |
| Consolidated Monday presentation table (9/28) | One row per dataset: language, domain, licence, token target/actual, punctuation quality, validation result, use/reject | PARTLY | `presentation_table.csv` (279 rows), `source_register.csv`, slide deck | Validation-result column says "pending" until human review; 'use' decisions rest on stated dataset licences |

## Earlier rows with Michael's name

| Sheet task | Status | Evidence / note |
|---|---|---|
| Literature review (your 4 papers) | MET | Medical ASR, Portuguese, Spanish customer support, USYD-JD Swahili: methodology and result filled in the Literature Review tab |
| Research paper (all, 9/23) | UNCLEAR | The sheet marks it "In progress (<25%)"; I found no paper draft in the folder |
| Model selection (with Rose, 9/25) | NOT STARTED | A baseline TF-IDF + logistic-regression domain classifier exists (last week's work) but that is not the PnC model |
| Setting up Baseline (Rose, Ukachi) | NOT MY ROW | |
| New implementation (with Peter, 9/29) | NOT STARTED | |
| Running ablations (10/02) | NOT STARTED | |
| Testing and evaluation (11/01) | NOT STARTED | |

## Dataset-selection criteria (pasted from the sheet)

| Criterion | Status |
|---|---|
| Genuinely in the target language | Mostly met; no systematic language-ID check on the main pool (Wikipedia passages use a function-word check) |
| Usable punctuation | Met (96.5% of passages end in terminal punctuation; law 65.9%, telecoms 78.3%) |
| Domain known and defensible | Weak: caption contamination removed, but domain labels still come from keywords or Wikipedia categories |
| Licence permits research use | PARTLY: 219,837 words with a stated licence; FineWeb-2 (about 177k) on hold pending client confirmation; Wikipedia is CC BY-SA |
| Enough text for the token target | NOT MET: under Michael's human standard, 11,128 (licence stated only), 277,207 (with Wikipedia, unvalidated), 377,904 (with FineWeb-2 if the client confirms), all capped at 200k per domain; fallback 500,000 not reached (see STANDARD_ESTIMATE.md). Earlier 487k / 656k figures did not apply the human standard |
| Diacritics preserved | Met (NFC, no replacement characters; Swahili uses plain Latin letters) |
| Documented and consistent format | Met |

## Blind classifier tab
The team has a "Blind classifier" tab (Kinyarwanda). The Swahili equivalent, `blind_classifier_swahili.csv`, has `sample_id, raw_text, label, Classifier, human_label_blind`. The `Classifier` column uses a model re-fitted with the same spec as last week's (the saved pickle fails to load under the installed scikit-learn). On the 100 rows it agrees with the pipeline label on all 100, including the 54 suspected captions. That shows the classifier reproduces the keyword labels, not that it understands domains. 13 of the 100 rows were in its training partition.
