# Target gap report (words, whitespace tokens; tokenizer = whitespace word, see README)

| Domain | AI-accepted | After caption + near-dup filter | Licence stated (documented or dataset card CC-BY) | + ODC-By dataset, underlying rights unresolved | Target | Gap to target (licence stated) |
|---|---:|---:|---:|---:|---:|---:|
| agriculture | 159,241 | 55,701 | 46,908 | 46,908 | 200,000 | 153,092 |
| finance | 213,680 | 130,440 | 113,826 | 113,826 | 200,000 | 86,174 |
| health | 158,351 | 84,625 | 43,955 | 52,516 | 200,000 | 156,045 |
| law | 164,447 | 162,041 | 12,729 | 96,327 | 200,000 | 187,271 |
| telecoms | 104,678 | 98,668 | 2,419 | 87,303 | 200,000 | 197,581 |
| **total** | 800,397 | 531,475 | 219,837 | 396,880 | 1,000,000 (fallback 500,000) | 780,163 |
