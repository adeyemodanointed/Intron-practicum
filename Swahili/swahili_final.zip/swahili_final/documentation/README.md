# Michael: Swahili deliverables (4 Oct 2026)

All decisions here are **AI-screened**, not human-verified. No second human reviewer has looked at anything. See "Needs a human" below.

| Sheet task | Output | State |
|---|---|---|
| Dataset gathering and audit, Swahili | this README + `summary.json` | draft complete |
| Punctuation statistics | `punctuation_stats.csv` | done (same counting method per domain) |
| Manual validation sample | `manual_validation_sample_EN.xlsx`, `score_validation.py` | **reviewer 1 done (100 rows); second reviewer pending** |
| Shared data formatting | `swahili_shared.jsonl` (6,406 records after caption filter), `id_mapping.csv`, `validate_jsonl.py` | done; validator reports no errors |
| Proposed cleaning process | `CLEANING_PROCESS.md` | draft for Rose |
| Consolidated presentation table | `presentation_table.csv` (279 source x domain rows) | done; every row says human validation pending |

## Audit numbers (words = whitespace split; tokenizer not chosen)

Counting tiers: **AI-accepted** (before caption filter) -> **after caption filter** (final JSONL) -> **documented licence**.

| Domain | AI-accepted words | After caption filter | % of 200k target | Documented-licence words |
|---|---:|---:|---:|---:|
| Agriculture | 159,241 | 56,029 | 28% | 4,409 |
| Finance | 213,680 | 131,547 | 66% | 278 |
| Health | 158,351 | 84,739 | 42% | 157 |
| Law | 164,447 | 162,431 | 81% | 12,729 |
| Telecoms | 104,678 | 98,668 | 49% | 2,419 |
| **Total** | **800,397** | **533,414** | 53% of 1M | **20,000 (approx.)** |

Final JSONL (before near-dup pass): 6,406 records. Caption filter (`caption_filter.py`) removed 5,316 passages / 266,983 words, almost all from the AfriVoice speech dataset (image descriptions, not natural domain text). `caption_exclusions.csv` lists every removal. On the 100-row sample, measured against Claude's own labels, it scored precision 0.98 and recall 0.89 (tuned on the same rows, so optimistic; Michael's human labels will give the real number).

Passage decisions in the source workbook: 11,531 ACCEPT, 191 NEEDS_EDIT (corrected text used), 2,226 REJECT (2,203 caption artifacts caught by the earlier AI pass).

## Caveats to say out loud on Monday
1. **Rights:** most passages have unresolved licences (mostly AfriVoice and FineWeb-2). Treat the 533k as "candidate", not "usable". Only about 20k words have documented terms.
2. **Not individually read:** 5,816 of the 6,406 final passages were bulk-screened. Per `quality_flags`, only the seed/core passages were read one by one by the AI.
3. **Duplicates:** exact-text duplicates: 0. The 765-id hold manifest matches 0 pool records (it appears already applied upstream). The workbook's `duplicate_group_id` is unique per row, so near-duplicate checking has **not** been done on this pool; run an 8-gram Jaccard pass before any train/test split.
4. **Punctuation:** agriculture and finance are 100% terminal-punctuated, which suggests heavy filtering; law (65.8%) and telecoms (78.1%) are lower.
5. **Validation sample is stratified, not random**, so its acceptance rate will not equal the pool's rate.

## Needs a human
1. Michael reviews `manual_validation_sample_EN.xlsx` (100 rows, team audit-tab layout; fill Is_Swa, domain_ok, punctuation_ok, quality_ok, keep with YES/NO).
2. A different teammate fills `reviewer2_keep` for about 25 rows.
3. Run `python score_validation.py` for acceptance rate and Cohen's kappa. Only then fill "validation result" in the presentation table.

## Human validation results (Michael, 100-row stratified sample, 4 Oct 2026)
Reviewer 1: Michael (YES/NO per criterion, `manual_validation_sample_EN.xlsx`). No second reviewer yet; no fluent-speaker check of grammar and register.

| Criterion | YES |
|---|---:|
| Genuine Swahili | 99 / 100 |
| Domain correct | 97 / 100 |
| Punctuation usable | 53 / 100 |
| Text quality OK | 29 / 100 |
| **Kept (all four YES)** | **19 / 100** |

- Agreement with the AI screening (keep vs accept): 31%.
- The sample is stratified (20 per domain, many caption-like rows), so 19% is **not** the pool's keep rate.
- The automatic caption filter flagged 49 of the 100 rows; Michael kept 1 of them (48 of 49 were correct removals). Among the 51 rows it passed, he kept 18 (35%, a rough figure: n = 51, stratified). By source among passes: FineWeb-2 12 / 31, other 6 / 14, AfriVoice 0 / 6 (captions the filter missed).
- Keep rate by domain: telecoms 10/20, law 5/22, agriculture 3/20, health 1/18, finance 0/20.
- Consequence: the 531k-word main pool is probably overstated. Applying Michael's standard to the pool is the next step; the figures in TARGET_GAP.md have not been adjusted for it.
- Round 1 of the review used passages that I had truncated with a display marker; 33 rows were re-reviewed on full text and only the re-reviewed answers are used.

## Re-estimate under Michael's human standard (see `STANDARD_ESTIMATE.md`)
Derived from his 100 labels (so an estimate, not independently validated):
- AfriVoice: 0 of 54 rows kept (95% upper bound about 7%), so it is excluded from the standard-conforming pool even though its dataset card states CC-BY-4.0.
- Everything else, passing simple rules (terminal punctuation, no web-page tails, no spacing errors, not caption-like): 17 of 24 kept (precision 71%, 95% CI 51 to 85%); the rules keep 17 of his 19 kept non-AfriVoice rows.
- Result (capped at 200k per domain): licence-stated only **11,128**; plus Wikipedia (unvalidated) **277,207**; plus FineWeb-2 if the client confirms **377,904**, i.e. about 268k expected keepable (range 193k to 321k). The 500k fallback is not reached in any scenario.
- Earlier figures (487k, 656k) did not apply the human standard and should not be quoted as usable words.

## PnC annotation (`annotate_pnc.py`, `pnc_annotated.jsonl`, `pnc_stats.json`)
Word-level punctuation labels (O, COMMA, PERIOD, QUESTION, EXCL, OTHER) and capitalisation labels (LOWER, TITLE, UPPER, MIXED) for 4,965 passages / 438,996 words: the standard-conforming main pool (not AfriVoice, passes quality rules) plus rule-passing Wikipedia (unvalidated). Labels: O 90.6%, COMMA 4.7%, PERIOD 4.4%, OTHER 0.3%, QUESTION 0.02% (90 words), EXCL 0.005%. Round trip (rebuild text from tokens) passes for all but 3 passages. Labels are rule-derived from the text as written, not human-checked; the text itself is only as good as the 71% estimate.

## Update: licences, near-duplicates and Wikipedia (see `TARGET_GAP.md`, `source_register.csv`)
- AfriVoice dataset card states CC-BY-4.0 for its transcripts; FineWeb-2 card states ODC-By (does not clear the underlying pages). Licence-stated words in the main pool: 219,837.
- Near-duplicate pass removed 40 passages; final main pool: 6,366 passages / 531,475 words.
- Swahili Wikipedia (CC BY-SA 4.0) fetched by topic category: 13,444 passages / 819,731 words after quality gates; **306,320 words after a strict domain-vocabulary filter**. All auto-filtered and **unreviewed**.
- Counting toward targets (each domain capped at 200k): **487,474** with the strict Wikipedia filter, up to 767,734 if all category-labelled Wikipedia text is counted. The 500k fallback is not reached under the strict filter.
- Token definition: whitespace words (the sheet's target is in word tokens).

Rebuild: `python build_deliverables.py`; Wikipedia: `python fetch_wikipedia.py`, `python process_wikipedia.py`, `python finalize_report.py`.
