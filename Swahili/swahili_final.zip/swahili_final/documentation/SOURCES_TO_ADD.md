# More good text: farming, finance, and text with questions

Searched 4 Oct 2026. Nothing below has been downloaded except what is marked DONE. Dataset-level licences are as stated on the pages I read; the rights of the underlying text are not independently verified.

## Farming (agriculture)
| Source | Licence (as stated) | Status |
|---|---|---|
| TARI/IITA rice training guide (already on disk) | CC BY 4.0 printed on PDF page 3 | **DONE**: 118 clean passages, 8,616 words, `tari_rice_passages.jsonl`. Agriculture seed is now 171 passages / 10,005 words, all from documents (no Wikipedia) |
| Swahili Corpus, Masasi and Masua, Mendeley Data v2 (Jan 2024), [page](https://data.mendeley.com/datasets/d4yhn5b9n6/2) | CC BY 4.0; 12 categories incl. Agriculture and Business and Industries; collected from official sources (PDF/DOCX) | **Needs your OK to download.** File sizes are not shown on the page; a search snippet said the Agriculture file has about 726,000 words (unverified). Sentences, so must be grouped into passages and re-checked with the quality rules; underlying document rights unverified |

## Finance
- The same Mendeley corpus has a Business and Industries category (not yet inspected).
- No other openly licensed Swahili finance document source found yet. Official finance documents (Bank of Tanzania, budget speeches, CMSA) state rights reserved or no licence.

## Text with questions (for punctuation and QA)
| Source | Licence (as stated) | What it gives |
|---|---|---|
| TyDi QA, Swahili part, [HF page](https://huggingface.co/datasets/google-research-datasets/tydiqa) | apache-2.0 on the card; Swahili present (example question: "Je,Ngamia anaweza kaa bila maji kwa muda gani?") | Real Swahili questions written by people; passages come from Swahili Wikipedia. Per-language counts not shown on the page |
| KenSwQuAD, [Harvard Dataverse](https://dataverse.harvard.edu/dataset.xhtml?persistentId=doi:10.7910/DVN/OTL0LM) | Not confirmed on the pages I could read (the paper is CC BY 4.0); check the Dataverse page | 7,526 question-answer pairs over 1,445 Kenyan stories; annotators wrote the questions |
| Belebele (Swahili, if present), [HF page](https://huggingface.co/datasets/facebook/belebele) | cc-by-sa-4.0 | Multiple-choice questions on passages; I could not confirm Swahili on the page |

## What I need from you
Permission to download: (1) the TyDi QA Swahili split, (2) KenSwQuAD, (3) the Mendeley Swahili Corpus Agriculture and Business files. I'll report sizes and licences after checking each before using any of it.

## Download results (2026-10-04)

| Source | Result |
|---|---|
| Mendeley Swahili Corpus, KILIMO + BIASHARA (CC BY 4.0, confirmed in the Mendeley API) | **Rejected.** Downloaded (4.7 MB and 0.4 MB). Both files are lowercased with all punctuation removed (0 punctuation marks, 0 capital letters), so they fail "usable punctuation". Not used. |
| TyDi QA primary_task validation, Swahili rows (apache-2.0 on card) | Downloaded (232 MB file, all languages). 2,288 Swahili questions, all ending in "?". Short questions (about 9 words) about Wikipedia topics. |
| Belebele swh_Latn (cc-by-sa-4.0) | Downloaded (0.9 MB). 900 Swahili questions about FLORES passages. |
| KenSwQuAD (CC BY 4.0 per Dataverse) | **Not downloaded.** Dataverse requires a guestbook form (name and email) before download. Needs Michael to fill it in himself. |

Questions file: `questions_swahili.jsonl` (3,154 unique questions, 27,559 words), built by `build_questions.py`.
Domain tags come from keywords in the question only (auto-tagged, unreviewed): agriculture 37, finance 83, health 81, law 75, telecoms 51, other 2,827.
Tagging by source article was tried and dropped (it tagged a giraffe article as agriculture).
These are questions only, not 10k-word domain passages, so they add question punctuation but do not close the finance gap.

## TanzLII Swahili legislation (2026-10-04)
The listing works: 228 Swahili acts and government notices (`external/tanzlii/links.json`). Every document page is behind a Cloudflare "Just a moment" check (HTTP 403), so I could not fetch the text. I did not try to get around the check. The text has to be downloaded by Michael in a normal browser (each act has a PDF/Word download button), or the team can ask TanzLII for bulk access.

## Hugging Face (2026-10-04)
Searched Hugging Face for Swahili datasets (162 hits; most are speech, translation or instruction data).
Used: `community-datasets/swahili_news` (card: cc-by-4.0, 38 MB). News labelled uchumi (economy) and afya (health).
After the rules (no glued sentences, 40-200 words, at least 2 domain keywords, Swahili check) `process_swahili_news.py` keeps finance 87 passages / 8,439 words and health 1,752 passages / 185,185 words (`swahili_news_passages.jsonl`).
Licence tier: dataset card says CC BY 4.0, but the underlying news-site text is unresolved, so it is NOT counted as licence-clear. It is reported as its own tier.
Most rejections are "glued sentences" (a scrape artefact like "huu.Misafara", 2,419 passages). A mechanical repair (add a space after the full stop) would raise finance; I have not applied it because it changes the text.
Not used: general-purpose Swahili corpora on Hugging Face with no domain labels and unclear or non-commercial licences (cc-by-nc, mit-tagged scrapes of unknown origin).

## Wikipedia extra pass
Started `EXTRA=1 python fetch_wikipedia.py finance telecoms` (634 finance titles first, then telecoms) with new category roots. Output appends to `wiki_raw.jsonl`; it must be processed with `process_wikipedia.py` when finished.

## Kaggle (2026-10-04, searched in the signed-in browser; nothing downloaded)
- `Swahili : News Classification Dataset` and `Swahili News Classification`: copies of swahili_news, which is already used (see the Hugging Face section).
- `SHAMBAQA` (agriculture Q&A): licence "Unknown". The dev file looks machine-generated (placeholder text such as "unknown" inside questions, boilerplate English glosses). Rejected.
- `Multilingual_health_Q&A_dataset_African_languages`: Zindi challenge data (Swahili in Kenyan nuance, maternal and sexual health Q&A). Kaggle licence is "Other (specified in description)" and the description gives none. Competition data usually carries use restrictions, so it needs a licence check with Zindi before use. Not downloaded.
- `kiswahili-ai-blended` (50 MB JSON), `swahilipot_hackathon_data`: no licence stated and the origin is unclear. Not downloaded.

## FineWeb-2 approved by the client (2026-10-05)
Michael reports the client said yes to FineWeb-2 because it is open source (ODC-By). Recorded as tier `dataset_odc_by_client_approved`; written confirmation is still pending.
The dataset licence is clear; the rights of the underlying web pages were not individually checked. The same quality rules apply (no relaxation).
Words (rule-passing, annotated): law 45,566, telecoms 49,013, health 6,084 (total 100,663). Agriculture and finance have none.
Licence-clear total now 436,262 words: agriculture 20,571, finance 60,429, health 172,559, law 112,207, telecoms 70,496. `clear_words_now.json` holds the figures.
The seed excludes passages over 250 words, so most FineWeb-2 text counts toward the target but does not appear in the seed.

## Agriculture Wikipedia pass (2026-10-05)
Ran `EXTRA=1 fetch_wikipedia.py agriculture`: 32 articles, 0 new strict words (strict agriculture stays 8,046). Wikipedia is exhausted for agriculture.

## More finance words: Mollel/SwahiliNewsClassification, category uchumi (2026-10-05)
Downloaded `mollel_news.parquet` (33 MB, card: cc-by-4.0). 3,007 economy articles (941,554 words).
Without repair: 0 passages kept (every long article has the glued-sentence artefact, e.g. "huu.Misafara").
With a mechanical repair (insert a space after a full stop that is followed by a capital letter) and the usual rules (no new filters): `mollel_finance_passages_repaired.jsonl`, 1,834 passages, 187,714 words, near-duplicates of swahili_news removed.
Tier: dataset card CC BY 4.0, underlying newspaper rights unresolved. NOT counted in the licence-clear totals until Michael decides (the client approved FineWeb-2, not this dataset). Not human-reviewed. Spot check: mostly business and economy news; some items are about roads or mining.
If counted: finance 60,429 + 187,714 = 248,143; overall 436,262 + 187,714 = 623,976 words.

## Agriculture: Kenyan and Tanzanian government sites, blogs and news (2026-10-05)
- Kenya Ministry of Agriculture (kilimo.go.ke): "Copyright 2026 Ministry of Agriculture and Livestock Development", English only, no reuse licence. Not used.
- Kilimo News (kilimonews.co.ke): "All rights Reserved", about 31+ Swahili articles. Not used.
- KBC Swahili, KilimoKwanza.org: no licence statement found. Not used. Tanzania's kilimo.go.tz did not respond to my fetch (timeout), so its terms are unchecked.
- VOA Swahili (voaswahili.com): VOA-produced text is public domain per VOA usage terms; articles that mention AFP, AP or Reuters were dropped. Of 136 search hits only 60 had a text body (12,127 words); after wire exclusion and the same rules plus 2 agriculture keywords: `voa_agri_passages.jsonl`, 32 passages, 2,990 words. Counted as licence-clear (public domain).
Agriculture is now 23,561 licence-clear words.

## FineWeb-2 Swahili: agriculture and finance (2026-10-05)
FineWeb-2 swh_Latn (ODC-By; client approved) is the largest source. Only the 15 MB test shard has been read (12,669 documents, 5.19M words); the train shard is 1.4 GB and has not been downloaded.
`process_fineweb_domains.py test` kept 3,482 passages (agriculture 78,066 words, finance 154,650) with the same rules and the 2-keyword domain check.
Sources: government (parliament.go.tz, bunge.go.tz, kilimo.go.tz), news, blogs and forums; also machine-translated and spam sites (hosts starting "sw.", libretexts, cryptosignals, binaryoptions).
The spam hosts were excluded by hostname (699 of 3,482 passages), leaving `fineweb_agri_fin_kept.jsonl`: agriculture 63,457 words, finance 120,898 words. Passages from parliament debates are real Swahili but their domain is borderline.
Licence-clear totals now: agriculture 87,018, finance 181,327, health 172,559, law 112,207, telecoms 70,496 = 623,607 words (news tier separate: 381,292).

Classifier note: with FineWeb-2 text in the agriculture, finance and law seeds, the seed-trained classifier scored 64.9% on Michael's reviewed passages (gold 47.4%, non-caption 49.0%); law recall fell to 0.20. Parliament-debate and forum text is a different register from the statutes and news in the test set, so the seed composition, not only its size, drives the classifier.

## FineWeb-2 Swahili train file (2026-10-05)
Downloaded `external/fineweb2_swh_train.parquet` (1.43 GB, ODC-By, client approved). `process_fineweb_train.py` read 84,000 documents and stopped when agriculture, finance and telecoms each reached 120,000 new words (selection cap; at most 9,000 words per host per domain; machine-translated/spam hosts skipped).
New passages: `fineweb_train_passages.jsonl` (agriculture 1,754, finance 1,815, telecoms 1,831). Same quality rules; domain by 2+ lexicon stems.
Licence-clear totals now: agriculture 206,813, finance 301,005, health 172,559, law 112,207, telecoms 190,288 = 982,872 words (capped at 200k per domain: 875,054). News tier separate: 381,292.
Domain precision is unreviewed: a spot check of 8 passages found real farm-radio and parliament text but also religious pages matching words like "kuku" and "chakula". Review a sample before relying on the domain label.
Classifier on Michael's reviewed passages: 66.0% (gold 84.2%, non-caption 57.1%).
