# Proposed cleaning process: Swahili (swa)

Owner: Michael. Draft for review with Rose. Steps marked **observed** are backed by decisions recorded in `ALL_PASSAGES_HUMAN_REVIEW_CLEANED.xlsx` (AI-screened pass of 3 Oct 2026); steps marked **proposed** are not yet implemented or verified.

| # | Step | Rule | Status | Evidence / count |
|---|---|---|---|---|
| 1 | Unicode normalisation | NFC; reject U+FFFD; keep Swahili text as-is (no diacritics stripping; Swahili uses plain Latin). For Yoruba/Igbo, never strip tone marks or dot-below characters. | observed (output checked: 0 non-NFC, 0 U+FFFD in 6,406 records) | `validate_jsonl.py` |
| 2 | Whitespace | collapse runs of whitespace; trim; fix glued sentences such as `huu.Ndizi` where punctuation lacks a following space | proposed (glued-sentence variants exist in the near-duplicate hold manifest) | quarantine_manifest.jsonl |
| 3 | Quote / apostrophe normalisation | map curly quotes and apostrophes to one form; keep apostrophes inside Swahili words (e.g. `ng'ombe`) | implemented in `annotate_pnc.py` (applied to the annotated set only, not to `swahili_shared.jsonl`) | round-trip check: 3 of 4,968 passages failed and were skipped |
| 4 | Boilerplate stripping | remove scraped footers, raw URLs, figure/table cross-references | observed | 166 footer strips, 11 URL removals, 10 figure/table pointer removals |
| 5 | Caption / register filter | reject image-description ("spoken visual description") passages, which are not natural domain text. Pass 1 (AI): 2,203 rejects. Pass 2 (`caption_filter.py`, rule-based): a further 5,316 passages / 266,983 words removed from the accepted set | observed | `caption_exclusions.csv`; precision 0.98 / recall 0.89 vs Claude labels on the 100-row sample (tuned on it; optimistic) |
| 6 | Malformed record filter | reject truncated passages, table dumps, heavy disfluency | observed | 14 truncated, 1 table dump, 5 disfluency, 3 truncated+caption |
| 7 | Grammar fixes | light noun-class agreement fixes flagged NEEDS_EDIT | observed (3 cases) | small; a fluent speaker should verify |
| 8 | Deduplication | exact normalised-text dedup (0 found), then within-domain near-duplicates (word 8-gram Jaccard >= 0.5; keep the longest of each cluster), then the 765-id hold manifest (0 pool matches; already applied upstream). Keep duplicate groups on one side of any train/test split | observed: 40 passages / 1,939 words removed (`near_dup_exclusions.csv`). Cross-domain near-duplicates not checked | summary.json |
| 9 | Punctuation-label extraction | tag each word with the punctuation that follows it: none / comma / period / question / exclamation / other, plus a capitalisation label | implemented: `annotate_pnc.py` -> `pnc_annotated.jsonl` (4,965 passages, 438,996 words); counting method in `punctuation_stats.csv` is the same Unicode whitespace-word method for all domains | punctuation_stats.csv |
| 10 | Licence gate | record licence tier per passage and per source (`source_register.csv`): `documented`, `dataset_card_cc_by_4.0` (AfriVoice, per dataset card), `dataset_odc_by_underlying_unresolved` (FineWeb-2), `unresolved` | observed | tiers in `TARGET_GAP.md`; AfriVoice card states CC-BY-4.0 for the transcripts it created; FineWeb-2 card states ODC-By, which does not clear the underlying web pages |

## Known weaknesses
- 5,816 of the 6,406 passages in the shared file were bulk-screened by program/AI, not individually read. The decisions are AI-screened, not human-verified.
- Law (65.8%) and telecoms (78.1%) have many passages that do not end in terminal punctuation. Legal headings and list items likely explain it; decide whether to keep them for punctuation work.
- Token definition: the sheet's target is in "word tokens", so all counts use whitespace-delimited words (punctuation attached). `token_count` is therefore not used. A sub-word tokenizer is only needed for model training and should be chosen with model selection.
