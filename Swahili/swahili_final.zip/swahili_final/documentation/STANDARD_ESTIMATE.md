# Re-estimate under Michael's human standard

Standard-conforming = not AfriVoice (0 of 54 kept in the human sample) AND passes the quality rules (terminal punctuation, no web-page tails, no spacing errors, not caption-like). Derived from the same 100 labels it is tested on, so treat it as an estimate, not a validated result.

Expected keepable = rule-passing words x measured precision 0.71 (17 of 24; 95% CI 0.51 to 0.85). Wikipedia was not in the sample, so its precision is unvalidated.

| Domain | Main pool before | Rule-passing, non-AfriVoice | of which licence stated | of which FineWeb-2 (ODC-By) | Wikipedia rule-passing (unvalidated) |
|---|---:|---:|---:|---:|---:|
| agriculture | 55,701 | 13,002 | 4,326 | 0 | 7,629 |
| finance | 130,440 | 14,110 | 278 | 0 | 60,186 |
| health | 84,625 | 18,548 | 157 | 6,085 | 166,429 |
| law | 162,041 | 69,646 | 4,316 | 45,587 | 34,317 |
| telecoms | 98,668 | 57,863 | 2,051 | 49,025 | 19,490 |
| **total** | 531,475 | 173,169 | 11,128 | 100,697 | 288,051 |

## Words toward the 200,000-per-domain target (capped), by scenario

| Domain | A: licence stated only | B: A + Wikipedia | C: B + FineWeb-2 (if client confirms) |
|---|---:|---:|---:|
| agriculture | 4,326 | 11,955 | 11,955 |
| finance | 278 | 60,464 | 60,464 |
| health | 157 | 166,586 | 172,671 |
| law | 4,316 | 38,633 | 84,220 |
| telecoms | 2,051 | 21,541 | 70,566 |
| **capped total** | **11,128** | **299,179** | **399,876** |

Expected human-keepable words (multiply the rule-passing figures by about 0.71; 0.51 to 0.85 is the plausible range):
- Scenario C rule-passing capped total 399,876 -> about 283,245 (range 203,936 to 339,894).
- Scenario A 11,128 -> about 7,882.

Targets: 1,000,000 words (fallback 500,000). Previously reported without the human standard: 487,474 (strict Wikipedia) and about 656k with FineWeb-2.

Why main-pool passages were dropped (a passage can have several reasons): {'space_before_punct': 232, 'no_terminal_punct': 221, 'afrivoice_source': 4591, 'glued_sentences': 75, 'web_boilerplate': 91}
